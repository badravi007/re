import { Module } from '@nestjs/common';
import { MulterModule } from '@nestjs/platform-express';
import { TypeOrmModule } from '@nestjs/typeorm';
import { AuthModule } from './auth/auth.module';
import { typeormOrmConfig } from './config/typeorm.config';
import { Common_data_user_appModule } from './module/common_data_user_app/common_data_user_app.module';
import { Custom_appModule } from './module/custom_app/custom_app.module';
import { EducationalInstitutionsCategoriesCountriesModule } from './module/educational_institutions_categories_countries/educational_institutions_categories_countries.module';
import { Getster_appModule } from './module/getster_app/getster_app.module';
// import { Getster_masterModule } from './module/getster_masters/getster_master.module';
import { createConnection } from 'typeorm';
import { GetsterRegistrationModule } from './module/getster-registration/getster-registration.module';
import { GetsterMasterModule } from './module/getster_master/getster_master.module';
import { UserAppModule } from './module/user-app/user-app.module';
import { DateTimeService } from './shared/service/date-time.service';
@Module({
  imports: [
    TypeOrmModule.forRoot(
      typeormOrmConfig('manage_getsters_of_get_wow_education_db', {
        name: 'manage_getsters_of_get_wow_education_db',
      }),
    ),
    TypeOrmModule.forRoot(
      typeormOrmConfig('wow_user_app_db', { name: 'wow_user_app_db' }),
    ),
    TypeOrmModule.forRoot(
      typeormOrmConfig('wow_custom_app_db', { name: 'wow_custom_app_db' }),
    ),
    TypeOrmModule.forRoot(
      typeormOrmConfig('wow_getster_app_db', { name: 'wow_getster_app_db' }),
    ),
    TypeOrmModule.forRoot(
      typeormOrmConfig('in_manage_get_wow_education_db', {
        name: 'in_manage_get_wow_education_db',
      }),
    ),
    TypeOrmModule.forRoot(
      typeormOrmConfig('user_apps_common_data_db', {
        name: 'user_apps_common_data_db',
      }),
    ),
    AuthModule,
    GetsterRegistrationModule,
    GetsterMasterModule,

    Common_data_user_appModule,
    EducationalInstitutionsCategoriesCountriesModule,
    UserAppModule,
    Custom_appModule,
    Getster_appModule,
    // Getster_masterModule,
    Common_data_user_appModule,
    MulterModule.register({
      dest: '.src/assets',
    }),
  ],
  providers: [DateTimeService],
})
export class AppModule {}

// Established connection to database
createConnection({
  type: 'mysql',
  port: 3306,
  host: 'localhost',
  username: 'root',
  password: 'GetBizMysqlDatabasePwd2021@',
});
