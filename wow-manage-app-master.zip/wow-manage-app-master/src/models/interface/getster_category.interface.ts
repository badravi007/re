export interface IGetsterCategory {
  getster_category_id: string;
  parent_getster_category_id?: string | null;
  getster_category_name?: string;
  is_the_getster_category_hidden?: boolean;
  children?: IGetsterCategory[];
  getster_category_type?: number;
}

export interface IAssignGetsterCategory {
  id?: number;
  getster_id: number;
  getster_category_id: string;
}
