export interface IUserAppEducationalInstitutionsCategory {
  country_code: string;
  user_app_educational_institution_category_id: string;
  parent_user_app_educational_institution_category_id?: string | null;
  user_app_educational_institution_category_name: string;
  is_user_app_educational_institution_category_hidden?: boolean;
  children?: IUserAppEducationalInstitutionsCategory[];
  user_app_educational_institution_category_type?: number;
}

export interface IAssignUserAppEducationalInstitutionsCategory {
  id?: number;
  user_app_educational_institution_category_id: string;
  getster_app_id: string;
}
