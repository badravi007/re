export interface IGetsterAppCategory {
  getster_app_category_id: string;
  parent_getster_app_category_id?: string | null;
  getster_app_category_name: string;
  is_the_getster_app_category_hidden?: boolean;
  children?: IGetsterAppCategory[];
  getster_app_category_type?: number;
  time_zone_iana_string?: string;
}

export interface IAssignGETsterCategory {
  id?: number;
  getster_app_category_id: string;
  getster_app_id: string;
  getster_app_location_within_the_category_id: string;
}
