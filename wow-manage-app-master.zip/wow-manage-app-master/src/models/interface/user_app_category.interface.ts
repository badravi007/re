export interface IUserAppCategory {
  user_app_category_id: string;
  parent_user_app_category_id?: string | null;
  user_app_category_name: string;
  is_the_user_app_category_hidden?: boolean;
  children?: IUserAppCategory[];
  user_app_category_type?: number;
}

export interface IAssignUserAppCategory {
  id?: number;
  user_app_category_id: string;
  user_app_id: string;
  getster_app_location_within_the_category_id: string;
}
