/* eslint-disable prettier/prettier */
export enum FileOrFolderEnum {
  is_folder = 1,
  is_file = 0,
}

export enum FileTypeEnum {
  default = 0,//unknown file type
  image = 1,//(jpg, png...)
  text = 2,//(note pad, word)
  spreadsheet = 3,//(google sheet, ms excel)
}
