import { ApiProperty } from '@nestjs/swagger';

export class GenericLaunchScreenImages {
  @ApiProperty()
  generic_image_id: number;

  @ApiProperty()
  generic_image_name: string;

  @ApiProperty()
  generic_image_storage_path: string;

  @ApiProperty()
  deleted_status: boolean;

  @ApiProperty()
  default_text_colour: string;
}

export class GenericLaunchScreenImagesWithAuditTrail extends GenericLaunchScreenImages {
  @ApiProperty()
  entry_by_user_id: number;

  @ApiProperty()
  entry_type: string;

  @ApiProperty()
  entry_local_date_time: string;
}
