import { ApiProperty } from '@nestjs/swagger';

export class AuditTrailForGenericLaunchScreenImagesDto {
  @ApiProperty()
  generic_image_id: number;

  @ApiProperty()
  entry_type: number;

  @ApiProperty()
  entry_by_user_id: number;

  @ApiProperty()
  entry_local_date_time: number;
}
