import { ApiProperty } from '@nestjs/swagger';

export class BusinessSpecificLaunchScreenImages {
  @ApiProperty()
  business_category_image_id: number;

  @ApiProperty()
  user_app_business_category_id: string;

  @ApiProperty()
  business_category_image_name: string;

  @ApiProperty()
  business_category_image_storage_path: string;

  @ApiProperty()
  uploaded_by_user_id: number;

  @ApiProperty()
  upload_datetime: string;

  @ApiProperty()
  deleted_status: boolean;

  @ApiProperty()
  default_text_colour: string;
}

export class BusinessSpecificLaunchScreenImagesWithAuditTrail extends BusinessSpecificLaunchScreenImages {
  @ApiProperty()
  entry_by_user_id: number;

  @ApiProperty()
  entry_type: string;

  @ApiProperty()
  entry_local_date_time: string;
}
