import {
  Body,
  Controller,
  Delete,
  Get,
  HttpStatus,
  Post,
  Put,
  Query,
  UploadedFile,
  UseGuards,
  UseInterceptors,
} from '@nestjs/common';
import { FileInterceptor } from '@nestjs/platform-express';
import { ApiBearerAuth, ApiBody, ApiConsumes, ApiTags } from '@nestjs/swagger';
import ResponseInterface from 'src/common/interface/response.interface';
import { diskStorage } from 'multer';
import {
  editFileName,
  imageFileFilter,
} from 'src/shared/utils/file-upload.utils';
import { BusinessSpecificLaunchScreenImagesWithAuditTrail } from '../dto/business_specific_launch_screen_images.dto';
import { Business_specific_launch_screen_imagesService } from './business_specific_launch_screen_images.service';
import { JwtAuthGuard } from 'src/auth/guard/jwt-auth.guard';

@UseGuards(JwtAuthGuard)
@ApiTags('Business Specific Launch Screen Images')
@ApiBearerAuth('JWT-auth')
@Controller('business_specific_launch_screen_image')
export class Business_specific_launch_screen_imagesController {
  constructor(
    private readonly custom_app_masterService: Business_specific_launch_screen_imagesService,
  ) {}

  @Post('/add_business_specific_launch_screen_images')
  @ApiConsumes('multipart/form-data')
  @ApiBody({
    schema: {
      type: 'object',
      properties: {
        business_category_image_id: { type: 'number' },
        user_app_business_category_id: { type: 'string' },
        business_category_image_name: { type: 'string' },
        business_category_image_storage_path: { type: 'string' },
        entry_by_user_id: { type: 'number' },
        upload_datetime: { type: 'string' },
        deleted_status: { type: 'boolean' },
        default_text_colour: { type: 'string' },
        entry_local_date_time: { type: 'string' },
        image: {
          type: 'string',
          format: 'binary',
        },
      },
    },
  })
  @UseInterceptors(
    FileInterceptor('image', {
      storage: diskStorage({
        destination: './src/assets/business_images',
        filename: editFileName,
      }),
      fileFilter: imageFileFilter,
    }),
  )
  async insertBusinessSpecificLaunchScreenImage(
    @UploadedFile() file,
    @Body()
    genericLaunchScreenImagesDto: BusinessSpecificLaunchScreenImagesWithAuditTrail,
  ): Promise<ResponseInterface> {
    const data = {
      business_category_image_id:
        genericLaunchScreenImagesDto.business_category_image_id,
      user_app_business_category_id:
        genericLaunchScreenImagesDto.user_app_business_category_id,
      business_category_image_name:
        genericLaunchScreenImagesDto.business_category_image_name,
      business_category_image_storage_path:
        genericLaunchScreenImagesDto.business_category_image_storage_path,
      uploaded_by_user_id: genericLaunchScreenImagesDto.entry_by_user_id,
      upload_datetime: genericLaunchScreenImagesDto.upload_datetime,
      deleted_status: genericLaunchScreenImagesDto.deleted_status,
      default_text_colour: genericLaunchScreenImagesDto.default_text_colour,
      entry_by_user_id: genericLaunchScreenImagesDto.entry_by_user_id,
      entry_type: 'Add New',
      entry_local_date_time: genericLaunchScreenImagesDto.entry_local_date_time,
    };

    const result =
      await this.custom_app_masterService.insertBusinessSpecificLaunchScreenImage(
        data,
      );
    return {
      statusCode: 200,
      message: `Created Successfully!`,
      data: result,
    };
  }

  @Put('/update_business_specific_launch_screen_images')
  @ApiConsumes('multipart/form-data')
  @ApiBody({
    schema: {
      type: 'object',
      properties: {
        business_category_image_id: { type: 'number' },
        user_app_business_category_id: { type: 'string' },
        business_category_image_name: { type: 'string' },
        business_category_image_storage_path: { type: 'string' },
        entry_by_user_id: { type: 'number' },
        upload_datetime: { type: 'string' },
        deleted_status: { type: 'boolean' },
        default_text_colour: { type: 'string' },
        entry_local_date_time: { type: 'string' },
        image: {
          type: 'string',
          format: 'binary',
        },
      },
    },
  })
  @UseInterceptors(
    FileInterceptor('image', {
      storage: diskStorage({
        destination: './src/assets/business_images',
        filename: editFileName,
      }),
      fileFilter: imageFileFilter,
    }),
  )
  async updateBusinessSpecificLaunchScreenImage(
    @UploadedFile() file,
    @Body()
    genericLaunchScreenImagesDto: BusinessSpecificLaunchScreenImagesWithAuditTrail,
  ): Promise<ResponseInterface> {
    const data = {
      business_category_image_id:
        genericLaunchScreenImagesDto.business_category_image_id,
      user_app_business_category_id:
        genericLaunchScreenImagesDto.user_app_business_category_id,
      business_category_image_name:
        genericLaunchScreenImagesDto.business_category_image_name,
      business_category_image_storage_path: file.filename,
      uploaded_by_user_id: genericLaunchScreenImagesDto.entry_by_user_id,
      upload_datetime: genericLaunchScreenImagesDto.upload_datetime,
      deleted_status: genericLaunchScreenImagesDto.deleted_status,
      default_text_colour: genericLaunchScreenImagesDto.default_text_colour,
      entry_by_user_id: genericLaunchScreenImagesDto.entry_by_user_id,
      entry_type: 'Add New',
      entry_local_date_time: genericLaunchScreenImagesDto.entry_local_date_time,
    };

    const result =
      await this.custom_app_masterService.updateBusinessSpecificLaunchScreenImage(
        data,
      );
    return {
      statusCode: 200,
      message: `Updated Successfully!`,
      data: result,
    };
  }

  @Delete('/delete_business_specific_launch_screen_image')
  async deleteBusinessSpecificLaunchScreenImage(
    @Query('business_category_image_id') business_category_image_id: number,
    @Query('entry_by_user_id') entry_by_user_id: number,
    @Query('entry_local_date_time') entry_local_date_time: string,
  ): Promise<ResponseInterface> {
    const result =
      await this.custom_app_masterService.deleteBusinessSpecificLaunchScreenImage(
        business_category_image_id,
        entry_by_user_id,
        entry_local_date_time,
      );
    return {
      statusCode: HttpStatus.CREATED,
      message: 'Deleted successful !!',
      data: result,
    };
  }

  @Get('/get_all_business_specific_launch_screen_images')
  async getAllBusinessSpecificLaunchScreenImages(): Promise<any> {
    const result =
      await this.custom_app_masterService.getAllBusinessSpecificLaunchScreenImages();
    return {
      statusCode: 200,
      message: `Get Successfully.`,
      data: result,
    };
  }

  @Get('/get_business_specific_launch_screen_images_by_category_id?')
  async getBusinessSpecificLaunchScreenImagesById(
    @Query('user_app_business_category_id')
    user_app_business_category_id: string,
  ): Promise<any> {
    const result =
      await this.custom_app_masterService.getBusinessSpecificLaunchScreenImagesByCategoryId(
        user_app_business_category_id,
      );
    return {
      statusCode: 200,
      message: `Get Successfully!`,
      data: result,
    };
  }

  @Get('/get_all_business_specific_launch_screen_images_audit_trail')
  async getALlBusinessSpecificLaunchScreenImagesAuditTrail(): Promise<any> {
    const result =
      await this.custom_app_masterService.getALlBusinessSpecificLaunchScreenImagesAuditTrail();
    return {
      statusCode: 200,
      message: `Get Audit Trail Successfully!`,
      data: result,
    };
  }
}
