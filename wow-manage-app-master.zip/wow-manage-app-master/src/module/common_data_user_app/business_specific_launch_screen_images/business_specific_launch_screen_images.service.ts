/*
https://docs.nestjs.com/providers#services
*/

import { Injectable } from '@nestjs/common';
import { InjectConnection, InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { AuditTrailForBusinessSpecificLaunchScreenImagesDto } from '../dto/audit_trail_for_business_specific_launch_screen_images.dto';
import { BusinessSpecificLaunchScreenImagesWithAuditTrail } from '../dto/business_specific_launch_screen_images.dto';
import { GenericLaunchScreenImagesWithAuditTrail } from '../dto/generic_launch_screen_images.dto';
import { AuditTrailForBusinessSpecificLaunchScreenImages } from '../entity/audit_trail_for_business_specific_launch_screen_images.entity';
import { AuditTrailForGenericLaunchScreenImages } from '../entity/audit_trail_for_generic_launch_screen_images.entity';
import { BusinessSpecificLaunchScreenImages } from '../entity/business_specific_launch_screen_images.entity';
import { GenericLaunchScreenImages } from '../entity/generic_launch_screen_images.entity';

@Injectable()
export class Business_specific_launch_screen_imagesService {
  constructor(
    @InjectRepository(
      BusinessSpecificLaunchScreenImages,
      'user_apps_common_data_db',
    )
    @InjectConnection('user_apps_common_data_db')
    private readonly businessSpecificLaunchScreenImagesRepository: Repository<BusinessSpecificLaunchScreenImages>,
  ) {}

  async insertBusinessSpecificLaunchScreenImage(
    genericLaunchScreenImagesDto: BusinessSpecificLaunchScreenImagesWithAuditTrail,
  ): Promise<any> {
    const data = {
      business_category_image_id:
        genericLaunchScreenImagesDto.business_category_image_id,
      user_app_business_category_id:
        genericLaunchScreenImagesDto.user_app_business_category_id,
      business_category_image_name:
        genericLaunchScreenImagesDto.business_category_image_name,
      business_category_image_storage_path:
        genericLaunchScreenImagesDto.business_category_image_storage_path,
      uploaded_by_user_id: genericLaunchScreenImagesDto.entry_by_user_id,
      upload_datetime: genericLaunchScreenImagesDto.upload_datetime,
      deleted_status: genericLaunchScreenImagesDto.deleted_status,
      default_text_colour: genericLaunchScreenImagesDto.default_text_colour,
    };

    let result = await this.businessSpecificLaunchScreenImagesRepository.save(
      data,
    );

    let body = {
      id: 0,
      business_category_image_id: result.business_category_image_id,
      entry_type: 'Add New',
      entry_by_user_id: genericLaunchScreenImagesDto.entry_by_user_id,
      entry_local_date_time: genericLaunchScreenImagesDto.entry_local_date_time,
    };

    await this.insertBusinessSpecificLaunchScreenImageAuditTrail(body);

    return result;
  }

  async insertBusinessSpecificLaunchScreenImageAuditTrail(
    customAppAuditTrailDto: AuditTrailForBusinessSpecificLaunchScreenImagesDto,
  ): Promise<any> {
    try {
      return await this.businessSpecificLaunchScreenImagesRepository.query(`
          insert into user_apps_common_data_db.audit_trail_for_business_specific_launch_screen_images values(
            0,'${customAppAuditTrailDto.entry_type}',
            '${customAppAuditTrailDto.entry_by_user_id}',
            '${customAppAuditTrailDto.entry_local_date_time}',
            '${customAppAuditTrailDto.business_category_image_id}'
          )
          `);
    } catch (err) {
      throw err;
    }
  }

  async updateBusinessSpecificLaunchScreenImage(
    genericLaunchScreenImagesDto: BusinessSpecificLaunchScreenImagesWithAuditTrail,
  ): Promise<any> {
    let result = await this.businessSpecificLaunchScreenImagesRepository.query(
      `update user_apps_common_data_db.business_specific_launch_screen_images set 
      business_category_image_name ='${genericLaunchScreenImagesDto.business_category_image_name}', 
      business_category_image_storage_path ='${genericLaunchScreenImagesDto.business_category_image_storage_path}', 
      default_text_colour ='${genericLaunchScreenImagesDto.default_text_colour}'
      where  business_category_image_id=${genericLaunchScreenImagesDto.business_category_image_id};`,
    );

    let body = {
      id: 0,
      business_category_image_id:
        genericLaunchScreenImagesDto.business_category_image_id,
      entry_type: 'Edit',
      entry_by_user_id: genericLaunchScreenImagesDto.entry_by_user_id,
      entry_local_date_time: genericLaunchScreenImagesDto.entry_local_date_time,
    };
    await this.insertBusinessSpecificLaunchScreenImageAuditTrail(body);

    return result;
  }

  async deleteBusinessSpecificLaunchScreenImage(
    business_category_image_id: number,
    entry_by_user_id: number,
    entry_local_date_time: string,
  ): Promise<any> {
    let result = await this.businessSpecificLaunchScreenImagesRepository.query(
      `update user_apps_common_data_db.business_specific_launch_screen_images set deleted_status = true where  business_category_image_id = ${business_category_image_id}`,
    );

    let body = {
      id: 0,
      business_category_image_id: business_category_image_id,
      entry_type: 'Delete',
      entry_by_user_id: entry_by_user_id,
      entry_local_date_time: entry_local_date_time,
    };
    await this.insertBusinessSpecificLaunchScreenImageAuditTrail(body);

    return result;
  }

  async getBusinessSpecificLaunchScreenImagesByCategoryId(
    user_app_business_category_id: string,
  ): Promise<any> {
    try {
      return this.businessSpecificLaunchScreenImagesRepository.query(
        `select * from user_apps_common_data_db.business_specific_launch_screen_images where user_app_business_category_id='${user_app_business_category_id}' and deleted_status ='false'`,
      );
    } catch (err) {
      throw err;
    }
  }
  async getAllBusinessSpecificLaunchScreenImages(): Promise<any> {
    try {
      return this.businessSpecificLaunchScreenImagesRepository.query(
        `select * from user_apps_common_data_db.business_specific_launch_screen_images;`,
      );
    } catch (err) {
      throw err;
    }
  }

  async getALlBusinessSpecificLaunchScreenImagesAuditTrail(): Promise<any> {
    try {
      let images = await this.businessSpecificLaunchScreenImagesRepository
        .query(`
      SELECT * FROM user_apps_common_data_db.audit_trail_for_business_specific_launch_screen_images;`);
      let result: any[] = [];
      for (let i = 0; i < images.length; i++) {
        let audit_trail_for_business_specific_launch_screen_images = await this
          .businessSpecificLaunchScreenImagesRepository.query(`
          SELECT * FROM user_apps_common_data_db.business_specific_launch_screen_images where business_category_image_id = '${images[i].business_category_image_id}';`);
        if (audit_trail_for_business_specific_launch_screen_images.length > 0) {
          result.push({
            business_category_image_id: images[i].business_category_image_id,
            entry_type: images[i].entry_type,
            entry_local_date_time: images[i].entry_local_date_time,
            entry_by_user_id: images[i].entry_by_user_id,
            business_category_image_name:
              audit_trail_for_business_specific_launch_screen_images[0]
                .business_category_image_name,
          });
        }
      }
      return result;
    } catch (err) {
      throw err;
    }
  }
}
