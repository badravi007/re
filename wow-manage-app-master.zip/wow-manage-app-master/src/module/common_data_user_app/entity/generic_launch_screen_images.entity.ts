import { Column, Entity, PrimaryGeneratedColumn } from 'typeorm';

@Entity({
  database: 'user_apps_common_data_db',
  name: 'generic_launch_screen_images',
})
export class GenericLaunchScreenImages {
  @PrimaryGeneratedColumn('increment')
  generic_image_id: number;

  @Column({
    type: 'varchar',
    length: 100,
  })
  generic_image_name: string;

  @Column({
    type: 'varchar',
    length: 100,
  })
  generic_image_storage_path: string;

  @Column()
  deleted_status: boolean;

  @Column({
    type: 'varchar',
    length: 7,
  })
  default_text_colour: string;
}
