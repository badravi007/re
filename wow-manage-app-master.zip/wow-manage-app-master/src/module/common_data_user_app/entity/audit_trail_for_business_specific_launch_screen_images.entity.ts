import { Column, Entity, PrimaryGeneratedColumn } from 'typeorm';

@Entity({
  database: 'user_apps_common_data_db',
  name: 'audit_trail_for_business_specific_launch_screen_images',
})
export class AuditTrailForBusinessSpecificLaunchScreenImages {
  @PrimaryGeneratedColumn('increment')
  id: number;

  @Column({
    type: 'varchar',
    length: 20,
  })
  business_category_image_id: string;

  @Column({
    type: 'varchar',
    length: 100,
  })
  entry_type: string;

  @Column({
    type: 'varchar',
    length: 100,
  })
  entry_by_user_id: string;

  @Column({
    type: 'varchar',
    length: 30,
  })
  entry_local_date_time: string;
}
