import { Column, Entity, PrimaryGeneratedColumn } from 'typeorm';

@Entity({
  database: 'user_apps_common_data_db',
  name: 'business_specific_launch_screen_images',
})
export class BusinessSpecificLaunchScreenImages {
  @PrimaryGeneratedColumn('increment')
  business_category_image_id: number;

  @Column({
    type: 'varchar',
    length: 20,
  })
  user_app_business_category_id: string;

  @Column({
    type: 'varchar',
    length: 100,
  })
  business_category_image_name: string;

  @Column({
    type: 'varchar',
    length: 100,
  })
  business_category_image_storage_path: string;

  @Column()
  uploaded_by_user_id: number;

  @Column({
    type: 'varchar',
    length: 30,
  })
  upload_datetime: string;

  @Column()
  deleted_status: boolean;

  @Column({
    type: 'varchar',
    length: 7,
  })
  default_text_colour: string;
}
