/*
https://docs.nestjs.com/providers#services
*/

import { Injectable } from '@nestjs/common';
import { InjectConnection, InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import {
  GenericLaunchScreenImages,
  GenericLaunchScreenImagesWithAuditTrail,
} from '../dto/generic_launch_screen_images.dto';
import { AuditTrailForGenericLaunchScreenImages } from '../entity/audit_trail_for_generic_launch_screen_images.entity';

@Injectable()
export class Generic_launch_screen_imagesService {
  constructor(
    @InjectRepository(GenericLaunchScreenImages, 'user_apps_common_data_db')
    @InjectConnection('user_apps_common_data_db')
    private readonly genericLaunchScreenImagesRepository: Repository<GenericLaunchScreenImages>,
  ) {}

  async insertGenericLaunchScreenImage(
    genericLaunchScreenImagesDto: GenericLaunchScreenImagesWithAuditTrail,
  ): Promise<any> {
    // let result: any = await this.genericLaunchScreenImagesRepository.query(
    //   `insert into user_apps_common_data_db.generic_launch_screen_images values(
    //             0,'${genericLaunchScreenImagesDto.generic_image_name}',
    //             '${genericLaunchScreenImagesDto.generic_image_storage_path}',
    //              ${genericLaunchScreenImagesDto.deleted_status},
    //             '${genericLaunchScreenImagesDto.default_text_colour}'
    //             );`,
    // );

    const data = {
      generic_image_id: genericLaunchScreenImagesDto.generic_image_id,
      generic_image_name: genericLaunchScreenImagesDto.generic_image_name,
      generic_image_storage_path:
        genericLaunchScreenImagesDto.generic_image_storage_path,
      deleted_status: genericLaunchScreenImagesDto.deleted_status,
      default_text_colour: genericLaunchScreenImagesDto.default_text_colour,
    };

    let result = await this.genericLaunchScreenImagesRepository.save(data);

    let body = {
      id: 0,
      generic_image_id: result.generic_image_id,
      entry_type: 'Add New',
      entry_by_user_id: genericLaunchScreenImagesDto.entry_by_user_id,
      entry_local_date_time: genericLaunchScreenImagesDto.entry_local_date_time,
    };

    await this.insertGenericLaunchScreenImageAuditTrail(body);

    return result;
  }

  async insertGenericLaunchScreenImageAuditTrail(
    customAppAuditTrailDto: AuditTrailForGenericLaunchScreenImages,
  ): Promise<any> {
    try {
      return await this.genericLaunchScreenImagesRepository.query(`
          insert into user_apps_common_data_db.audit_trail_for_generic_launch_screen_images values(
            0,'${customAppAuditTrailDto.generic_image_id}',
            '${customAppAuditTrailDto.entry_type}',
            '${customAppAuditTrailDto.entry_local_date_time}',
            '${customAppAuditTrailDto.entry_by_user_id}'
          )
          `);
    } catch (err) {
      throw err;
    }
  }

  async updateGenericLaunchScreenImage(
    genericLaunchScreenImagesDto: GenericLaunchScreenImagesWithAuditTrail,
  ): Promise<any> {
    let result = await this.genericLaunchScreenImagesRepository.query(
      `update user_apps_common_data_db.generic_launch_screen_images set 
          generic_image_name ='${genericLaunchScreenImagesDto.generic_image_name}', 
          generic_image_storage_path ='${genericLaunchScreenImagesDto.generic_image_storage_path}', 
          default_text_colour ='${genericLaunchScreenImagesDto.default_text_colour}'
          where generic_image_id=${genericLaunchScreenImagesDto.generic_image_id};`,
    );

    let body = {
      id: 0,
      generic_image_id: genericLaunchScreenImagesDto.generic_image_id,
      entry_type: 'Edit',
      entry_by_user_id: genericLaunchScreenImagesDto.entry_by_user_id,
      entry_local_date_time: genericLaunchScreenImagesDto.entry_local_date_time,
    };
    await this.insertGenericLaunchScreenImageAuditTrail(body);

    return result;
  }

  async deleteGenericLaunchScreenImage(
    generic_image_id: number,
    entry_by_user_id: number,
    entry_local_date_time: string,
  ): Promise<any> {
    // let result = await this.genericLaunchScreenImagesRepository.query(
    //   `delete from user_apps_common_data_db.generic_launch_screen_images where  generic_image_id = ${generic_image_id}`,
    // );
    let result = await this.genericLaunchScreenImagesRepository.query(
      `update user_apps_common_data_db.generic_launch_screen_images set deleted_status = true where generic_image_id = ${generic_image_id}`,
    );

    let body = {
      id: 0,
      generic_image_id: generic_image_id,
      entry_type: 'Delete',
      entry_by_user_id: entry_by_user_id,
      entry_local_date_time: entry_local_date_time,
    };
    await this.insertGenericLaunchScreenImageAuditTrail(body);

    return result;
  }

  async getGenericLaunchScreenImagesById(
    generic_image_id: number,
  ): Promise<any> {
    try {
      return this.genericLaunchScreenImagesRepository.query(
        `select * from user_apps_common_data_db.generic_launch_screen_images where generic_image_id= ${generic_image_id}`,
      );
    } catch (err) {
      throw err;
    }
  }
  async getAllGenericLaunchScreenImages(): Promise<any> {
    try {
      return this.genericLaunchScreenImagesRepository.query(
        `select * from user_apps_common_data_db.generic_launch_screen_images where deleted_status = 0;;`,
      );
    } catch (err) {
      throw err;
    }
  }

  async getALlGenericLaunchScreenImagesAuditTrail(): Promise<any> {
    try {
      let images = await this.genericLaunchScreenImagesRepository.query(`
      SELECT * FROM user_apps_common_data_db.audit_trail_for_generic_launch_screen_images;`);
      let result: any[] = [];
      for (let i = 0; i < images.length; i++) {
        let generic_image_name = await this.genericLaunchScreenImagesRepository
          .query(`
          SELECT * FROM user_apps_common_data_db.generic_launch_screen_images where  generic_image_id = '${images[i].generic_image_id}';`);
        if (generic_image_name.length > 0) {
          result.push({
            generic_image_id: images[i].generic_image_id,
            entry_type: images[i].entry_type,
            entry_local_date_time: images[i].entry_local_date_time,
            entry_by_user_id: images[i].entry_by_user_id,
            generic_image_name: generic_image_name[0].generic_image_name,
          });
        } else {
          result.push({
            generic_image_id: images[i].generic_image_id,
            entry_type: images[i].entry_type,
            entry_local_date_time: images[i].entry_local_date_time,
            entry_by_user_id: images[i].entry_by_user_id,
            generic_image_name: '',
          });
        }
      }
      return result;
    } catch (err) {
      throw err;
    }
  }
}
