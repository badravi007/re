/*
https://docs.nestjs.com/controllers#controllers
*/

import {
  Body,
  Controller,
  Delete,
  Get,
  HttpStatus,
  Post,
  Put,
  Query,
  UploadedFile,
  UseGuards,
  UseInterceptors,
} from '@nestjs/common';
import { FileInterceptor } from '@nestjs/platform-express';
import { ApiBearerAuth, ApiBody, ApiConsumes, ApiTags } from '@nestjs/swagger';
import ResponseInterface from 'src/common/interface/response.interface';
import { GenericLaunchScreenImagesWithAuditTrail } from '../dto/generic_launch_screen_images.dto';
import { Generic_launch_screen_imagesService } from './generic_launch_screen_images.service';
import { diskStorage } from 'multer';
import {
  editFileName,
  imageFileFilter,
} from 'src/shared/utils/file-upload.utils';
import { JwtAuthGuard } from 'src/auth/guard/jwt-auth.guard';

@UseGuards(JwtAuthGuard)
@ApiTags('Generic Launch Screen Images')
@ApiBearerAuth('JWT-auth')
@Controller('generic_launch_screen_image')
export class Generic_launch_screen_imagesController {
  constructor(
    private readonly custom_app_masterService: Generic_launch_screen_imagesService,
  ) {}

  @Post('/add_generic_launch_screen_images')
  @ApiConsumes('multipart/form-data')
  @ApiBody({
    schema: {
      type: 'object',
      properties: {
        generic_image_id: { type: 'number' },
        generic_image_name: { type: 'string' },
        generic_image_storage_path: { type: 'string' },
        deleted_status: { type: 'boolean' },
        default_text_colour: { type: 'string' },
        entry_by_user_id: { type: 'number' },
        entry_local_date_time: { type: 'string' },
        image: {
          type: 'string',
          format: 'binary',
        },
      },
    },
  })
  @UseInterceptors(
    FileInterceptor('image', {
      storage: diskStorage({
        destination: './src/assets/generic_images',
        filename: editFileName,
      }),
      fileFilter: imageFileFilter,
    }),
  )
  async createUserAppMaster(
    @UploadedFile() file,
    @Body() customAppMasterDto: GenericLaunchScreenImagesWithAuditTrail,
  ): Promise<ResponseInterface> {
    const data = {
      generic_image_id: customAppMasterDto.generic_image_id,
      generic_image_name: customAppMasterDto.generic_image_name,
      generic_image_storage_path: file.filename,
      deleted_status: customAppMasterDto.deleted_status,
      default_text_colour: customAppMasterDto.default_text_colour,
      entry_by_user_id: customAppMasterDto.entry_by_user_id,
      entry_type: 'Add New',
      entry_local_date_time: customAppMasterDto.entry_local_date_time,
    };

    const result =
      await this.custom_app_masterService.insertGenericLaunchScreenImage(data);
    return {
      statusCode: 200,
      message: `Created Successfully!`,
      data: result,
    };
  }

  @Put('/update_generic_launch_screen_images')
  @ApiConsumes('multipart/form-data')
  @ApiBody({
    schema: {
      type: 'object',
      properties: {
        generic_image_id: { type: 'number' },
        generic_image_name: { type: 'string' },
        generic_image_storage_path: { type: 'string' },
        deleted_status: { type: 'boolean' },
        default_text_colour: { type: 'string' },
        entry_by_user_id: { type: 'number' },
        entry_local_date_time: { type: 'string' },
        image: {
          type: 'string',
          format: 'binary',
        },
      },
    },
  })
  @UseInterceptors(
    FileInterceptor('image', {
      storage: diskStorage({
        destination: './src/assets/generic_images',
        filename: editFileName,
      }),
      fileFilter: imageFileFilter,
    }),
  )
  async updateUserAppMaster(
    @UploadedFile() file,
    @Body() customAppMasterDto: GenericLaunchScreenImagesWithAuditTrail,
  ): Promise<ResponseInterface> {
    const data = {
      generic_image_id: customAppMasterDto.generic_image_id,
      generic_image_name: customAppMasterDto.generic_image_name,
      generic_image_storage_path: file.filename,
      deleted_status: customAppMasterDto.deleted_status,
      default_text_colour: customAppMasterDto.default_text_colour,
      entry_by_user_id: customAppMasterDto.entry_by_user_id,
      entry_type: 'Edit',
      entry_local_date_time: customAppMasterDto.entry_local_date_time,
    };

    const result =
      await this.custom_app_masterService.updateGenericLaunchScreenImage(data);
    return {
      statusCode: 200,
      message: `Updated Successfully!`,
      data: result,
    };
  }

  @Delete('/delete_generic_launch_screen_image')
  async deleteGenericLaunchScreenImage(
    @Query('generic_image_id') generic_image_id: number,
    @Query('entry_by_user_id') entry_by_user_id: number,
    @Query('entry_local_date_time') entry_local_date_time: string,
  ): Promise<ResponseInterface> {
    const result =
      await this.custom_app_masterService.deleteGenericLaunchScreenImage(
        generic_image_id,
        entry_by_user_id,
        entry_local_date_time,
      );
    return {
      statusCode: HttpStatus.CREATED,
      message: 'Deleted successful !!',
      data: result,
    };
  }

  @Get('/get_all_generic_launch_screen_images')
  async getAllGenericLaunchScreenImages(): Promise<any> {
    const result =
      await this.custom_app_masterService.getAllGenericLaunchScreenImages();
    return {
      statusCode: 200,
      message: `Get Successfully.`,
      data: result,
    };
  }

  @Get('/get_generic_launch_screen_images_by_id?')
  async getGenericLaunchScreenImagesById(
    @Query('generic_image_id') generic_image_id: number,
  ): Promise<any> {
    const result =
      await this.custom_app_masterService.getGenericLaunchScreenImagesById(
        generic_image_id,
      );
    return {
      statusCode: 200,
      message: `Get Successfully!`,
      data: result,
    };
  }

  @Get('/get_all_generic_launch_screen_images_audit_trail')
  async getALlGenericLaunchScreenImagesAuditTrail(): Promise<any> {
    const result =
      await this.custom_app_masterService.getALlGenericLaunchScreenImagesAuditTrail();
    return {
      statusCode: 200,
      message: `Get Audit Trail Successfully!`,
      data: result,
    };
  }
}
