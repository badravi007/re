/*
https://docs.nestjs.com/modules
*/

import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { Business_specific_launch_screen_imagesController } from './business_specific_launch_screen_images/business_specific_launch_screen_images.controller';
import { Business_specific_launch_screen_imagesService } from './business_specific_launch_screen_images/business_specific_launch_screen_images.service';
import { AuditTrailForBusinessSpecificLaunchScreenImages } from './entity/audit_trail_for_business_specific_launch_screen_images.entity';
import { AuditTrailForGenericLaunchScreenImages } from './entity/audit_trail_for_generic_launch_screen_images.entity';
import { BusinessSpecificLaunchScreenImages } from './entity/business_specific_launch_screen_images.entity';
import { GenericLaunchScreenImages } from './entity/generic_launch_screen_images.entity';
import { Generic_launch_screen_imagesController } from './generic_launch_screen_images/generic_launch_screen_images.controller';
import { Generic_launch_screen_imagesService } from './generic_launch_screen_images/generic_launch_screen_images.service';

@Module({
  imports: [
    TypeOrmModule.forFeature(
      [
        GenericLaunchScreenImages,
        BusinessSpecificLaunchScreenImages,
        AuditTrailForGenericLaunchScreenImages,
        AuditTrailForBusinessSpecificLaunchScreenImages,
      ],
      'user_apps_common_data_db',
    ),
  ],
  controllers: [
    Generic_launch_screen_imagesController,
    Business_specific_launch_screen_imagesController,
  ],
  providers: [
    Business_specific_launch_screen_imagesService,
    Generic_launch_screen_imagesService,
  ],

  exports: [
    Business_specific_launch_screen_imagesService,
    Generic_launch_screen_imagesService,
  ],
})
export class Common_data_user_appModule {}
