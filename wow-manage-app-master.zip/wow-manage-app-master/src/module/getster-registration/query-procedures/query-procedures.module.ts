import { Module } from '@nestjs/common';
import { QP_CreateGetsterDynamicTables } from './qp_create-getster-dynamic-tables';

const procedures = [QP_CreateGetsterDynamicTables];
@Module({
  imports: [],
  providers: [...procedures],
  exports: [...procedures],
})
export class QueryProceduresModule {}
