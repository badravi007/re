import {
  ForbiddenException,
  Injectable,
  InternalServerErrorException,
} from '@nestjs/common';
import { Connection, getConnection } from 'typeorm';

@Injectable()
export class QP_CreateGetsterDynamicTables {
  dbConnection: Connection = getConnection();

  constructor() {}

  async createGetsterDynamicTable(getster_id: number) {
    try {
      // --1st Not exist then create 12_getster_id_home_screen_update_datetime table -----
      if (
        await this.tableExists(
          'manage_getsters_of_get_wow_education_db',
          `${getster_id}_getster_id_home_screen_update_datetime`,
        )
      ) {
        await this.dbConnection.query(`
            CREATE TABLE manage_getsters_of_get_wow_education_db.${getster_id}_getster_id_home_screen_update_datetime (
              getster_category_update_utc_datetime datetime NULL,
              getster_app_update_utc_datetime datetime NULL
            );
          `);
      }

      // --2st Not exist then create 12_getster_id_home_screen_recent_apps table -----
      if (
        await this.tableExists(
          'manage_getsters_of_get_wow_education_db',
          `${getster_id}_getster_id_home_screen_recent_apps`,
        )
      ) {
        await this.dbConnection.query(`
            CREATE TABLE manage_getsters_of_get_wow_education_db.${getster_id}_getster_id_home_screen_recent_apps (
              getster_app_id int not NULL,
              getster_app_icon_image varchar(100) NULL,
              getster_app_icon_name varchar(100) NULL
            );
          `);
      }

      // --3st Not exist then create 12_getster_id_home_screen_favourite_apps table -----
      if (
        await this.tableExists(
          'manage_getsters_of_get_wow_education_db',
          `${getster_id}_getster_id_home_screen_favourite_apps`,
        )
      ) {
        await this.dbConnection.query(`
            CREATE TABLE manage_getsters_of_get_wow_education_db.${getster_id}_getster_id_home_screen_favourite_apps (
              getster_app_id int not NULL,
              getster_app_icon_image varchar(100) NULL,
              getster_app_icon_name varchar(100) NULL
            );
          `);
      }

      // --4st Not exist then create 12_getster_id_home_screen_apps table -----
      if (
        await this.tableExists(
          'manage_getsters_of_get_wow_education_db',
          `${getster_id}_getster_id_home_screen_apps`,
        )
      ) {
        await this.dbConnection.query(`
            CREATE TABLE manage_getsters_of_get_wow_education_db.${getster_id}_getster_id_home_screen_apps (
              getster_app_category_id varchar(50) not NULL,
              parent_getster_app_category_id varchar(100) NULL,
              getster_app_category_name varchar(100) NULL,

              getster_app_id int not NULL,
              getster_app_icon_name varchar(100) NULL,
              getster_app_icon_image varchar(100) NULL,

              getster_app_location_within_the_category_id int NULL
            );
          `);
      }
    } catch (error) {
      if (error.status == 403) throw new ForbiddenException();
      throw new InternalServerErrorException();
    }
  }

  // -- Check The Table exist or not -----
  async tableExists(dbName: string, tableName: string): Promise<boolean> {
    try {
      const tableExists = await this.dbConnection.query(
        `
          SELECT *
            FROM information_schema.tables
            WHERE table_schema = '${dbName}'
                AND table_name = '${tableName}'
            LIMIT 1;
          `,
      );

      if (tableExists.length == 0) return true; //TABLE not exist then return true

      return false; //TABLE exist then return false
    } catch (error) {
      throw error;
    }
  }
}
