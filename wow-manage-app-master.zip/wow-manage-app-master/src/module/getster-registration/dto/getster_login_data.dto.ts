import { ApiProperty } from '@nestjs/swagger';

export class GetsterLoginDto {
  // getster_id: number;
  @ApiProperty()
  registered_mobile_country_code: string;
  @ApiProperty()
  registered_mobile_no: number;
  @ApiProperty()
  getster_password: string;
  @ApiProperty()
  getster_registration_login_approval_status: number;
  @ApiProperty()
  login_token_foreceful_invalidation_datetime: Date;
  @ApiProperty()
  getster_language_default: string;
  @ApiProperty()
  registration_datetime: Date;
  @ApiProperty()
  number_of_failed_attempts_for_the_day: number;
  @ApiProperty()
  login_block_datetime: Date;
}
