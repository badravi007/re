import { ApiProperty } from '@nestjs/swagger';
import { GetsterLoginDto } from './getster_login_data.dto';
export class GetsterProfileDto extends GetsterLoginDto {
  // getster_id: number;
  @ApiProperty()
  registered_mobile_country_code: string;
  @ApiProperty()
  registered_mobile_number: number;
  @ApiProperty()
  getster_registration_login_approval_status: number;
  @ApiProperty()
  first_name: string;
  @ApiProperty()
  last_name: string;
  @ApiProperty()
  date_of_birth: Date;
  @ApiProperty()
  getster_blood_group: string;
  @ApiProperty()
  gender: boolean;
  @ApiProperty()
  additional_getster_data_field_values: object;
  @ApiProperty()
  emergency_mobile_no: string;
  @ApiProperty()
  about_user: string;
  @ApiProperty()
  biz_card_company_details: object;
  @ApiProperty()
  biz_card_mobile_no: number;
  @ApiProperty()
  biz_card_phone_no: number;
  @ApiProperty()
  biz_card_website: string;
  @ApiProperty()
  biz_card_email_id: string;
  @ApiProperty()
  biz_card_address: string;
  @ApiProperty()
  biz_card_address_gps: string;
  @ApiProperty()
  first_login_image_of_the_day_update_datetime: Date;
  @ApiProperty()
  getster_category_id: string;
}
