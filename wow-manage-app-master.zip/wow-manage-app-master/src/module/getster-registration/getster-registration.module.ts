import { Module } from '@nestjs/common';
import { AuthModule } from 'src/auth/auth.module';
import { LoginRegisterController } from './login_register/login_register.controller';
import { LoginRegisterService } from './login_register/login_register.service';
import { QueryProceduresModule } from './query-procedures/query-procedures.module';

@Module({
  imports: [QueryProceduresModule, AuthModule],
  controllers: [LoginRegisterController],
  providers: [LoginRegisterService],
})
export class GetsterRegistrationModule {}
