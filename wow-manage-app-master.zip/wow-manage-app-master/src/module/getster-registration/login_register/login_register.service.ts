import {
  HttpException,
  HttpStatus,
  Injectable,
  NotFoundException,
} from '@nestjs/common';
import { DateTime } from 'luxon';
import * as mysql from 'mysql2';
import { AuthService } from 'src/auth/services/auth.service';
import { Role } from 'src/models/enum/role.enum';
import { Connection, getConnection } from 'typeorm';
import { GetsterProfileDto } from '../dto/getster_profile.dto';
import { QP_CreateGetsterDynamicTables } from './../query-procedures/qp_create-getster-dynamic-tables';
@Injectable()
export class LoginRegisterService {
  dbConnection: Connection = getConnection();
  constructor(
    private _QP_CreateGetsterDynamicTables: QP_CreateGetsterDynamicTables,
    private _authService: AuthService,
  ) {}
  async onAddRegisterLoginProfile(_data: GetsterProfileDto) {
    try {
      const {
        about_user,
        additional_getster_data_field_values,
        biz_card_address,
        biz_card_address_gps,
        biz_card_company_details,
        biz_card_email_id,
        biz_card_mobile_no,
        biz_card_phone_no,
        biz_card_website,
        date_of_birth,
        emergency_mobile_no,
        first_login_image_of_the_day_update_datetime,
        gender,
        first_name,
        getster_blood_group,
        getster_registration_login_approval_status,
        last_name,
        registered_mobile_country_code,
        registered_mobile_number,
        //
        getster_language_default,
        getster_password,
        login_block_datetime,
        login_token_foreceful_invalidation_datetime,
        number_of_failed_attempts_for_the_day,
        registered_mobile_no,
        registration_datetime,
        //
        getster_category_id,
      } = _data;

      const TimeZoneIanaString = 'Asia/Kolkata';
      const entry_date_time: any = DateTime.local({
        zone: TimeZoneIanaString,
      }).toFormat('yyyy-MM-dd TT');

      // getster_profile

      // await this.dbConnection.query(`
      //     INSERT INTO manage_getsters_of_get_wow_education_db.getster_profile
      //     (registered_mobile_country_code,
      //     registered_mobile_number,
      //     getster_registration_login_approval_status,
      //     first_name,
      //     last_name,
      //     date_of_birth,
      //     getster_blood_group,
      //     gender,
      //     additional_getster_data_field_values,
      //     emergency_mobile_no,
      //     about_user,
      //     biz_card_company_details,
      //     biz_card_mobile_no,
      //     biz_card_phone_no,
      //     biz_card_website,
      //     biz_card_email_id,
      //     biz_card_address,
      //     biz_card_address_gps,
      //     first_login_image_of_the_day_update_datetime)
      //     VALUES
      //     (${mysql.escape(registered_mobile_country_code)},
      //     ${mysql.escape(registered_mobile_number)},
      //     ${mysql.escape(getster_registration_login_approval_status)},
      //     ${mysql.escape(first_name)},
      //     ${mysql.escape(last_name)},
      //     ${mysql.escape(this.convertDateTime(date_of_birth).toString())},
      //     ${mysql.escape(getster_blood_group)},
      //     ${mysql.escape(gender)},
      //     ${mysql.escape(JSON.stringify(additional_getster_data_field_values))},
      //     ${mysql.escape(emergency_mobile_no)},
      //     ${mysql.escape(about_user)},
      //     ${mysql.escape(JSON.stringify(biz_card_company_details))},
      //     ${mysql.escape(biz_card_mobile_no)},
      //     ${mysql.escape(biz_card_phone_no)},
      //     ${mysql.escape(biz_card_website)},
      //     ${mysql.escape(biz_card_email_id)},
      //     ${mysql.escape(biz_card_address)},
      //     ${mysql.escape(biz_card_address_gps)},
      //     ${mysql.escape(
      //       this.convertDateTime(
      //         first_login_image_of_the_day_update_datetime,
      //       ).toString(),
      //     )});
      // `);

      await this.dbConnection.query(`
      INSERT INTO manage_getsters_of_get_wow_education_db.getster_profile
      (registered_mobile_country_code,
      registered_mobile_number,
      getster_registration_login_approval_status,
      first_name,
      last_name,
      date_of_birth,
      gender,
      additional_getster_data_field_values)
      VALUES
      (${mysql.escape(registered_mobile_country_code)},
      ${mysql.escape(registered_mobile_number)},
      ${mysql.escape(0)},
      ${mysql.escape(first_name)},
      ${mysql.escape(last_name)},
      ${mysql.escape(this.convertDateTime(date_of_birth).toString())},
      ${mysql.escape(gender)},
      ${mysql.escape(JSON.stringify(additional_getster_data_field_values))});
  `);

      const getsterId = await this.dbConnection
        .query(
          `
        SELECT getster_id FROM manage_getsters_of_get_wow_education_db.getster_profile
        ORDER BY getster_id desc limit 1
        `,
        )
        .then((data) => data[0].getster_id);

      //   await this.dbConnection.query(`
      //     INSERT INTO manage_getsters_of_get_wow_education_db.getster_login_data
      //     (getster_id,
      //     registered_mobile_country_code,
      //     registered_mobile_no,
      //     getster_password,
      //     getster_registration_login_approval_status,
      //     login_token_foreceful_invalidation_datetime,
      //     getster_language_default,
      //     registration_datetime,
      //     number_of_failed_attempts_for_the_day,
      //     login_block_datetime)
      //     VALUES
      //     (${mysql.escape(getsterId)},
      //     ${mysql.escape(registered_mobile_country_code)},
      //     ${mysql.escape(registered_mobile_no)},
      //     ${mysql.escape(getster_password)},
      //     ${mysql.escape(getster_registration_login_approval_status)},
      //     ${mysql.escape(
      //       this.convertDateTime(
      //         login_token_foreceful_invalidation_datetime,
      //       ).toString(),
      //     )},
      //     ${mysql.escape(getster_language_default)},
      //     ${mysql.escape(this.convertDateTime(registration_datetime).toString())},
      //     ${mysql.escape(number_of_failed_attempts_for_the_day)},
      //     ${mysql.escape(this.convertDateTime(login_block_datetime).toString())});
      // `);

      // getster_login_data
      const hashPassword = await this._authService.hashPassword(
        getster_password,
      );
      await this.dbConnection.query(`
      INSERT INTO manage_getsters_of_get_wow_education_db.getster_login_data
      (getster_id,
      registered_mobile_country_code,
      registered_mobile_no,
      getster_password,
      getster_registration_login_approval_status,
      registration_datetime)
      VALUES
      (${mysql.escape(getsterId)},
      ${mysql.escape(registered_mobile_country_code)},
      ${mysql.escape(registered_mobile_number)},
      ${mysql.escape(hashPassword)},
      ${mysql.escape(0)},
      ${mysql.escape(entry_date_time)})
  `);

      const getster_category_ids = getster_category_id.split(',');
      for (let i = 0; i < getster_category_ids.length; i++) {
        const element = getster_category_ids[i];
        await this.dbConnection.query(`
              INSERT INTO manage_getsters_of_get_wow_education_db.registered_users_registered_getster_categories
              (getster_id,
              getster_category_id)
              VALUES
              (${mysql.escape(getsterId)},
              ${mysql.escape(element)});
              `);
      }
      await this._QP_CreateGetsterDynamicTables
        .createGetsterDynamicTable(getsterId)
        .then(async () => {
          await this.onInsertGetsterAppsGetster(getsterId);
          await this.getsterAppUpdateStatus(getsterId);
        });
    } catch (error) {
      throw error;
    }
  }
  async onGetsterHomeScreenApps(getster_id: number) {
    try {
      const get_all_getster_apps = await this.dbConnection.query(`
        SELECT b.getster_app_category_id,c.parent_getster_app_category_id,c.getster_app_category_name,b.getster_app_id,d.getster_app_icon_name ,d.getster_app_icon_image,e.getster_app_location_within_the_category_id FROM manage_getsters_of_get_wow_education_db.registered_users_registered_getster_categories a
        left join manage_getsters_of_get_wow_education_db.getster_category_wise_app_access b on a.getster_category_id=b.getster_category_id
        left join wow_getster_app_db.getster_app_categories c on b.getster_app_category_id=c.getster_app_category_id
        left join wow_getster_app_db.getster_app_master d on d.getster_app_id=b.getster_app_id
        left join wow_getster_app_db.getster_apps_and_categories_assignment e on e.getster_app_id=b.getster_app_id AND  e.getster_app_category_id=b.getster_app_category_id
        where a.getster_id=${getster_id};
      `);

      let get_all_category = await this.dbConnection.query(
        `SELECT * FROM wow_getster_app_db.getster_app_categories;`,
      );

      let body: any[] = [];
      let main_count = 0;
      for (let i = 0; i < get_all_category.length; i++) {
        let getster_app_category_name =
          get_all_category[i].getster_app_category_name;
        let data: any[] = [];

        for (let j = 0; j < get_all_getster_apps.length; j++) {
          if (
            get_all_category[i].getster_app_category_id ===
            get_all_getster_apps[j].getster_app_category_id
          ) {
            data.push(get_all_getster_apps[j]);
          }
        }
        main_count++;
        if (main_count > i && data.length != 0) {
          body.push({
            getster_app_category_name: getster_app_category_name,
            data: data,
          });
        }
        getster_app_category_name = null;
        data = [null];
      }

      return body;
    } catch (error) {
      throw error;
    }
  }
  async onInsertGetsterAppsGetster(getster_id: number) {
    await this.dbConnection.query(`
            TRUNCATE manage_getsters_of_get_wow_education_db.${getster_id}_getster_id_home_screen_apps;
          `);
    await this.dbConnection.query(`
            TRUNCATE manage_getsters_of_get_wow_education_db.${getster_id}_getster_id_home_screen_update_datetime;
          `);
    await this.dbConnection.query(`
            TRUNCATE manage_getsters_of_get_wow_education_db.${getster_id}_getster_id_home_screen_recent_apps;
          `);
    await this.dbConnection.query(`
            TRUNCATE manage_getsters_of_get_wow_education_db.${getster_id}_getster_id_home_screen_favourite_apps;
          `);
    const _data = await this.dbConnection.query(`
      INSERT INTO manage_getsters_of_get_wow_education_db.${getster_id}_getster_id_home_screen_apps
      (getster_app_category_id,
      parent_getster_app_category_id,
      getster_app_category_name,
      getster_app_id,
      getster_app_icon_name,
      getster_app_icon_image,
      getster_app_location_within_the_category_id)
      SELECT b.getster_app_category_id,c.parent_getster_app_category_id,c.getster_app_category_name,b.getster_app_id,d.getster_app_icon_name ,d.getster_app_icon_image,e.getster_app_location_within_the_category_id FROM manage_getsters_of_get_wow_education_db.registered_users_registered_getster_categories a
      left join manage_getsters_of_get_wow_education_db.getster_category_wise_app_access b on a.getster_category_id=b.getster_category_id
      left join wow_getster_app_db.getster_app_categories c on b.getster_app_category_id=c.getster_app_category_id
      left join wow_getster_app_db.getster_app_master d on d.getster_app_id=b.getster_app_id
      left join wow_getster_app_db.getster_apps_and_categories_assignment e on e.getster_app_id=b.getster_app_id AND  e.getster_app_category_id=b.getster_app_category_id
      where a.getster_id=${getster_id};
    `);
  }

  async getsterAppUpdateStatus(getster_id: number) {
    let getster_category_update_utc_datetime = await this.dbConnection.query(`
    SELECT * FROM manage_getsters_of_get_wow_education_db.getster_category_update_status
    WHERE getster_category_update_utc_datetime
    `);

    let getster_app_update_utc_date_time = await this.dbConnection.query(`
    SELECT * FROM wow_getster_app_db.getster_app_update_status
    WHERE getster_app_update_utc_date_time
    `);

    let isFound = await this.dbConnection.query(`
    SELECT * FROM manage_getsters_of_get_wow_education_db.${getster_id}_getster_id_home_screen_update_datetime
    WHERE getster_category_update_utc_datetime = '${getster_category_update_utc_datetime[0].getster_category_update_utc_datetime}' AND getster_app_update_utc_datetime='${getster_app_update_utc_date_time[0].getster_app_update_utc_date_time}'
    `);

    if (isFound.length == 0) {
      await this.dbConnection.query(`

      INSERT INTO manage_getsters_of_get_wow_education_db.${getster_id}_getster_id_home_screen_update_datetime
      (getster_category_update_utc_datetime,
      getster_app_update_utc_datetime)
      VALUES
          (
            ${mysql.escape(
              getster_category_update_utc_datetime[0]
                .getster_category_update_utc_datetime,
            )},
            ${mysql.escape(
              getster_app_update_utc_date_time[0]
                .getster_app_update_utc_date_time,
            )}
          );
      `);
    } else {
      await this.dbConnection.query(`
        UPDATE manage_getsters_of_get_wow_education_db.${getster_id}_getster_id_home_screen_update_datetime
        SET
        getster_category_update_utc_datetime = ${mysql.escape(
          getster_category_update_utc_datetime[0]
            .getster_category_update_utc_datetime,
        )},
        getster_app_update_utc_datetime = ${mysql.escape(
          getster_app_update_utc_date_time[0].getster_app_update_utc_date_time,
        )}

        WHERE getster_category_update_utc_datetime = '${
          getster_category_update_utc_datetime[0]
            .getster_category_update_utc_datetime
        }' AND getster_app_update_utc_datetime='${
        getster_app_update_utc_date_time[0].getster_app_update_utc_date_time
      }'

      `);
    }
  }

  async checkTimeStampIsMatch(getster_id: number) {
    let getster_category_update_utc_datetime = await this.dbConnection.query(`
    SELECT * FROM manage_getsters_of_get_wow_education_db.getster_category_update_status
    WHERE getster_category_update_utc_datetime
    `);

    let getster_app_update_utc_date_time = await this.dbConnection.query(`
    SELECT * FROM wow_getster_app_db.getster_app_update_status
    WHERE getster_app_update_utc_date_time
    `);

    let isFound = await this.dbConnection.query(`
    SELECT * FROM manage_getsters_of_get_wow_education_db.${getster_id}_getster_id_home_screen_update_datetime
    WHERE getster_category_update_utc_datetime = '${getster_category_update_utc_datetime[0].getster_category_update_utc_datetime}' AND getster_app_update_utc_datetime='${getster_app_update_utc_date_time[0].getster_app_update_utc_date_time}'
    `);

    if (isFound.length == 0) return false;
    else return true;
  }

  // Login
  async onLoginWithRegisteredMobileNumber(
    registered_mobile_number: number,
    registered_mobile_country_code: number,
  ) {
    try {
      const _data = await this.dbConnection.query(`
        SELECT * FROM manage_getsters_of_get_wow_education_db.getster_login_data
        where registered_mobile_country_code=${mysql.escape(
          registered_mobile_country_code,
        )} AND registered_mobile_no=${mysql.escape(registered_mobile_number)}
      `);

      if (_data.length == 0)
        throw new NotFoundException('This Mobile Number Not Register!');
      else
        return {
          getster_id: _data[0].getster_id,
        };
    } catch (error) {
      throw error;
    }
  }
  async onLoginWithGetsterPassword(
    getster_id: number,
    getster_password: string,
  ) {
    try {
      const _data = await this.dbConnection.query(`
        SELECT * FROM manage_getsters_of_get_wow_education_db.getster_login_data
        where getster_id=${mysql.escape(getster_id)}
      `);
      console.log(Boolean(_data[0].getster_registration_login_approval_status));

      const getsterApprovalStatus =
        _data[0].getster_registration_login_approval_status;

      const compare = await this._authService.comparePasswords(
        getster_password,
        _data[0].getster_password,
      );
      if (getsterApprovalStatus == 0)
        throw new HttpException('Your not approved login!', HttpStatus.FOUND);

      if (compare) {
        const {
          getster_id,
          registered_mobile_country_code,
          registered_mobile_no,
          getster_password,
          getster_registration_login_approval_status,
          login_token_foreceful_invalidation_datetime,
          getster_language_default,
          registration_datetime,
          number_of_failed_attempts_for_the_day,
          login_block_datetime,
        } = _data[0];

        const payload = {
          getster_id,
          registered_mobile_country_code,
          roles: Role.Admin,
          time_zone_iana_string: 'Asia/Kolkata',
        };
        const generatorToken = await this._authService.generateJwt(payload);

        if (!(await this.checkTimeStampIsMatch(getster_id))) {
          await this.onInsertGetsterAppsGetster(getster_id);
          await this.getsterAppUpdateStatus(getster_id);
        }

        return generatorToken;
      } else {
        throw new HttpException(
          'Login was not successful, wrong credentials',
          HttpStatus.UNAUTHORIZED,
        );
      }
    } catch (error) {
      throw error;
    }
  }
  // ------------------------ Helper Function ------------------------
  convertDateTime(_date: Date): Date {
    const date = DateTime.fromISO(_date);
    // const date = DateTime.fromISO(_date).toFormat('yyyy LLL dd');
    return date;
  }
}
