import {
  Body,
  Controller,
  Get,
  HttpStatus,
  Post,
  Query,
  UseGuards,
} from '@nestjs/common';
import { Req } from '@nestjs/common/decorators';
import { ApiBearerAuth, ApiTags } from '@nestjs/swagger';
import { Request } from 'express';
import { JwtAuthGuard } from 'src/auth/guard/jwt-auth.guard';
import { AuthService } from 'src/auth/services/auth.service';
import ResponseInterface from 'src/common/interface/response.interface';
import { GetsterProfileDto } from '../dto/getster_profile.dto';
import { LoginRegisterService } from './login_register.service';

@ApiTags('Getster Register')
@Controller('manage-getster')
export class LoginRegisterController {
  constructor(
    private _loginRegisterService: LoginRegisterService,
    private _authService: AuthService,
  ) {}

  @Post('login-register')
  async onAddRegisterLoginProfile(@Body() _data: GetsterProfileDto) {
    try {
      await this._loginRegisterService.onAddRegisterLoginProfile(_data);
    } catch (error) {
      throw error;
    }
  }

  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth('JWT-auth')
  @Get('home-screen-apps')
  async onGetsterHomeScreenApps(
    @Req() request: Request,
  ): Promise<ResponseInterface> {
    try {
      let _data = await this._authService.verifyJwt(
        String(request.headers.authenticationtoken),
      );

      const data = await this._loginRegisterService.onGetsterHomeScreenApps(
        _data.user.getster_id,
      );

      return {
        message: 'Data get successful!',
        statusCode: 200,
        data,
      };
    } catch (error) {
      throw error;
    }
  }

  // Login
  @Get('login-with-registered-mobile-number')
  async onLoginWithRegisteredMobileNumber(
    @Query('registered_mobile_number') registered_mobile_number: number,
    @Query('registered_mobile_country_code')
    registered_mobile_country_code: number,
  ): Promise<ResponseInterface> {
    try {
      const data: any =
        await this._loginRegisterService.onLoginWithRegisteredMobileNumber(
          registered_mobile_number,
          registered_mobile_country_code,
        );

      return {
        statusCode: HttpStatus.OK,
        message: 'Data get successful',
        data: data,
      };
    } catch (error) {
      throw error;
    }
  }
  @Get('login-with-getster-password')
  async onLoginWithGetsterPassword(
    @Query('getster_id') getster_id: number,
    @Query('getster_password')
    getster_password: string,
  ): Promise<ResponseInterface> {
    try {
      const data: any =
        await this._loginRegisterService.onLoginWithGetsterPassword(
          getster_id,
          getster_password,
        );

      return {
        statusCode: HttpStatus.OK,
        message: 'Login successful',
        data: data,
      };
    } catch (error) {
      throw error;
    }
  }
}
