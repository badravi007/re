/*
https://docs.nestjs.com/controllers#controllers
*/

import {
  Body,
  Controller,
  Delete,
  Get,
  Param,
  Post,
  Put,
  Query,
  UseGuards,
} from '@nestjs/common';
import { AuthGuard } from '@nestjs/passport';
import { ApiBearerAuth, ApiTags } from '@nestjs/swagger';
import ResponseInterface from 'src/common/interface/response.interface';
import { PageApiDto } from '../dto/page_api.dto';
import { Page_apiService } from './page_api.service';

// @UseGuards(JwtAuthGuard)
@ApiTags('Paginated Api')
@ApiBearerAuth('JWT-auth')
@Controller('paginated_api')
export class Page_apiController {
  constructor(private readonly pageApiService: Page_apiService) {}

  @Post('/create_paginated_api')
  async createPaginatedApi(
    @Body() getsterCategory: PageApiDto,
  ): Promise<ResponseInterface> {
    const result = await this.pageApiService.createPaginatedApi(
      getsterCategory,
    );
    return {
      statusCode: 200,
      message: `Created Successfully!`,
      data: result,
    };
  }

  @Get('/get_all_paginated_api')
  async getAllPaginatedApi(
    @Query('page') page: number,
    @Query('limit') limit: number,
  ): Promise<any> {
    const result = await this.pageApiService.getAllPaginatedApi(page, limit);
    return {
      statusCode: 200,
      message: `Get List Successfully!`,
      data: result,
    };
  }
}
