/*
https://docs.nestjs.com/providers#services
*/
import { Injectable } from '@nestjs/common';
import { InjectConnection, InjectRepository } from '@nestjs/typeorm';
import { getRepository, Repository } from 'typeorm';

import { PageApiDto } from '../dto/page_api.dto';
import { PageApi } from '../entity/page_api.entity';

@Injectable()
export class Page_apiService {
  constructor(
    @InjectRepository(PageApi, 'in_manage_get_wow_education_db')
    @InjectConnection('in_manage_get_wow_education_db')
    private readonly paginatedApiRepository: Repository<PageApi>,
  ) {}

  async createPaginatedApi(getsterCategory: PageApiDto): Promise<PageApi> {
    try {
      // return await getRepository('student').save(getsterCategory);
      return await this.paginatedApiRepository.save(getsterCategory);
    } catch (err) {
      throw err;
    }
  }

  async getAllPaginatedApi(page: number, limit: number): Promise<PageApi> {
    let mysql = require('mysql2');
    try {
      return await this.paginatedApiRepository.query(
        `SELECT * FROM student where id > ${mysql.escape(
          page * limit,
        )}  LIMIT ${limit}`,
      );
    } catch (err) {
      throw err;
    }
  }
}

// return await this.paginatedApiRepository.query(
//   `SELECT * FROM student where id > `
//   + mysql.escape(page) + `*`
//   + mysql.escape(limit) + `LIMIT`
//   + mysql.escape(limit));
