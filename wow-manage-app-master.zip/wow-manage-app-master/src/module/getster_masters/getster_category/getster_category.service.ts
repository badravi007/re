/*
https://docs.nestjs.com/providers#services
*/

import { Injectable } from '@nestjs/common';
import { InjectConnection, InjectRepository } from '@nestjs/typeorm';
import { IGetsterCategory } from 'src/models/interface/getster_category.interface';
import { DateTimeService } from 'src/shared/service/date-time.service';
import { Repository } from 'typeorm';
import { GetsterCategory } from '../entity/getster_category.entity';
import * as mysql from 'mysql2';

@Injectable()
export class Getster_categoryService {
  constructor(
    @InjectRepository(GetsterCategory, 'in_manage_get_wow_education_db')
    @InjectConnection('in_manage_get_wow_education_db')
    private readonly getsterCategoryRepository: Repository<GetsterCategory>,
  ) {}
  async postCategory(category_details: IGetsterCategory) {
    try {
      await this.getsterCategoryRepository.query(`
            INSERT INTO in_manage_get_wow_education_db.getster_category (getster_category_id, parent_getster_category_id, getster_category_name, is_the_getster_category_hidden,getster_category_type) VALUES (
              ${mysql.escape(category_details.getster_category_id)},
              ${mysql.escape(category_details.parent_getster_category_id)}, 
              ${mysql.escape(category_details.getster_category_name)},
              ${mysql.escape(category_details.is_the_getster_category_hidden)},
              ${mysql.escape(category_details.getster_category_type)}
              );
            `);
    } catch (error) {
      throw error;
    }
  }

  async updateCategory(category_details: IGetsterCategory) {
    try {
      if (category_details.getster_category_name) {
        await this.getsterCategoryRepository.query(`
        UPDATE in_manage_get_wow_education_db.getster_category
        SET getster_category_name = ${mysql.escape(
          category_details.getster_category_name,
        )} WHERE 
        getster_category_id = '${category_details.getster_category_id}' `);
      }
    } catch (error) {
      throw error;
    }
  }

  async hideCategory(category_details: IGetsterCategory) {
    try {
      if (category_details.is_the_getster_category_hidden) {
        await this.getsterCategoryRepository.query(`
          UPDATE in_manage_get_wow_education_db.getster_category 
          SET is_the_getster_category_hidden = ${mysql.escape(
            category_details.is_the_getster_category_hidden,
          )} WHERE 
          getster_category_id = '${category_details.getster_category_id}' `);
      }
    } catch (error) {
      throw error;
    }
  }

  async GetAllCategories() {
    try {
      const TaskData = await this.getsterCategoryRepository.query(
        `SELECT * FROM in_manage_get_wow_education_db.getster_category order by id`,
      );
      // console.log(TaskData);

      let data;
      if (TaskData.length > 1) {
        data = await this.treeConstruct(TaskData);
        // console.log(data, "tree");

        return data;
      }
      // console.log(data);

      // console.log(TaskData, "taskdata");

      const obj = TaskData[0];
      const pair = { children: [] };
      const objData = { ...obj, ...pair };
      if (obj !== undefined) {
        return [objData];
      }
      return [];
    } catch (error) {
      throw error;
    }
  }

  treeConstruct(treeData) {
    let constructedTree = [];
    for (let i of treeData) {
      let treeObj = i;
      let assigned = false;
      this.constructTree(constructedTree, treeObj, assigned);
    }
    return constructedTree;
  }

  constructTree(constructedTree, treeObj, assigned) {
    if (treeObj.parent_getster_category_id == null) {
      treeObj.children = [];
      constructedTree.push(treeObj);
      return true;
    } else if (
      treeObj.parent_getster_category_id === constructedTree.getster_category_id
    ) {
      treeObj.children = [];
      constructedTree.children.push(treeObj);
      return true;
    } else {
      if (constructedTree.children != undefined) {
        for (let index = 0; index < constructedTree.children.length; index++) {
          let constructedObj = constructedTree.children[index];
          if (assigned == false) {
            assigned = this.constructTree(constructedObj, treeObj, assigned);
          }
        }
      } else {
        for (let index = 0; index < constructedTree.length; index++) {
          let constructedObj = constructedTree[index];
          if (assigned == false) {
            assigned = this.constructTree(constructedObj, treeObj, assigned);
          }
        }
      }
      return false;
    }
  }

  //

  async checkGetsterAssignedGetsterCategory(getster_category_id: string) {
    let datas: any[] = await this.getsterCategoryRepository.query(
      `select * from in_manage_get_wow_education_db.getster_category_wise_app_access where getster_category_id = ${mysql.escape(
        getster_category_id,
      )}`,
    );

    if (datas.length == 0) {
      return false;
    }
    return datas[0].user_id !== null ? true : false;
  }
}
