/*
https://docs.nestjs.com/controllers#controllers
*/

import {
  Body,
  Controller,
  Get,
  HttpStatus,
  Post,
  Put,
  Query,
} from '@nestjs/common';
import { ApiTags } from '@nestjs/swagger';
import { GetsterCategoryDto } from '../dto/getster_category.dto';
import { Getster_categoryService } from './getster_category.service';

// @UseGuards(JwtAuthGuard)
// @ApiBearerAuth('JWT-auth')
@ApiTags('GETster Category')
@Controller('getster_category')
export class Getster_categoryController {
  constructor(private _treeViewService: Getster_categoryService) {}

  @Post('add_getster_category')
  async addCategory(@Body() category: GetsterCategoryDto): Promise<any> {
    try {
      await this._treeViewService.postCategory(category);
      return {
        status: 200,
        message: 'Created Successfully',
      };
    } catch (error) {
      throw error;
    }
  }

  @Get('get_all_getster_category')
  async GetAllCategories(): Promise<any> {
    try {
      const tasksData = await this._treeViewService.GetAllCategories();
      return {
        status: HttpStatus.OK,
        message: 'Fetched Successfully',
        data: tasksData,
      };
    } catch (error) {
      throw error;
    }
  }

  @Put('update_getster_category')
  async updateCategory(@Body() category: GetsterCategoryDto): Promise<any> {
    try {
      await this._treeViewService.updateCategory(category);
      return {
        status: 200,
        message: 'Updated Successfully',
      };
    } catch (error) {
      throw error;
    }
  }

  @Put('hide_getster_category')
  async hideCategory(@Body() category: GetsterCategoryDto): Promise<any> {
    try {
      await this._treeViewService.hideCategory(category);
      return {
        status: 200,
        message: 'Hide Successfully',
      };
    } catch (error) {
      throw error;
    }
  }

  @Get('check_getster_is_assigned_getster_category')
  async checkGetsterAssignedGetsterCategory(
    @Query('getster_category_id') getster_category_id: string,
  ) {
    let info = await this._treeViewService.checkGetsterAssignedGetsterCategory(
      getster_category_id,
    );

    if (info == true) {
      return {
        status: 200,
        message:
          'User is present in this category in-order to hide parent category / sub category kindly reassign the user to another category',
        userIsAssigned: true,
      };
    } else if (info == false) {
      return {
        status: 200,
        message: 'User is not present in this category',
        userIsAssigned: false,
      };
    }
  }
}
