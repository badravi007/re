/*
https://docs.nestjs.com/modules
*/

import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { AuthModule } from 'src/auth/auth.module';
import { GetsterCategory } from './entity/getster_category.entity';
import { GetsterCategoryAdminAuditTrail } from './entity/getster_category_admin_audit_trail.entity';
import { GetsterCategoryUpdateStatus } from './entity/getster_category_update_status.entity';
import { GetsterCategoryWiseAdditionalFieldNames } from './entity/getster_category_wise_additional_field_names.entity';
import { GetsterCategoryWiseAppAccess } from './entity/getster_category_wise_app_access.entity';
import { GetsterIdLogin } from './entity/getster_id_login.entity';
import { GetsterProfile } from './entity/getster_profile.entity';
import { GetsterProfileAuditTrail } from './entity/getster_profile_audit_trail.entity';
import { PageApi } from './entity/page_api.entity';
import { RegisteredUserGetsterCategories } from './entity/registered_users_registered_getster_categories.entity';
import { Getster_categoryController } from './getster_category/getster_category.controller';
import { Getster_categoryService } from './getster_category/getster_category.service';
import { Getster_profileController } from './getster_profile/getster_profile.controller';
import { Getster_profileService } from './getster_profile/getster_profile.service';
import { Page_apiController } from './page-api/page_api.controller';
import { Page_apiService } from './page-api/page_api.service';

@Module({
  imports: [
    TypeOrmModule.forFeature(
      [
        RegisteredUserGetsterCategories,
        GetsterProfile,
        GetsterIdLogin,
        GetsterCategory,
        GetsterCategoryWiseAppAccess,
        GetsterCategoryWiseAdditionalFieldNames,
        GetsterCategoryUpdateStatus,
        PageApi,
        GetsterProfileAuditTrail,
        GetsterCategoryAdminAuditTrail,
      ],
      'in_manage_get_wow_education_db',
    ),
    AuthModule,
  ],
  controllers: [
    Getster_profileController,
    Page_apiController,
    Getster_categoryController,
  ],
  providers: [Getster_profileService, Page_apiService, Getster_categoryService],
  exports: [Getster_profileService, Page_apiService, Getster_categoryService],
})
export class Getster_masterModule {}
