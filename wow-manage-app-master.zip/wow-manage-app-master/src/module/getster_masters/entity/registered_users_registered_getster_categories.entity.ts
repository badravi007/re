import { Column, Entity, PrimaryColumn, PrimaryGeneratedColumn } from 'typeorm';

@Entity({
  database: 'in_manage_get_wow_education_db',
  name: 'registered_users_registered_getster_categories',
})
export class RegisteredUserGetsterCategories {
  @PrimaryGeneratedColumn('increment')
  id: number;

  @Column({
    nullable: false,
  })
  getster_id: number;

  @Column({
    nullable: false,
    length: 100,
  })
  getster_category_id: string;
}
