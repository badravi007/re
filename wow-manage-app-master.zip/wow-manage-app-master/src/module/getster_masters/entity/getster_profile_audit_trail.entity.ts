import { Column, Entity, PrimaryGeneratedColumn } from 'typeorm';

@Entity({
  database: 'in_manage_get_wow_education_db',
  name: 'getster_profile_audit_trail',
})
export class GetsterProfileAuditTrail {
  @PrimaryGeneratedColumn('increment')
  id: number;

  @Column()
  getster_id: number;

  @Column({ length: 50 })
  entry_type: string;

  @Column()
  entry_by_user_id: number;

  @Column({ length: 30 })
  entry_local_date_time: string;
}
