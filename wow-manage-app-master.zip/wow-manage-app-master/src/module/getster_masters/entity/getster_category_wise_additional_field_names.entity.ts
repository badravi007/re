import { Column, Entity, PrimaryColumn, PrimaryGeneratedColumn } from 'typeorm';

@Entity({
  database: 'in_manage_get_wow_education_db',
  name: 'getster_category_wise_additional_field_names',
})
export class GetsterCategoryWiseAdditionalFieldNames {
  @PrimaryGeneratedColumn('increment')
  id: number;

  @Column({
    length: 100,
  })
  getster_category_id: string;

  @Column({
    type: 'varchar',
    length: 1000,
  })
  additional_getster_data_field_name: string;

  @Column()
  location_of_user_required: boolean;
}
