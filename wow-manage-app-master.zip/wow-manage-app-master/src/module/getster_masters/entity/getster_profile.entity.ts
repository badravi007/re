import { Column, Entity, PrimaryColumn, PrimaryGeneratedColumn } from 'typeorm';

@Entity({ database: 'in_manage_get_wow_education_db', name: 'getster_profile' })
export class GetsterProfile {
  @PrimaryGeneratedColumn('increment')
  getster_id: number;

  @Column({
    type: 'varchar',
    length: 100,
    nullable: false,
  })
  first_name: string;

  @Column({
    nullable: false,
    type: 'varchar',
    length: 100,
  })
  last_name: string;

  @Column({
    nullable: false,
    type: 'varchar',
    length: 25,
  })
  date_of_birth: string;

  @Column({
    nullable: false,
    type: 'varchar',
    length: 25,
  })
  gender: string;

  @Column({
    type: 'varchar',
    length: 1000,
    nullable: true,
  })
  additional_getster_data_field_values: string;

  @Column({
    type: 'varchar',
    length: 100,
    nullable: true,
  })
  about_user: string;

  @Column({
    type: 'varchar',
    length: 1000,
    nullable: true,
  })
  biz_card_company_details: string;

  @Column({
    type: 'varchar',
    length: 1000,
    nullable: true,
  })
  biz_card_mobile_no: number;

  @Column({
    type: 'varchar',
    length: 1000,
    nullable: true,
  })
  biz_card_phone_no: number;

  @Column({
    type: 'varchar',
    length: 70,
    nullable: true,
  })
  biz_card_website: string;

  @Column({
    type: 'varchar',
    length: 100,
    nullable: true,
  })
  biz_card_email_id: string;

  @Column({
    type: 'varchar',
    length: 400,
    nullable: true,
  })
  biz_card_address: string;

  @Column({
    type: 'varchar',
    length: 100,
    nullable: true,
  })
  biz_card_address_gps: string;

  @Column({
    type: 'varchar',
    length: 100,
    nullable: true,
  })
  face_recognition_image_file: string;

  @Column({
    type: 'varchar',
    length: 30,
    nullable: true,
  })
  getster_registration_approval_date: string;

  @Column({
    type: 'varchar',
    length: 30,
    nullable: true,
  })
  getster_profile_update_date: string;
}
