import { Column, Entity, PrimaryGeneratedColumn } from 'typeorm';

@Entity({
  database: 'in_manage_get_wow_education_db',
  name: 'getster_category_admin_audit_trail',
})
export class GetsterCategoryAdminAuditTrail {
  @PrimaryGeneratedColumn('increment')
  id: number;

  @Column()
  getster_category_id: string;

  @Column({ length: 50 })
  entry_type: string;

  @Column()
  entry_by_user_id: number;

  @Column({ length: 30 })
  entry_local_date_time: string;
}
