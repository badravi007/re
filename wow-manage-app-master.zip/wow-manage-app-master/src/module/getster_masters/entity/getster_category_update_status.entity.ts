import { Column, Entity, PrimaryColumn, PrimaryGeneratedColumn } from 'typeorm';

@Entity({
  database: 'in_manage_get_wow_education_db',
  name: 'getster_category_update_status',
})
export class GetsterCategoryUpdateStatus {
  @PrimaryColumn()
  getster_category_update_utc_date_time: string;
}
