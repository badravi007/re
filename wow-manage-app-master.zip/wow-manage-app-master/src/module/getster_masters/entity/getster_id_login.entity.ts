import { Column, Entity, PrimaryColumn, PrimaryGeneratedColumn } from 'typeorm';

@Entity({
  database: 'in_manage_get_wow_education_db',
  name: 'getster_id_login',
})
export class GetsterIdLogin {
  @PrimaryGeneratedColumn('increment')
  id: number;

  @Column({
    length: 15,
  })
  login_mobile_no: string;

  @Column({
    length: 100,
    nullable: false,
  })
  getster_password: string;

  @Column({
    nullable: false,
  })
  getster_approval_status: number;

  @Column({
    nullable: true,
  })
  face_recognition_file: string;

  @Column({
    length: 255,
    nullable: true,
  })
  authkey: string;

  @Column({
    nullable: false,
  })
  getster_id: number;

  @Column({
    nullable: true,
  })
  getster_language_default: string;
}
