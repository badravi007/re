/*
https://docs.nestjs.com/providers#services
*/

import { Injectable } from '@nestjs/common';
import { InjectConnection, InjectRepository } from '@nestjs/typeorm';
import { AuthService } from 'src/auth/services/auth.service';
import { Repository } from 'typeorm';
import { GetsterCategoryAssignDto } from '../dto/getster_category_assign.dto';
import {
  GetsterFavouriteAppsDto,
  GetsterLogOutDto,
  GetsterLoginDto,
  GetsterRecentAppsDto,
} from '../dto/getster_id_login.dto';
import {
  GetsterCategoryIdDto,
  GetsterProfileDto,
  UpdateGETsterProfile,
} from '../dto/getster_profile.dto';
import { GetsterProfileAuditTrailDto } from '../dto/getster_profile_audit_trail.dto';

import { GetsterProfile } from '../entity/getster_profile.entity';

@Injectable()
export class Getster_profileService {
  constructor(
    @InjectRepository(GetsterProfile, 'in_manage_get_wow_education_db')
    @InjectConnection('in_manage_get_wow_education_db')
    private readonly getsterProfileRepository: Repository<GetsterProfile>,
    private _authService: AuthService,
  ) {}

  async createGetsterProfile(
    getsterProfileDto: GetsterCategoryIdDto,
  ): Promise<GetsterProfile> {
    try {
      let body: GetsterProfileDto = getsterProfileDto;
      const getster_profile_response = await this.getsterProfileRepository.save(
        body,
      );
      let g_id = getster_profile_response.getster_id;
      await this.getsterProfileRepository
        .query(`insert into getster_id_login values (0,
            '${getster_profile_response.login_mobile_no}',
            '${getster_profile_response.getster_password}',
            true,'${getster_profile_response.face_recognition_image_file}',null,${getster_profile_response.getster_id},null)`);

      // creating dynamic tables
      await this.getsterProfileRepository.query(
        `create table ${getster_profile_response.getster_id}_getster_id_home_screen_update_timestamps(getster_category_update_utc_date_time varchar(30) not null,getster_app_update_utc_date_time varchar(30) not null);`,
      );
      await this.getsterProfileRepository.query(
        `create table ${getster_profile_response.getster_id}_getster_id_home_screen_recent_apps(getster_app_id int not null,	getster_app_icon_image varchar(100) not null,	getster_app_icon_name varchar(20) not null);`,
      );
      await this.getsterProfileRepository.query(
        `create table ${getster_profile_response.getster_id}_getster_id_home_screen_favourite_apps(getster_app_id int not null,	getster_app_icon_image varchar(100) not null,	getster_app_icon_name varchar(20) not null);`,
      );
      await this.getsterProfileRepository.query(
        `create table ${getster_profile_response.getster_id}_getster_id_home_screen_apps(getster_app_category_id varchar(50) not null,getster_app_category_path varchar(100) not null, getster_app_category_name varchar(50) not null,getster_app_id int not null,		getster_app_icon_image varchar(100) not null,getster_app_icon_name varchar(20) not null,getster_app_location_within_the_category_id varchar(50) not null );`,
      );
      // end

      let getster_category_id: any = getsterProfileDto.getster_category_id;
      for (let i = 0; i < getster_category_id.length; i++) {
        await this.getsterProfileRepository
          .query(`insert into registered_users_registered_getster_categories values (
                0,
                ${getster_profile_response.getster_id},
                ${getster_category_id[i]})`);

        let getster_app_category_id = await this.getsterProfileRepository.query(
          `SElect * from getster_category_wise_app_access where
           getster_category_id='${getster_category_id[i]}'`,
        );

        for (let j = 0; j < getster_app_category_id.length; j++) {
          let getster_app_ids: any[] =
            getster_app_category_id[j].getster_app_id.split(',');
          for (let k = 0; k < getster_app_ids.length; k++) {
            // let connection = getConnection('wow_getster_app_db');

            let category_apps = await this.getsterProfileRepository.query(`
       SELECT master.getster_app_id,master.getster_app_icon_name,master.	getster_app_icon_image,
       master.getster_app_name,master.getster_app_development_status,master.getster_app_title_bar_name,

       assign.getster_app_category_id,assign.id,
       assign.getster_app_id,assign.getster_app_location_within_the_category_id,

       catLoc.getster_app_category_name as CategoryName, catLoc.getster_app_category_name as getster_app_category_name,
       catLoc.getster_app_category_path, catLoc.getster_app_category_id

       FROM   wow_getster_app_db.getster_app_master master
       join
       wow_getster_app_db.getster_apps_and_categories_assignment assign on  master.getster_app_id = assign.getster_app_id
       join
       wow_getster_app_db.getster_app_categories catLoc  on assign.getster_app_category_id = catLoc.getster_app_category_id

       WHERE assign.getster_app_category_id='${getster_app_category_id[j].getster_app_category_id}' and
       assign.getster_app_id = '${getster_app_ids[k]}'
        `);

            for (let l = 0; l < category_apps.length; l++) {
              await this.getsterProfileRepository.query(
                `insert into in_manage_get_wow_education_db.${getster_profile_response.getster_id}_getster_id_home_screen_apps values (
                    '${category_apps[l].getster_app_category_id}' ,
                    '${category_apps[l].getster_app_category_path}',
                    '${category_apps[l].getster_app_category_name}',
                     ${category_apps[l].getster_app_id},
                    '${category_apps[l].getster_app_icon_image}',
                    '${category_apps[l].getster_app_icon_name}',
                    '${category_apps[l].getster_app_location_within_the_category_id}'
                  );`,
              );
            }
          }
        }
      }

      let mysql = require('mysql2');
      // let connection = getConnection('wow_getster_app_db');

      let getster_app_update_utc_date_time =
        await this.getsterProfileRepository.query(
          `select * from wow_getster_app_db.getster_app_update_status;`,
        );

      let temp =
        getster_app_update_utc_date_time[0].getster_app_update_utc_date_time;

      // let con = getConnection('in_manage_get_wow_education_db');

      let getster_category_update_utc_date_time =
        await this.getsterProfileRepository.query(
          `select * from in_manage_get_wow_education_db.getster_category_update_status;`,
        );

      let temp1 =
        getster_category_update_utc_date_time[0]
          .getster_category_update_utc_date_time;

      await this.getsterProfileRepository.query(
        `insert into ${getster_profile_response.getster_id}_getster_id_home_screen_update_timestamps values (
        '${temp1}' ,
          '${temp}'
        );`,
      );
      //

      //

      const result = await this.getsterProfileRepository.findOne({
        where: { getster_id: getster_profile_response.getster_id },
      });

      return result;
    } catch (err) {
      throw err;
    }
  }

  async checkGetsterProfileExist(login_mobile_no: string): Promise<boolean> {
    const mysql = require('mysql2');
    try {
      const user = await this.getsterProfileRepository.query(
        `select * from getster_id_login where login_mobile_no = ` +
          mysql.escape(login_mobile_no),
      );

      return user.length > 0 ? true : false;
    } catch (err) {
      throw err;
    }
  }

  async getsterLogin(getsterLoginDto: GetsterLoginDto): Promise<LoginResponse> {
    const mysql = require('mysql2');
    const payload = {
      user_id: 1,
      customer_id: '1a23',
    };

    try {
      let result;
      let response_result;
      const user_info = await this.getsterProfileRepository.query(
        `SELECT *
        FROM in_manage_get_wow_education_db.getster_id_login getsterid
        JOIN in_manage_get_wow_education_db.getster_profile getsterprofile On getsterid.getster_id = getsterprofile.getster_id
        WHERE getsterid.login_mobile_no = ` +
          mysql.escape(getsterLoginDto.login_mobile_no) +
          `AND getsterid.getster_password =  ` +
          mysql.escape(getsterLoginDto.getster_password),
      );

      response_result = {
        getster_id: user_info[0].getster_id,
        getster_approval_status: user_info[0].getster_approval_status,
        face_recognition_file: user_info[0].face_recognition_file,
        access_token: await this._authService.generateJwt(payload),
      };

      if (user_info.length != 0) {
        let getster_category_update_status =
          await this.getsterProfileRepository.query(
            `SELECT * FROM in_manage_get_wow_education_db.getster_category_update_status;`,
          );
        let getster_app_update_status =
          await this.getsterProfileRepository.query(
            `SELECT * FROM wow_getster_app_db.getster_app_update_status;`,
          );
        let getster_id_update_status: any =
          await this.getsterProfileRepository.query(
            `SELECT * FROM in_manage_get_wow_education_db.${user_info[0].getster_id}_getster_id_home_screen_update_timestamps;`,
          );

        if (
          getster_category_update_status[0]
            .getster_category_update_utc_date_time ===
            getster_id_update_status[0].getster_category_update_utc_date_time &&
          getster_app_update_status[0].getster_app_update_utc_date_time ===
            getster_id_update_status[0].getster_app_update_utc_date_time
        ) {
          result = {
            status: true,
            message: 'Login Successfully',
            data: response_result,
          };
          await this.getsterProfileRepository.query(`
          update in_manage_get_wow_education_db.getster_id_login set
          authkey = '${await this._authService.generateJwt(
            payload,
          )}' where getster_id='${user_info[0].getster_id}'`);
        } else {
          // truncate tables data's.
          // await this.getsterProfileRepository.query(
          //   `truncate table in_manage_get_wow_education_db.${user_info[0].getster_id}_getster_id_home_screen_update_timestamps;`,
          // );
          await this.getsterProfileRepository.query(
            `truncate table in_manage_get_wow_education_db.${user_info[0].getster_id}_getster_id_home_screen_recent_apps;`,
          );
          await this.getsterProfileRepository.query(
            `truncate table in_manage_get_wow_education_db.${user_info[0].getster_id}_getster_id_home_screen_favourite_apps;`,
          );
          await this.getsterProfileRepository.query(
            `truncate table in_manage_get_wow_education_db.${user_info[0].getster_id}_getster_id_home_screen_apps;`,
          );
          let getster_category_id = await this.getsterProfileRepository.query(
            `SELECT * FROM in_manage_get_wow_education_db.registered_users_registered_getster_categories where getster_id=${user_info[0].getster_id};`,
          );
          for (let i = 0; i < getster_category_id.length; i++) {
            let getster_app_category_id =
              await this.getsterProfileRepository.query(
                `SELECT * FROM in_manage_get_wow_education_db.getster_category_wise_app_access where getster_category_id=${getster_category_id[i].getster_category_id};`,
              );

            for (let j = 0; j < getster_app_category_id.length; j++) {
              await this.getsterProfileRepository.query(
                `update in_manage_get_wow_education_db.${user_info[0].getster_id}_getster_id_home_screen_update_timestamps set
                getster_category_update_utc_date_time = '${getster_category_update_status[0].getster_category_update_utc_date_time}' ,
                getster_app_update_utc_date_time = '${getster_app_update_status[0].getster_app_update_utc_date_time}'
                `,
              );

              let getster_app_id: any =
                getster_app_category_id[j].getster_app_id.split(',');

              for (let k = 0; k < getster_app_id.length; k++) {
                // let connection = getConnection('wow_getster_app_db');
                let category_apps = await this.getsterProfileRepository.query(`
             SELECT master.getster_app_id,master.getster_app_icon_name,master.	getster_app_icon_image,
             master.getster_app_name,master.getster_app_development_status,master.getster_app_title_bar_name,

             assign.getster_app_category_id,assign.id,
             assign.getster_app_id,assign.getster_app_location_within_the_category_id,

             catLoc.getster_app_category_name as CategoryName, catLoc.getster_app_category_name as getster_app_category_name,
             catLoc.getster_app_category_path, catLoc.getster_app_category_id

             FROM   wow_getster_app_db.getster_app_master master
             join
             wow_getster_app_db.getster_apps_and_categories_assignment assign on  master.getster_app_id = assign.getster_app_id
             join
             wow_getster_app_db.getster_app_categories catLoc  on assign.getster_app_category_id = catLoc.getster_app_category_id

             WHERE assign.getster_app_category_id='${getster_app_category_id[j].getster_app_category_id}' and
             assign.getster_app_id = '${getster_app_id[k]}'
              `);

                for (let l = 0; l < category_apps.length; l++) {
                  await this.getsterProfileRepository.query(
                    `insert into in_manage_get_wow_education_db.${user_info[0].getster_id}_getster_id_home_screen_apps values (
                          '${category_apps[l].getster_app_category_id}' ,
                          '${category_apps[l].getster_app_category_path}',
                          '${category_apps[l].getster_app_category_name}',
                          ${category_apps[l].getster_app_id},
                          '${category_apps[l].getster_app_icon_image}',
                          '${category_apps[l].getster_app_icon_name}',
                          '${category_apps[l].getster_app_location_within_the_category_id}'
                        );`,
                  );
                }
              }
            }
          }

          result = {
            status: true,
            message: 'Login Successfully',
            data: response_result,
          };

          await this.getsterProfileRepository.query(`
          update in_manage_get_wow_education_db.getster_id_login set
          authkey = '${await this._authService.generateJwt(
            payload,
          )}' where getster_id='${user_info[0].getster_id}'`);
        }
      } else {
        result = {
          status: true,
          message: 'Given Username or password is wrong.',
          data: null,
        };
      }

      return result;
      // return user.length > 0 ? true : false;
    } catch (err) {
      throw err;
    }
  }

  async logout(getsterLogOutDto: GetsterLogOutDto): Promise<any> {
    // return await getRepository(GetsterIdLogin).delete({
    //   authkey: getsterLogOutDto.access_token,
    // });
    const payload = {
      user_id: 1,
      customer_id: '1a23',
    };
    // return await this._authService.logOutJwt(getsterLogOutDto.access_token);
  }
  async addGetsterRecentApp(
    getsterRecentAppsDto: GetsterRecentAppsDto,
  ): Promise<any> {
    try {
      return await this.getsterProfileRepository.query(
        `insert into in_manage_get_wow_education_db.${getsterRecentAppsDto.getster_id}_getster_id_home_screen_recent_apps values (
        ${getsterRecentAppsDto.getster_app_id},
        '${getsterRecentAppsDto.getster_app_icon_image}' ,
        '${getsterRecentAppsDto.getster_app_icon_name}');`,
      );
    } catch (err) {
      throw err;
    }
  }

  async addGetsterFavouriteApp(
    getsterFavouriteAppsDto: GetsterFavouriteAppsDto,
  ): Promise<any> {
    try {
      return await this.getsterProfileRepository.query(
        `insert into in_manage_get_wow_education_db.${getsterFavouriteAppsDto.getster_id}_getster_id_home_screen_favourite_apps values (
        ${getsterFavouriteAppsDto.getster_app_id},
        '${getsterFavouriteAppsDto.getster_app_icon_image}' ,
        '${getsterFavouriteAppsDto.getster_app_icon_name}');`,
      );
    } catch (err) {
      throw err;
    }
  }

  async getGetsterFavouriteApp(getster_id: number): Promise<any> {
    try {
      return await this.getsterProfileRepository.query(
        `select * from in_manage_get_wow_education_db.${getster_id}_getster_id_home_screen_favourite_apps`,
      );
    } catch (err) {
      throw err;
    }
  }

  async getGetsterRecentApp(getster_id: number): Promise<any> {
    try {
      return await this.getsterProfileRepository.query(
        `select * from in_manage_get_wow_education_db.${getster_id}_getster_id_home_screen_recent_apps;`,
      );
    } catch (err) {
      throw err;
    }
  }

  async removeGetsterRecentApp(
    getster_id: number,
    getster_app_id: string,
  ): Promise<any> {
    try {
      return await this.getsterProfileRepository.query(
        `delete from in_manage_get_wow_education_db.${getster_id}_getster_id_home_screen_recent_apps where getster_app_id='${getster_app_id}'`,
      );
    } catch (err) {
      throw err;
    }
  }

  async removeGetsterFavouriteApp(
    getster_id: number,
    getster_app_id: string,
  ): Promise<any> {
    try {
      return await this.getsterProfileRepository.query(
        `delete from in_manage_get_wow_education_db.${getster_id}_getster_id_home_screen_favourite_apps where getster_app_id='${getster_app_id}'`,
      );
    } catch (err) {
      throw err;
    }
  }

  async getGetsterApps(getster_id: number): Promise<any> {
    try {
      let category_id = await this.getsterProfileRepository.query(
        `select distinct getster_app_category_name,getster_app_category_id from ${getster_id}_getster_id_home_screen_apps`,
      );
      let body: any[] = [];
      let main_count = 0;
      let data: any[] = [];
      for (let i = 0; i < category_id.length; i++) {
        let getster_app_category_name =
          category_id[i].getster_app_category_name;

        let getster_app = await this.getsterProfileRepository.query(
          `select * from in_manage_get_wow_education_db.${getster_id}_getster_id_home_screen_apps where
          getster_app_category_id=${category_id[i].getster_app_category_id}`,
        );

        // for (let j = 0; j < getster_app.length; j++) {
        //   if (
        //     category_id[i].getster_app_category_id ===
        //     getster_app[j].getster_app_category_id
        //   ) {
        //     data.push();
        //   }
        // }
        body.push({
          getster_app_category_name: getster_app_category_name,
          data: getster_app,
        });
        main_count++;
        if (main_count > i && data.length != 0) {
        }
      }

      return body;
    } catch (err) {
      throw err;
    }
  }

  async checkGetsterFavouriteAppsExist(
    getster_id: number,
    getster_app_id: number,
  ): Promise<boolean> {
    const mysql = require('mysql2');
    try {
      const user = await this.getsterProfileRepository.query(
        `select * from in_manage_get_wow_education_db.${getster_id}_getster_id_home_screen_favourite_apps where getster_app_id = ` +
          mysql.escape(getster_app_id),
      );

      return user.length > 0 ? true : false;
    } catch (err) {
      throw err;
    }
  }

  async checkGetsterRecentAppsExist(
    getster_id: number,
    getster_app_id: number,
  ): Promise<boolean> {
    const mysql = require('mysql2');
    try {
      const user = await this.getsterProfileRepository.query(
        `select * from in_manage_get_wow_education_db.${getster_id}_getster_id_home_screen_recent_apps where getster_app_id = ` +
          mysql.escape(getster_app_id),
      );

      return user.length > 0 ? true : false;
    } catch (err) {
      throw err;
    }
  }

  async assignGetsterCategoryAppWise(
    getsterCategoryAssignDto: GetsterCategoryAssignDto,
  ): Promise<any> {
    try {
      await this.getsterProfileRepository.query(
        `update in_manage_get_wow_education_db.getster_category_update_status set
        getster_category_update_utc_date_time = '${getsterCategoryAssignDto.getster_category_utc}'`,
      );
      // Additional Field
      let checkIfExist = await this.checkIfExistAdditionalField(
        getsterCategoryAssignDto.getster_category_id,
      );
      if (checkIfExist) {
        await this.getsterProfileRepository.query(`
        update in_manage_get_wow_education_db.getster_category_wise_additional_field_names set
        additional_getster_data_field_name = '${getsterCategoryAssignDto.additional_getster_data_field_name}',
        location_of_user_required = ${getsterCategoryAssignDto.location_of_user_required} where
        getster_category_id = '${getsterCategoryAssignDto.getster_category_id}'
      `);
      } else {
        await this.getsterProfileRepository.query(
          `insert into in_manage_get_wow_education_db.getster_category_wise_additional_field_names values (
        0,'${getsterCategoryAssignDto.getster_category_id}',
        '${getsterCategoryAssignDto.additional_getster_data_field_name}' ,
        ${getsterCategoryAssignDto.location_of_user_required});`,
        );
      }
      // Getster Category App Assignment
      let getster_app_id: any = getsterCategoryAssignDto.getster_app_id;
      for (let i = 0; i < getster_app_id.length; i++) {
        if (getster_app_id[i].getster_app_id == '') {
          await this.getsterProfileRepository.query(`
          delete from in_manage_get_wow_education_db.getster_category_wise_app_access where
          getster_category_id='${getsterCategoryAssignDto.getster_category_id}' and
          getster_app_category_id = '${getster_app_id[i].getster_app_category_id}';
          `);
        } else {
          let checkIfExistC = await this.checkIfExistApps(
            getsterCategoryAssignDto.getster_category_id,
            getster_app_id[i].getster_app_category_id,
          );
          if (checkIfExistC) {
            await this.getsterProfileRepository.query(
              `update in_manage_get_wow_education_db.getster_category_wise_app_access set
            getster_app_id = '${getster_app_id[i].getster_app_id}' where
            getster_app_category_id='${getster_app_id[i].getster_app_category_id}' and
            getster_category_id = '${getsterCategoryAssignDto.getster_category_id}'`,
            );
          } else {
            await this.getsterProfileRepository.query(
              `insert into in_manage_get_wow_education_db.getster_category_wise_app_access values
            (0,'${getsterCategoryAssignDto.getster_category_id}',
            '${getster_app_id[i].getster_app_category_id}',
            '${getster_app_id[i].getster_app_id}');`,
            );
          }
        }
      }
      return 'Assigned Successfully.';
    } catch (err) {
      throw err;
    }
  }

  async checkIfExistApps(
    getster_category_id: string,
    getster_app_category_id: string,
  ): Promise<boolean> {
    try {
      let is_checked = await this.getsterProfileRepository.query(
        `SELECT * FROM in_manage_get_wow_education_db.getster_category_wise_app_access
        WHERE getster_app_category_id = '${getster_app_category_id}' and
        getster_category_id = '${getster_category_id}'`,
      );

      return is_checked.length > 0 ? true : false;
    } catch (err) {
      throw err;
    }
  }

  async checkIfExistAdditionalField(
    getster_category_id: string,
  ): Promise<boolean> {
    try {
      let is_checked = await this.getsterProfileRepository.query(
        `SELECT * FROM in_manage_get_wow_education_db.getster_category_wise_additional_field_names
        WHERE getster_category_id = '${getster_category_id}'`,
      );
      return is_checked.length > 0 ? true : false;
    } catch (err) {
      throw err;
    }
  }

  async getAdditionalGetsterFormField(
    getster_category_id: string,
  ): Promise<AdditionalData[]> {
    try {
      let ids: any = getster_category_id.split(',');
      let body: any[] = [];
      for (let i = 0; i < ids.length; i++) {
        let result = await this.getsterProfileRepository.query(`
        SELECT additionalForm.getster_category_id,
        additionalForm.additional_getster_data_field_name,
        additionalForm.location_of_user_required,
        getster_category.getster_category_name
        FROM in_manage_get_wow_education_db.getster_category_wise_additional_field_names  additionalForm join
        in_manage_get_wow_education_db.getster_category getster_category on  additionalForm.getster_category_id = getster_category.getster_category_id
        where additionalForm.getster_category_id = ${ids[i]}
        `);
        if (result != 0) {
          body.push({
            getster_category_name: result[0].getster_category_name,
            location_of_user_required: result[0].location_of_user_required,
            data: JSON.stringify(result[0].additional_getster_data_field_name),
          });
        }
      }
      return body;
    } catch (err) {
      throw err;
    }
  }

  async getGetsterCategoryWiseGetsterApps(
    getster_category_id: string,
  ): Promise<AdditionalData[]> {
    try {
      let result = await this.getsterProfileRepository.query(`
      SELECT master.getster_category_id,master.additional_getster_data_field_name,master.location_of_user_required,
      apps.getster_app_category_id,apps.getster_app_id
      FROM in_manage_get_wow_education_db.getster_category_wise_additional_field_names  master  join
      in_manage_get_wow_education_db.getster_category_wise_app_access apps on
       apps.getster_category_id = '${getster_category_id}' and
       master.getster_category_id = '${getster_category_id}'
      `);
      return result;
    } catch (err) {
      throw err;
    }
  }
  async getGetsterProfileByStatus(
    getster_approval_status: string,
  ): Promise<any> {
    try {
      let getsters = await this.getsterProfileRepository.query(`
      SELECT * FROM in_manage_get_wow_education_db.getster_id_login getsterid
      JOIN in_manage_get_wow_education_db.getster_profile getsterprofile On getsterid.getster_id = getsterprofile.getster_id
      WHERE getsterid.getster_approval_status=${getster_approval_status}
      `);

      let result: any[] = [];
      let category_names: string = '';
      for (let i = 0; i < getsters.length; i++) {
        let getster_category_id = await this.getsterProfileRepository.query(`
        SELECT * FROM in_manage_get_wow_education_db.registered_users_registered_getster_categories getsterid
        WHERE getsterid.getster_id=${getsters[i].getster_id}
      `);

        for (let j = 0; j < getster_category_id.length; j++) {
          let getster_category_name: any = await this.getsterProfileRepository
            .query(`
          SELECT * FROM in_manage_get_wow_education_db.getster_category getstercategory
          WHERE getstercategory.getster_category_id=${getster_category_id[j].getster_category_id}
        `);
          category_names +=
            getster_category_name[0].getster_category_name + ',';
        }
        result.push({
          login_mobile_no: getsters[i].login_mobile_no,
          getster_approval_status: getsters[i].getster_approval_status,
          getster_id: getsters[i].getster_id,
          first_name: getsters[i].first_name,
          last_name: getsters[i].last_name,
          dob: getsters[i].dob,
          gender: getsters[i].gender,
          additional_getster_data_field_values:
            getsters[i].additional_getster_data_field_values,
          about_user: getsters[i].about_user,
          getster_category_name: category_names,
        });
        category_names = '';
      }
      return result;
    } catch (err) {
      throw err;
    }
  }
  async getGetsterProfileByGETsterID(getster_id: string): Promise<any> {
    try {
      let getsters = await this.getsterProfileRepository.query(`
      SELECT * FROM in_manage_get_wow_education_db.getster_id_login getsterid
      JOIN in_manage_get_wow_education_db.getster_profile getsterprofile On getsterid.getster_id = getsterprofile.getster_id
      WHERE getsterid.getster_id=${getster_id}
      `);

      let result: any[] = [];
      let category_names: string = '';
      for (let i = 0; i < getsters.length; i++) {
        let getster_category_id = await this.getsterProfileRepository.query(`
        SELECT * FROM in_manage_get_wow_education_db.registered_users_registered_getster_categories getsterid
        WHERE getsterid.getster_id=${getsters[i].getster_id}
      `);

        for (let j = 0; j < getster_category_id.length; j++) {
          let getster_category_name: any = await this.getsterProfileRepository
            .query(`
          SELECT * FROM in_manage_get_wow_education_db.getster_category getstercategory
          WHERE getstercategory.getster_category_id=${getster_category_id[j].getster_category_id}
        `);
          category_names +=
            getster_category_name[0].getster_category_name + ',';
        }
        result.push({
          login_mobile_no: getsters[i].login_mobile_no,
          getster_approval_status: getsters[i].getster_approval_status,
          getster_id: getsters[i].getster_id,
          first_name: getsters[i].first_name,
          last_name: getsters[i].last_name,
          dob: getsters[i].date_of_birth,
          gender: getsters[i].gender,
          additional_getster_data_field_values:
            getsters[i].additional_getster_data_field_values,
          about_user: getsters[i].about_user,
          getster_category_name: category_names,
        });
        category_names = '';
      }
      return result;
    } catch (err) {
      throw err;
    }
  }
  async updateGetsterProfileStatus(
    getster_approval_status: number,
    selected_getster_id: number,
    entry_by_user_id: number,
    entry_local_date_time: string,
    entry_type: string,
  ): Promise<AdditionalData[]> {
    try {
      let result = await this.getsterProfileRepository.query(`
      update  in_manage_get_wow_education_db.getster_id_login set getster_approval_status = ${getster_approval_status} where getster_id = ${selected_getster_id};
      `);

      let audit_trail_body = {
        getster_id: selected_getster_id,
        entry_type: entry_type,
        entry_by_user_id: entry_by_user_id,
        entry_local_date_time: entry_local_date_time,
      };

      await this.insertGetsterProfileAuditTrailDto(audit_trail_body);

      return result;
    } catch (err) {
      throw err;
    }
  }

  async insertGetsterProfileAuditTrailDto(
    getsterProfileAuditTrailDto: GetsterProfileAuditTrailDto,
  ): Promise<any> {
    try {
      return await this.getsterProfileRepository.query(`
      insert into in_manage_get_wow_education_db.getster_profile_audit_trail values(
        0,'${getsterProfileAuditTrailDto.getster_id}',
        '${getsterProfileAuditTrailDto.entry_type}',
        '${getsterProfileAuditTrailDto.entry_by_user_id}',
        '${getsterProfileAuditTrailDto.entry_local_date_time}'
      )
      `);
    } catch (err) {
      throw err;
    }
  }

  async getGetsterProfileAuditTrail(): Promise<any> {
    try {
      let getsters = await this.getsterProfileRepository.query(`
      SELECT * FROM in_manage_get_wow_education_db.getster_profile_audit_trail;
      `);
      let result: any[] = [];
      let category_names: string = '';
      for (let i = 0; i < getsters.length; i++) {
        let getster_name = await this.getsterProfileRepository
          .query(`SELECT * FROM in_manage_get_wow_education_db.getster_profile
        WHERE getster_id=${getsters[i].getster_id} `);
        let entry_by_user_id = await this.getsterProfileRepository
          .query(`SELECT * FROM in_manage_get_wow_education_db.getster_profile
        WHERE getster_id=${getsters[i].entry_by_user_id}`);

        let getster_category_id = await this.getsterProfileRepository.query(`
        SELECT * FROM in_manage_get_wow_education_db.registered_users_registered_getster_categories getsterid
        WHERE getsterid.getster_id=${getsters[i].entry_by_user_id}
      `);

        for (let j = 0; j < getster_category_id.length; j++) {
          let getster_category_name: any = await this.getsterProfileRepository
            .query(`
          SELECT * FROM in_manage_get_wow_education_db.getster_category getstercategory
          WHERE getstercategory.getster_category_id=${getster_category_id[j].getster_category_id}
        `);
          category_names +=
            getster_category_name[0].getster_category_name + ',';
        }

        result.push({
          getster_name: getster_name[0].first_name,
          entry_type: getsters[i].entry_type,
          entry_local_date_time: getsters[i].entry_local_date_time,
          entry_by_user_id: entry_by_user_id[0].first_name,
          getster_category_name: category_names,
        });
        category_names = '';
      }
      return result;
    } catch (err) {
      throw err;
    }
  }

  async getGetsterConsoleProfileAuditTrail(): Promise<any> {
    try {
      let getsters = await this.getsterProfileRepository.query(`
      SELECT * FROM in_manage_get_wow_education_db.getster_profile_audit_trail where entry_type='Approved Console Access' or entry_type= 'Deny Console Access' ;
      `);
      let result: any[] = [];
      let category_names: string = '';
      for (let i = 0; i < getsters.length; i++) {
        let getster_name = await this.getsterProfileRepository
          .query(`SELECT * FROM in_manage_get_wow_education_db.getster_profile
        WHERE getster_id=${getsters[i].getster_id} `);
        let entry_by_user_id = await this.getsterProfileRepository
          .query(`SELECT * FROM in_manage_get_wow_education_db.getster_profile
        WHERE getster_id=${getsters[i].entry_by_user_id}`);

        let getster_category_id = await this.getsterProfileRepository.query(`
        SELECT * FROM in_manage_get_wow_education_db.registered_users_registered_getster_categories getsterid
        WHERE getsterid.getster_id=${getsters[i].getster_id}
      `);

        for (let j = 0; j < getster_category_id.length; j++) {
          let getster_category_name: any = await this.getsterProfileRepository
            .query(`
          SELECT * FROM in_manage_get_wow_education_db.getster_category getstercategory
          WHERE getstercategory.getster_category_id=${getster_category_id[j].getster_category_id}
        `);
          category_names +=
            getster_category_name[0].getster_category_name + ',';
        }

        result.push({
          console_user_id: getster_name[0].getster_id,
          console_user_name: getster_name[0].first_name,
          entry_type: getsters[i].entry_type,
          entry_by_user_id: entry_by_user_id[0].first_name,
          entry_local_date_time: getsters[i].entry_local_date_time,
          getster_category_name: category_names,
        });
        category_names = '';
      }
      return result;
    } catch (err) {
      throw err;
    }
  }

  async updateGetsterProfile(profileInfo: UpdateGETsterProfile): Promise<any> {
    try {
      let result = await this.getsterProfileRepository.query(`
        update in_manage_get_wow_education_db.getster_profile set first_name = '${profileInfo.first_name}',
        last_name = '${profileInfo.last_name}', about_user= '${profileInfo.about_user}'
         where getster_id = ${profileInfo.getster_id};
        `);

      let getster_category_id: any = profileInfo.getster_category_id;
      for (let i = 0; i < getster_category_id.length; i++) {
        let category_id_existing = await this.getsterProfileRepository.query(
          `SELECT * FROM in_manage_get_wow_education_db.registered_users_registered_getster_categories where getster_id = '${profileInfo.getster_id}' and getster_category_id = '${getster_category_id[i]}';`,
        );
        if (category_id_existing.length == 0) {
          await this.getsterProfileRepository
            .query(`insert into in_manage_get_wow_education_db.registered_users_registered_getster_categories values (
                  0,
                  ${profileInfo.getster_id},
                  ${getster_category_id[i]})`);
        } else {
          //   await this.getsterProfileRepository.query(`
          //     update in_manage_get_wow_education_db.registered_users_registered_getster_categories set first_name = '${profileInfo.first_name}',
          //     last_name = '${profileInfo.last_name}', about_user= '${profileInfo.about_user}'
          //     where getster_id = ${profileInfo.getster_id};
          // `);
        }
      }
      return result;
    } catch (err) {
      throw err;
    }
  }

  async updateGetsterMobile(
    login_mobile_no: string,
    getster_id: string,
  ): Promise<any> {
    try {
      let result;
      let category_id_existing = await this.getsterProfileRepository.query(
        `SELECT * FROM in_manage_get_wow_education_db.getster_id_login where login_mobile_no = '${login_mobile_no}';`,
      );
      if (category_id_existing.length == 0) {
        result = await this.getsterProfileRepository.query(`
        update in_manage_get_wow_education_db.getster_id_login set login_mobile_no = '${login_mobile_no}'
         where getster_id = ${getster_id};
        `);
      } else {
        result = false;
      }
      return result;
    } catch (err) {
      throw err;
    }
  }
}

interface AdditionalData {
  category_name: string;
  data: any;
}
interface LoginResponse {
  status: boolean;
  message: string;
  data: any;
}
