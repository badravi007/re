/*
https://docs.nestjs.com/controllers#controllers
*/

import {
  Body,
  Controller,
  Delete,
  Get,
  Post,
  Put,
  Query,
  UseGuards,
} from '@nestjs/common';
import { ApiBearerAuth, ApiTags } from '@nestjs/swagger';
import * as fs from 'fs';
import { JwtAuthGuard } from 'src/auth/guard/jwt-auth.guard';
import { ErrorCodeMap } from 'src/common/api-error/ErrorCodeMap';
import ResponseInterface from 'src/common/interface/response.interface';
import { GetsterCategoryAssignDto } from '../dto/getster_category_assign.dto';
import {
  GetsterFavouriteAppsDto,
  GetsterLogOutDto,
  GetsterLoginDto,
  GetsterRecentAppsDto,
} from '../dto/getster_id_login.dto';
import {
  GetsterCategoryIdDto,
  UpdateGETsterProfile,
} from '../dto/getster_profile.dto';
import { Getster_profileService } from './getster_profile.service';

@ApiTags('Getster Profile')
@ApiBearerAuth('JWT-auth')
@Controller('getster_profile')
export class Getster_profileController {
  constructor(private readonly getsterProfileService: Getster_profileService) {}

  @Post('/add_getster_registration')
  async createGetsterRegistration(
    @Body() getsterProfileDto: GetsterCategoryIdDto,
  ): Promise<ResponseInterface> {
    const alreadyExists =
      await this.getsterProfileService.checkGetsterProfileExist(
        getsterProfileDto.login_mobile_no,
      );
    if (alreadyExists) {
      return {
        statusCode: 101,
        message: `Getster Profile ${ErrorCodeMap[101]}!`,
        data: null,
      };
    } else {
      const base64Data = getsterProfileDto.image.replace(
        /^data:image\/[a-z]+;base64,/,
        '',
      );
      // const base64Data = getsterProfileDto.image.replace(
      //   /^data:image\/[a-z]+;base64,\/9j\//,
      //   '',
      // );
      const buffer = Buffer.from(base64Data, 'base64');

      await fs.writeFile(
        './src/assets/getster/' + getsterProfileDto.face_recognition_image_file,
        buffer,
        (err) => {
          if (err) return console.error(err);
        },
      );

      const result = await this.getsterProfileService.createGetsterProfile(
        getsterProfileDto,
      );
      let t = result;
      return {
        statusCode: 200,
        message: `Getster Profile Created Successfully!`,
        data: result,
      };
    }
  }

  @Post('/getster_login')
  async getsterLogin(
    @Body() getsterLoginDto: GetsterLoginDto,
  ): Promise<ResponseInterface> {
    const result = await this.getsterProfileService.getsterLogin(
      getsterLoginDto,
    );

    return {
      statusCode: 200,
      message: result.message,
      data: result.data,
    };
  }

  @Post('/getster_logout')
  async getsterLogOut(
    @Body() getsterLogOutDto: GetsterLogOutDto,
  ): Promise<ResponseInterface> {
    const result = await this.getsterProfileService.logout(getsterLogOutDto);

    return {
      statusCode: 200,
      message: result.message,
      data: result.data,
    };
  }

  @UseGuards(JwtAuthGuard)
  @Post('/add_getster_recent_app')
  async addGetsterRecentApp(
    @Body() getsterRecentAppsDto: GetsterRecentAppsDto,
  ): Promise<ResponseInterface> {
    const alreadyExists =
      await this.getsterProfileService.checkGetsterRecentAppsExist(
        getsterRecentAppsDto.getster_id,
        getsterRecentAppsDto.getster_app_id,
      );
    if (alreadyExists) {
      return {
        statusCode: 101,
        message: `Getster Recent App ${ErrorCodeMap[101]}!`,
        data: null,
      };
    } else {
      const result = await this.getsterProfileService.addGetsterRecentApp(
        getsterRecentAppsDto,
      );
      return {
        statusCode: 200,
        message: `Add Recent App Successfully.`,
        data: result,
      };
    }
  }

  @UseGuards(JwtAuthGuard)
  @Post('/add_getster_favourite_app')
  async addGetsterFavouriteApp(
    @Body() getsterFavouriteAppsDto: GetsterFavouriteAppsDto,
  ): Promise<ResponseInterface> {
    const alreadyExists =
      await this.getsterProfileService.checkGetsterFavouriteAppsExist(
        getsterFavouriteAppsDto.getster_id,
        getsterFavouriteAppsDto.getster_app_id,
      );
    if (alreadyExists) {
      return {
        statusCode: 101,
        message: `Getster Favourite App ${ErrorCodeMap[101]}!`,
        data: null,
      };
    } else {
      const result = await this.getsterProfileService.addGetsterFavouriteApp(
        getsterFavouriteAppsDto,
      );
      return {
        statusCode: 200,
        message: `Add Favourite App Successfully.`,
        data: result,
      };
    }
  }

  @UseGuards(JwtAuthGuard)
  @Get('/get_getster_favourite_app')
  async getGetsterFavouriteApp(
    @Query('getster_id') getster_id: number,
  ): Promise<ResponseInterface> {
    const result = await this.getsterProfileService.getGetsterFavouriteApp(
      getster_id,
    );
    return {
      statusCode: 200,
      message: `Get Favourite Apps Successfully.`,
      data: result,
    };
  }

  @UseGuards(JwtAuthGuard)
  @Get('/get_getster_recent_app')
  async getGetsterRecentApp(
    @Query('getster_id') getster_id: number,
  ): Promise<ResponseInterface> {
    const result = await this.getsterProfileService.getGetsterRecentApp(
      getster_id,
    );
    return {
      statusCode: 200,
      message: `Get Recent Apps Successfully.`,
      data: result,
    };
  }

  @UseGuards(JwtAuthGuard)
  @Get('/get_getster_home_screen_app')
  async getGetsterApps(
    @Query('getster_id') getster_id: number,
  ): Promise<ResponseInterface> {
    const result = await this.getsterProfileService.getGetsterApps(getster_id);
    return {
      statusCode: 200,
      message: `Get GETster Home Screen Apps Successfully.`,
      data: result,
    };
  }

  @UseGuards(JwtAuthGuard)
  @Delete('/remove_getster_recent_app')
  async removeGetsterRecentApp(
    @Query('getster_id') getster_id: number,
    @Query('getster_app_id') getster_app_id: string,
  ): Promise<ResponseInterface> {
    const result = await this.getsterProfileService.removeGetsterRecentApp(
      getster_id,
      getster_app_id,
    );
    return {
      statusCode: 200,
      message: `App Removed Successfully.`,
      data: result,
    };
  }

  @UseGuards(JwtAuthGuard)
  @Delete('/remove_getster_favorite_app')
  async removeGetsterFavouriteApp(
    @Query('getster_id') getster_id: number,
    @Query('getster_app_id') getster_app_id: string,
  ): Promise<ResponseInterface> {
    const result = await this.getsterProfileService.removeGetsterFavouriteApp(
      getster_id,
      getster_app_id,
    );
    return {
      statusCode: 200,
      message: `App Removed Successfully.`,
      data: result,
    };
  }

  @UseGuards(JwtAuthGuard)
  @Post('/assign_getster_category_app_wise')
  async assignGetsterCategoryAppWise(
    @Body() getsterCategoryAssignDto: GetsterCategoryAssignDto,
  ): Promise<ResponseInterface> {
    const result =
      await this.getsterProfileService.assignGetsterCategoryAppWise(
        getsterCategoryAssignDto,
      );
    return {
      statusCode: 200,
      message: `Assign GETster Category App Wise Successfully.`,
      data: result,
    };
  }

  @UseGuards(JwtAuthGuard)
  @Get('/get_additional_getster_form_field')
  async getAdditionalGetsterFormField(
    @Query('getster_category_id') getster_category_id: string,
  ): Promise<ResponseInterface> {
    const result =
      await this.getsterProfileService.getAdditionalGetsterFormField(
        getster_category_id,
      );
    return {
      statusCode: 200,
      message: `Get Additional Fields Successfully.`,
      data: result,
    };
  }

  @Get('/get_additional_getster_form_fields')
  async getSelectedGetsterCategoryFieldsAndApps(
    @Query('getster_category_id') getster_category_id: string,
  ): Promise<ResponseInterface> {
    const result =
      await this.getsterProfileService.getAdditionalGetsterFormField(
        getster_category_id,
      );
    return {
      statusCode: 200,
      message: `Get Recent Apps Successfully.`,
      data: result,
    };
  }

  @UseGuards(JwtAuthGuard)
  @Get('/get_getster_category_wise_getster_apps')
  async getGetsterCategoryWiseGetsterApps(
    @Query('getster_category_id') getster_category_id: string,
  ): Promise<ResponseInterface> {
    const result =
      await this.getsterProfileService.getGetsterCategoryWiseGetsterApps(
        getster_category_id,
      );
    return {
      statusCode: 200,
      message: `Get All Getster Category Wise Getster Apps Successfully.`,
      data: result,
    };
  }

  @UseGuards(JwtAuthGuard)
  @Get('/get_getster_profile_by_status')
  async getGetsterProfileByStatus(
    @Query('getster_approval_status') getster_approval_status: string,
  ): Promise<ResponseInterface> {
    const result = await this.getsterProfileService.getGetsterProfileByStatus(
      getster_approval_status,
    );
    return {
      statusCode: 200,
      message: `Get Getster Successfully.`,
      data: result,
    };
  }

  @UseGuards(JwtAuthGuard)
  @Get('/get_getster_profile_by_getster_id')
  async getGetsterProfileByGETsterID(
    @Query('getster_id') getster_id: string,
  ): Promise<ResponseInterface> {
    const result =
      await this.getsterProfileService.getGetsterProfileByGETsterID(getster_id);
    return {
      statusCode: 200,
      message: `Get Getster Successfully.`,
      data: result,
    };
  }

  @UseGuards(JwtAuthGuard)
  @Put('/update_getster_profile_status')
  async updateGetsterProfileStatus(
    @Query('getster_approval_status') getster_approval_status: number,
    @Query('selected_getster_id') selected_getster_id: number,
    @Query('entry_by_user_id') entry_by_user_id: number,
    @Query('entry_local_date_time') entry_local_date_time: string,
    @Query('entry_type') entry_type: string,
  ): Promise<ResponseInterface> {
    const result = await this.getsterProfileService.updateGetsterProfileStatus(
      getster_approval_status,
      selected_getster_id,
      entry_by_user_id,
      entry_local_date_time,
      entry_type,
    );
    return {
      statusCode: 200,
      message: `Update Getster Successfully.`,
      data: result,
    };
  }

  @UseGuards(JwtAuthGuard)
  @Get('/get_all_getster_profile_audit_trail')
  async getGetsterProfileAuditTrail(): Promise<ResponseInterface> {
    const result =
      await this.getsterProfileService.getGetsterProfileAuditTrail();
    return {
      statusCode: 200,
      message: `Get Getster Successfully.`,
      data: result,
    };
  }

  @UseGuards(JwtAuthGuard)
  @Get('/get_all_getster_console_profile_audit_trail')
  async getGetsterConsoleProfileAuditTrail(): Promise<ResponseInterface> {
    const result =
      await this.getsterProfileService.getGetsterConsoleProfileAuditTrail();
    return {
      statusCode: 200,
      message: `Get Getster Successfully.`,
      data: result,
    };
  }

  @UseGuards(JwtAuthGuard)
  @Put('/update_getster_profile_by_getster')
  async updateGetsterProfile(
    @Body() updateGetsterProfile: UpdateGETsterProfile,
  ): Promise<ResponseInterface> {
    const result = await this.getsterProfileService.updateGetsterProfile(
      updateGetsterProfile,
    );
    return {
      statusCode: 200,
      message: `Update Getster Successfully.`,
      data: result,
    };
  }

  @UseGuards(JwtAuthGuard)
  @Put('/update_getster_mobile_number')
  async updateGetsterMobile(
    @Query('login_mobile_no') login_mobile_no: string,
    @Query('getster_id') getster_id: string,
  ): Promise<ResponseInterface> {
    const result = await this.getsterProfileService.updateGetsterMobile(
      login_mobile_no,
      getster_id,
    );

    return {
      statusCode: 200,
      message: `Update Getster Mobile Number Successfully.`,
      data: result,
    };
  }
}
