import { ApiProperty } from '@nestjs/swagger';
import { isEnum, IsNotEmpty } from 'class-validator';

export class GetsterCategoryDto {
  @ApiProperty()
  getster_category_id: string;

  @ApiProperty()
  parent_getster_category_id: string | null;

  @ApiProperty()
  getster_category_name: string;

  @ApiProperty()
  is_the_getster_category_hidden: boolean;

  @ApiProperty()
  children: any;

  @ApiProperty()
  getster_category_type: number;
}

export class GetGetsterAdditionalFieldNameDto {
  @ApiProperty()
  getster_category_id: JSON;
}
