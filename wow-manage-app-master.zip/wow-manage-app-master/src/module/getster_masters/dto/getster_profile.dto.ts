import { ApiProperty } from '@nestjs/swagger';
import { IsNotEmpty, IsOptional } from 'class-validator';

export class GetsterProfileDto {
  @IsNotEmpty()
  @ApiProperty()
  first_name: string;

  @IsNotEmpty()
  @ApiProperty()
  last_name: string;

  @IsNotEmpty()
  @ApiProperty()
  login_mobile_no: string;

  @IsNotEmpty()
  @ApiProperty()
  getster_password: string;

  @IsNotEmpty()
  @ApiProperty()
  getster_approval_status: boolean;

  @IsNotEmpty()
  @ApiProperty()
  additional_getster_data_field_values: string;

  @IsOptional()
  @ApiProperty()
  about_user: string;

  @IsOptional()
  @ApiProperty()
  biz_card_company_details: string;

  @IsOptional()
  @ApiProperty()
  biz_card_mobile_no: number;

  @IsOptional()
  @ApiProperty()
  biz_card_phone_no: number;

  @IsOptional()
  @ApiProperty()
  biz_card_website: string;

  @IsOptional()
  @ApiProperty()
  biz_card_email_id: string;

  @IsOptional()
  @ApiProperty()
  biz_card_address: string;

  @IsOptional()
  @ApiProperty()
  biz_card_address_gps: string;

  @IsOptional()
  @ApiProperty()
  face_recognition_image_file: string;

  @IsOptional()
  @ApiProperty()
  getster_registration_approval_date: string;

  @IsOptional()
  @ApiProperty()
  getster_profile_update_date: string;

  @IsOptional()
  @ApiProperty()
  image: string;
}

export class GetsterCategoryIdDto extends GetsterProfileDto {
  @IsNotEmpty()
  @ApiProperty()
  getster_category_id: string;
}

export class UpdateGETsterProfile {
  @ApiProperty()
  first_name: string;

  @ApiProperty()
  last_name: string;

  @ApiProperty()
  about_user: string;

  @ApiProperty()
  getster_id: number;

  @ApiProperty()
  getster_category_id: string;
}
