import { ApiProperty } from '@nestjs/swagger';

export class GetsterReassignCategoryDto {
  @ApiProperty()
  getster_id: number;
  @ApiProperty()
  getster_category_id: string;
  @ApiProperty()
  first_name: string;
  @ApiProperty()
  last_name: string;
  @ApiProperty()
  getster_category_name: string;
}
