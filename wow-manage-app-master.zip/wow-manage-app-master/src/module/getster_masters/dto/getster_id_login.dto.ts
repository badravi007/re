import { ApiProperty } from '@nestjs/swagger';
import { IsNotEmpty } from 'class-validator';

export class GetsterLoginDto {
  @IsNotEmpty()
  @ApiProperty()
  login_mobile_no: string;

  @IsNotEmpty()
  @ApiProperty()
  getster_password: string;
}

export class GetsterRecentAppsDto {
  @IsNotEmpty()
  @ApiProperty()
  getster_id: number;

  @IsNotEmpty()
  @ApiProperty()
  getster_app_id: number;

  @IsNotEmpty()
  @ApiProperty()
  getster_app_icon_image: string;

  @IsNotEmpty()
  @ApiProperty()
  getster_app_icon_name: string;
}

export class GetsterFavouriteAppsDto {
  @IsNotEmpty()
  @ApiProperty()
  getster_id: number;

  @IsNotEmpty()
  @ApiProperty()
  getster_app_id: number;

  @IsNotEmpty()
  @ApiProperty()
  getster_app_icon_image: string;

  @IsNotEmpty()
  @ApiProperty()
  getster_app_icon_name: string;
}

export class GetsterLogOutDto {
  @IsNotEmpty()
  @ApiProperty()
  access_token: string;
}
