import { ApiProperty } from '@nestjs/swagger';
import { IsNotEmpty } from 'class-validator';

export class GetsterCategoryAssignDto {
  @IsNotEmpty()
  @ApiProperty()
  getster_category_id: string;

  @IsNotEmpty()
  @ApiProperty()
  additional_getster_data_field_name: string;

  @IsNotEmpty()
  @ApiProperty()
  getster_app_id: JSON;

  @IsNotEmpty()
  @ApiProperty()
  location_of_user_required: boolean;

  @IsNotEmpty()
  @ApiProperty()
  getster_category_utc: string;
}
