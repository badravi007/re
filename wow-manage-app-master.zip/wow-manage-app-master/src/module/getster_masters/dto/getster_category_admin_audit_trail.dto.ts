import { ApiProperty } from '@nestjs/swagger';

export class GetsterCategoryAdminAuditTrailDto {
  @ApiProperty()
  getster_category_id: string;

  @ApiProperty()
  entry_type: string;

  @ApiProperty()
  entry_by_user_id: number;

  @ApiProperty()
  entry_local_date_time: string;
}
