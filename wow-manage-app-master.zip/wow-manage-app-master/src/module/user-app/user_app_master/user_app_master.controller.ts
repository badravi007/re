import {
  Body,
  Controller,
  Get,
  NotFoundException,
  Post,
  Put,
  Query,
  Res,
  UploadedFile,
  UseInterceptors,
} from '@nestjs/common';
import { FileInterceptor } from '@nestjs/platform-express';
import { ApiBody, ApiConsumes, ApiTags } from '@nestjs/swagger';
import { existsSync } from 'fs';
import { diskStorage } from 'multer';
import { ErrorCodeMap } from 'src/common/api-error/ErrorCodeMap';
import ResponseInterface from 'src/common/interface/response.interface';
import {
  editFileName,
  imageFileFilter,
} from 'src/shared/utils/file-upload.utils';
import { UpdateUserAppDevelopmentStatusDto } from '../dto/update_user_app_development_status.dto';
import { UserAppAuditTrailDto } from '../dto/user_app_master.dto';
import { User_app_masterService } from './user_app_master.service';

// @UseGuards(JwtAuthGuard)
// @ApiBearerAuth('JWT-auth')
@ApiTags('User App Master')
@Controller('user_app_master')
export class User_app_masterController {
  constructor(private readonly userAppMasterService: User_app_masterService) {}

  @Post('/add_user_app')
  @ApiConsumes('multipart/form-data')
  @ApiBody({
    schema: {
      type: 'object',
      properties: {
        user_app_id: { type: 'number' },
        user_app_icon_name: { type: 'string' },
        user_app_full_name: { type: 'string' },
        getster_id: { type: 'string' },
        user_app_activity_utc_date_time: { type: 'string' },
        user_app_development_status: { type: 'boolean' },
        image: {
          type: 'string',
          format: 'binary',
        },
      },
    },
  })
  @UseInterceptors(
    FileInterceptor('image', {
      storage: diskStorage({
        destination: './src/assets/user_app_icons',
        filename: editFileName,
      }),
      fileFilter: imageFileFilter,
    }),
  )
  async createUserAppMaster(
    @UploadedFile() file,
    @Body() userAppMasterDto: UserAppAuditTrailDto,
  ): Promise<ResponseInterface> {
    const data = {
      user_app_id: userAppMasterDto.user_app_id,
      user_app_icon_name: userAppMasterDto.user_app_icon_name,
      user_app_full_name: userAppMasterDto.user_app_full_name,
      user_app_icon_image_path: file.filename,
      user_app_development_status: userAppMasterDto.user_app_development_status,
      getster_id: userAppMasterDto.getster_id,
      user_app_activity_utc_date_time:
        userAppMasterDto.user_app_activity_utc_date_time,
    };

    const alreadyExists =
      await this.userAppMasterService.checkUserAppMasterExist(
        userAppMasterDto.user_app_full_name,
      );
    if (alreadyExists) {
      return {
        statusCode: 101,
        message: `User App  ${ErrorCodeMap[101]}!`,
        data: null,
      };
    } else {
      const result = await this.userAppMasterService.createUserAppMaster(data);
      return {
        statusCode: 200,
        message: `User App Created Successfully!`,
        data: result,
      };
    }
  }

  @Put('/update_user_app')
  @ApiConsumes('multipart/form-data')
  @ApiBody({
    schema: {
      type: 'object',
      properties: {
        user_app_id: { type: 'number' },
        user_app_icon_name: { type: 'string' },
        user_app_full_name: { type: 'string' },
        getster_id: { type: 'string' },
        user_app_activity_utc_date_time: { type: 'string' },
        user_app_development_status: { type: 'boolean' },
        image: {
          type: 'string',
          format: 'binary',
        },
      },
    },
  })
  @UseInterceptors(
    FileInterceptor('image', {
      storage: diskStorage({
        destination: './src/assets/user_app_icons',
        filename: editFileName,
      }),
      fileFilter: imageFileFilter,
    }),
  )
  async updateUserAppMaster(
    @UploadedFile() file,
    @Body() userAppMasterDto: UserAppAuditTrailDto,
  ): Promise<ResponseInterface> {
    const data = {
      user_app_id: userAppMasterDto?.user_app_id,
      user_app_icon_name: userAppMasterDto?.user_app_icon_name,
      user_app_full_name: userAppMasterDto?.user_app_full_name,
      user_app_icon_image_path: file?.filename,
      user_app_development_status:
        userAppMasterDto?.user_app_development_status,
      getster_id: userAppMasterDto?.getster_id,
      user_app_activity_utc_date_time:
        userAppMasterDto?.user_app_activity_utc_date_time,
    };

    const result = await this.userAppMasterService.updateUserAppMaster(data);
    return {
      statusCode: 200,
      message: `Updated User App Successfully.`,
      data: result,
    };
  }

  // @UseGuards(JwtAuthGuard)
  @Put('/update_user_app_status')
  async updateUserAppDevelopmentStatus(
    @Body() updateUserAppDevelopmentStatus: UpdateUserAppDevelopmentStatusDto,
  ): Promise<ResponseInterface> {
    const result =
      await this.userAppMasterService.updateUserAppDevelopmentStatus(
        updateUserAppDevelopmentStatus,
      );
    return {
      statusCode: 200,
      message: `Updated User App Development Status Successfully!`,
      data: result,
    };
  }

  @Get('/get_all_user_app_audit_trail')
  async getAllBusinessCategoryAuditTrail(): Promise<any> {
    const result = await this.userAppMasterService.getAllUserAppAuditTrail();
    return {
      statusCode: 200,
      message: `Get Audit Trail Successfully!`,
      data: result,
    };
  }

  // @Get('/get_all_user_app_by_category_wise')
  // async getAllUserAppsByCategoryWise(): Promise<any> {
  //   const result =
  //     await this.userAppMasterService.getAllUserAppsByCategoryWise();
  //   return {
  //     statusCode: 200,
  //     message: `Get User App Category List Successfully.`,
  //     data: result,
  //   };
  // }

  @Get('/get_all_user_app_by_category_ids')
  async getAllUserAppByUserAppCategoryID(
    @Query('user_app_category_id') user_app_category_id: string,
  ): Promise<any> {
    const result =
      await this.userAppMasterService.getAllUserAppByUserAppCategoryID(
        user_app_category_id,
      );
    return {
      statusCode: 200,
      message: `Get Successfully!`,
      data: result,
    };
  }

  @Get('/get_file_user_app_master')
  async getFileUserAppMaster(
    @Query('file_name') file_name: string,
    @Res() res,
  ): Promise<any> {
    try {
      if (!existsSync(`src/assets/user_app_icons/${file_name}`)) {
        throw new NotFoundException();
      }
      return res.sendFile(file_name, {
        root: 'src/assets/user_app_icons',
      });
    } catch (error) {
      throw error.response;
    }
  }

  @Get('/get_user_app_by_id?')
  async getUserAppById(
    @Query('user_app_id') user_app_id: number,
  ): Promise<any> {
    const result = await this.userAppMasterService.getUserAppById(user_app_id);
    return {
      statusCode: 200,
      message: `Get All User App Successfully!`,
      data: result,
    };
  }
}
