/*
https://docs.nestjs.com/providers#services
*/

import { Injectable } from '@nestjs/common';
import { InjectConnection, InjectRepository } from '@nestjs/typeorm';
import { unlink } from 'fs';
import { Repository } from 'typeorm';
import { UpdateUserAppDevelopmentStatusDto } from '../dto/update_user_app_development_status.dto';
import { UserAppAuditTrailDto } from '../dto/user_app_master.dto';
import { UserAppsAuditTrailDto } from '../dto/user_apps_audit_trail.dto';
import { UserAppMaster } from '../entities/user_app_master.entity';

@Injectable()
export class User_app_masterService {
  constructor(
    @InjectRepository(UserAppMaster, 'wow_user_app_db')
    @InjectConnection('wow_user_app_db')
    private readonly userAppMasterRepository: Repository<UserAppMaster>,
  ) {}

  async createUserAppMaster(
    userAppMasterDto: UserAppAuditTrailDto,
  ): Promise<UserAppMaster> {
    try {
      let body = {
        user_app_id: userAppMasterDto.user_app_id,
        user_app_icon_name: userAppMasterDto.user_app_icon_name,
        user_app_full_name: userAppMasterDto.user_app_full_name,
        user_app_icon_image_path: userAppMasterDto.user_app_icon_image_path,
        user_app_development_status:
          userAppMasterDto.user_app_development_status,
      };
      let result = await this.userAppMasterRepository.save(body);
      let audit_trail_body = {
        user_app_id: result.user_app_id,
        user_app_activity: 'Add App',
        user_app_activity_by_user_id: userAppMasterDto.getster_id,
        user_app_activity_utc_date_time:
          userAppMasterDto.user_app_activity_utc_date_time,
      };
      await this.insertUserAppAuditTrailDto(audit_trail_body);
      return result;
    } catch (err) {
      throw err;
    }
  }

  async insertUserAppAuditTrailDto(
    businessCategoryCategory: UserAppsAuditTrailDto,
  ): Promise<any> {
    try {
      return await this.userAppMasterRepository.query(`
      insert into wow_user_app_db.user_apps_audit_trail values(
        0,'${businessCategoryCategory.user_app_id}',
        '${businessCategoryCategory.user_app_activity}',
        '${businessCategoryCategory.user_app_activity_by_user_id}',
        '${businessCategoryCategory.user_app_activity_utc_date_time}'
      )
      `);
    } catch (err) {
      throw err;
    }
  }

  async updateUserAppMaster(
    updateUserAppMasterDto: UserAppAuditTrailDto,
  ): Promise<any> {
    try {
      let data = await this.userAppMasterRepository
        .query(
          `
        SELECT * FROM wow_user_app_db.user_app_master
        where user_app_id='${updateUserAppMasterDto.user_app_id}'
       `,
        )
        .then((data) => data[0]);

      const {
        user_app_icon_name,
        user_app_full_name,
        user_app_icon_image_path,
        user_app_development_status,
      } = data;
      if (updateUserAppMasterDto?.user_app_icon_image_path) {
        unlink(
          './src/assets/user_app_icons/' + user_app_icon_image_path,
          (error) => {
            console.log(error);
          },
        );
      }

      let result = await this.userAppMasterRepository.query(`
      update wow_user_app_db.user_app_master set
      user_app_icon_name='${
        updateUserAppMasterDto.user_app_icon_name ?? user_app_icon_name
      }',
      user_app_full_name='${
        updateUserAppMasterDto.user_app_full_name ?? user_app_full_name
      }',
      user_app_icon_image_path='${
        updateUserAppMasterDto.user_app_icon_image_path ??
        user_app_icon_image_path
      }',

        user_app_development_status='${
          updateUserAppMasterDto.user_app_development_status ??
          user_app_development_status
        }'
       where user_app_id='${updateUserAppMasterDto.user_app_id}'`);

      let audit_trail_body = {
        user_app_id: updateUserAppMasterDto.user_app_id,
        user_app_activity: 'Edit App',
        user_app_activity_by_user_id: updateUserAppMasterDto.getster_id,
        user_app_activity_utc_date_time:
          updateUserAppMasterDto.user_app_activity_utc_date_time,
      };
      await this.insertUserAppAuditTrailDto(audit_trail_body);
      return result;
    } catch (err) {
      throw err;
    }
  }

  async updateUserAppDevelopmentStatus(
    updateUserAppDevelopmentStatus: UpdateUserAppDevelopmentStatusDto,
  ): Promise<boolean> {
    try {
      const result = await this.userAppMasterRepository.update(
        updateUserAppDevelopmentStatus.user_app_id,
        updateUserAppDevelopmentStatus,
      );
      return result ? true : false;
    } catch (err) {
      throw err;
    }
  }

  async checkUserAppMasterExist(user_app_full_name: string): Promise<boolean> {
    try {
      const user = await this.userAppMasterRepository.findOne({
        where: { user_app_full_name: user_app_full_name },
      });
      return user ? true : false;
    } catch (err) {
      throw err;
    }
  }

  async getAllUserAppAuditTrail(): Promise<any> {
    try {
      let audit_trail = await this.userAppMasterRepository.query(`
      SELECT * FROM wow_user_app_db.user_apps_audit_trail;
  `);

      let result: any[] = [];
      for (let i = 0; i < audit_trail.length; i++) {
        let user_app_icon_name = await this.userAppMasterRepository.query(`
      SELECT * FROM wow_user_app_db.user_app_master where user_app_id = '${audit_trail[i].user_app_id}';`);

        let profile_name = await this.userAppMasterRepository.query(`
        SELECT * FROM in_manage_get_wow_education_db.getster_profile where getster_id = '${audit_trail[i].user_app_activity_by_user_id}';`);

        // if (user_app_icon_name.length > 0) {
        //   result.push({
        //     user_app_id: audit_trail[i].user_app_id,
        //     user_app_activity: audit_trail[i].user_app_activity,
        //     user_app_activity_by_user_id:
        //       audit_trail[i].user_app_activity_by_user_id,
        //     user_app_activity_utc_date_time:
        //       audit_trail[i].user_app_activity_utc_date_time,
        //     user_app_icon_name: user_app_icon_name[0].user_app_icon_name,
        //     first_name: profile_name[0].first_name,
        //   });
        // }
      }
      return result;
    } catch (err) {
      throw err;
    }
  }

  // async getAllUserAppsByCategoryWise(): Promise<any> {
  //   try {
  //     // let connection = getConnection('user_app_db');
  //     let get_all_user_apps = await this.userAppMasterRepository.query(`
  //     SELECT
  //     master.custom_app_id,
  //     master.custom_app_icon_name,
  //     master.custom_app_icon_image_path,
  //     master.custom_app_full_name,
  //     master.custom_app_development_status,
  //     assign.user_app_category_location,
  //     assign.user_app_educational_institution_category_id,
  //     assign.user_app_country_code,
  //     assign.custom_app_id,
  //     catLoc.user_app_category_name as CategoryName,
  //     catLoc.user_app_category_name as user_app_category_name,
  //     catLoc.parent_user_app_category_id,
  //     catLoc.user_app_category_id
  //     FROM wow_custom_app_db.custom_app_master  master
  //     join
  //     wow_user_app_db.user_app_country_educational_institution_category_location assign on  master.custom_app_id = assign.custom_app_id
  //     join
  //     wow_user_app_db.user_app_categories catLoc  on assign.user_app_category_id=catLoc.user_app_category_id
  //         `);

  //     let get_all_category = await this.userAppMasterRepository.query(
  //       `SELECT * FROM wow_user_app_db.user_app_categories;`,
  //     );

  //     let body: any[] = [];
  //     let main_count = 0;
  //     for (let i = 0; i < get_all_category.length; i++) {
  //       let user_app_category_name = get_all_category[i].user_app_category_name;
  //       let data: any[] = [];

  //       let app_count = 0;
  //       for (let j = 0; j < get_all_user_apps.length; j++) {
  //         if (
  //           get_all_category[i].user_app_category_id ===
  //             get_all_user_apps[j].user_app_category_id &&
  //           get_all_user_apps[j].custom_app_id != null
  //         ) {
  //           if (app_count === 0) {
  //             data.push(get_all_user_apps[j]);
  //             app_count++;
  //           }

  //           let valid: boolean = false;
  //           for (let k = 0; k < data.length; k++) {
  //             if (
  //               data[k].custom_app_id === get_all_user_apps[j].custom_app_id &&
  //               data[k].user_app_category_id ===
  //                 get_all_user_apps[j].user_app_category_id
  //             ) {
  //               valid = true;
  //             } else {
  //             }
  //           }
  //           if (!valid) {
  //             data.push(get_all_user_apps[j]);
  //           }
  //           //
  //         }
  //       }

  //       main_count++;
  //       if (main_count > i && data.length != 0) {
  //         body.push({
  //           user_app_category_name: user_app_category_name,
  //           data: data,
  //         });
  //       }
  //       user_app_category_name = null;
  //       data = [null];
  //     }

  //     return await body;
  //   } catch (err) {
  //     throw err;
  //   }
  // }

  async getAllUserAppByUserAppCategoryID(
    user_app_category_id: any,
  ): Promise<any> {
    try {
      // let connection = getConnection('wow_user_app_db');
      let get_all_user_apps = await this.userAppMasterRepository.query(`
            SELECT a.user_app_id,
            a.user_app_icon_name,
            a.user_app_icon_image_path,
            a.user_app_full_name,
            a.user_app_development_status,
            b.user_app_category_location,
            b.custom_app_id,
            d.user_app_educational_institution_category_id,
            c.user_app_category_name as CategoryName,
            c.user_app_category_name as user_app_category_name,
            c.parent_user_app_category_id,
            c.user_app_category_id
            from wow_user_app_db.user_app_master  a
            join
            wow_user_app_db.user_app_and_customapp_location_and_classify_user_app_category b on  a.user_app_id = b.user_app_id
            join
            wow_user_app_db.user_app_suitability_to_educational_institution_categories d on a.user_app_id = d.user_app_id
            join
            wow_user_app_db.user_app_categories c  on b.user_app_category_id=c.user_app_category_id;
          `);

      let category_id: any[] = user_app_category_id.split(',');
      let body: any[] = [];
      let main_count = 0;
      for (let i = 0; i < category_id.length; i++) {
        let user_app_category_name = await this.userAppMasterRepository.query(
          `SELECT * FROM wow_user_app_db.user_app_categories where user_app_category_id = '${category_id[i]}';`,
        );
        let data: any[] = [];

        for (let j = 0; j < get_all_user_apps.length; j++) {
          if (category_id[i] === get_all_user_apps[j].user_app_category_id) {
            data.push(get_all_user_apps[j]);
          }
        }
        main_count++;
        if (main_count > i && data.length != 0) {
          body.push({
            user_app_category_name:
              user_app_category_name[0].user_app_category_name,
            data: data,
          });
        }
        user_app_category_name = null;
        data = [null];
      }

      return await body;
    } catch (err) {
      throw err;
    }
  }

  async getUserAppById(user_app_id: number): Promise<any[]> {
    try {
      // let connection = getConnection('wow_user_app_db');
      let get_all_user_apps = await this.userAppMasterRepository.query(
        `SELECT * FROM wow_user_app_db.user_app_master where user_app_id= ${user_app_id}`,
      );

      let userAppCategoryIdList = await this.userAppMasterRepository.query(`
        SELECT a.*,b.user_app_educational_institution_category_id FROM wow_user_app_db.user_app_and_customapp_location_and_classify_user_app_category a
        left join wow_user_app_db.user_app_suitability_to_educational_institution_categories b on a.user_app_id=b.user_app_id
        WHERE a.user_app_id=${user_app_id};
      `);

      let categoryIdList: any[] = [];
      for (let i = 0; i < userAppCategoryIdList.length; i++) {
        const element = userAppCategoryIdList[i].user_app_category_id;
        categoryIdList.push(element);
      }
      return [
        {
          ...get_all_user_apps[0],
          user_app_category_ids: categoryIdList.toString(),
        },
      ];

      // return get_all_user_apps;
    } catch (err) {
      throw err;
    }
  }
}
