import { Column, Entity, PrimaryColumn, PrimaryGeneratedColumn } from 'typeorm';

@Entity({
  database: 'wow_user_app_db',
  name: 'getbiz_app_launch_Screen_display',
})
export class GetbizAppLaunchScreenDisplay {
  @PrimaryColumn()
  user_app_id: number;

  @Column({
    length: 50,
  })
  user_app_launch_screen_mobile_image_file_name: string;

  @Column({
    length: 50,
  })
  user_app_launch_screen_desktop_image_file_name: string;

  @Column({
    length: 150,
  })
  user_app_launch_screen_text1: string;

  @Column({
    length: 150,
  })
  user_app_launch_screen_text2: string;

  @Column({
    length: 150,
  })
  user_app_launch_screen_text3: string;

  @Column()
  user_app_launch_screen_location: number;
}
