import { Column, Entity, PrimaryColumn, PrimaryGeneratedColumn } from 'typeorm';

@Entity({ database: 'wow_user_app_db', name: 'user_apps_audit_trail' })
export class UserAppsAuditTrail {
  @PrimaryGeneratedColumn('increment')
  id: number;

  @Column()
  user_app_id: number;

  @Column({ length: 20 })
  user_app_activity: string;

  @Column()
  user_app_activity_by_user_id: string;

  @Column({ length: 30 })
  user_app_activity_utc_date_time: string;
}
