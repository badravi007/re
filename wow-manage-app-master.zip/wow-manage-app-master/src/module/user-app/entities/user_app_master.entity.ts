import { Column, Entity, PrimaryGeneratedColumn } from 'typeorm';

@Entity({ database: 'wow_user_app_db', name: 'user_app_master' })
export class UserAppMaster {
  @PrimaryGeneratedColumn('increment')
  user_app_id: number;

  @Column({
    type: 'varchar',
    length: 100,
  })
  user_app_icon_name: string;

  @Column({
    type: 'varchar',
    length: 255,
  })
  user_app_full_name: string;

  @Column({
    type: 'varchar',
    length: 255,
  })
  user_app_icon_image_path: string;

  // @Column({
  //   type: 'varchar',
  //   length: 100,
  // })
  // user_app_title_bar_name: string;

  @Column()
  user_app_development_status: boolean;
}
