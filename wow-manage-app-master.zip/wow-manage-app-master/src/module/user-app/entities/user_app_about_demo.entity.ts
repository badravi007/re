import { Column, Entity, PrimaryColumn } from 'typeorm';

@Entity({ database: 'wow_user_app_db', name: 'user_app_about_demo' })
export class UserAppAboutDemo {
  @PrimaryColumn()
  user_app_id: number;

  @Column({
    length: 255,
  })
  user_app_demo_video_thumb_nail_path: string;

  @Column({
    length: 255,
  })
  user_app_demo_video_path: string;

  @Column({
    type: 'json',
  })
  user_app_datetime_description: TimeStampDescription[];

  @Column({
    type: 'json',
  })
  user_app_attachments_path: object[];
}

class TimeStampDescription {
  description: string;
  title: string;
  time_stamp: string;
}
