import { Column, Entity, PrimaryGeneratedColumn } from 'typeorm';

@Entity({
  database: 'wow_user_app_db',
  name: 'user_app_educational_institutions_category_about_demo',
})
export class UserAppEducationalInstitutionsCategoryAboutDemo {
  @PrimaryGeneratedColumn('increment')
  id: number;

  @Column()
  user_app_educational_institution_category_id: number;

  @Column({
    type: 'varchar',
    length: 100,
  })
  user_app_educational_institution_category_demo_video_thumb_nail: string;

  @Column({
    type: 'varchar',
    length: 255,
  })
  user_app_educational_institution_category_demo_video_path: string;

  @Column({
    type: 'json',
  })
  user_app_educational_institution_category_description_datetime: object[];
}
