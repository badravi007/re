import { Column, Entity, PrimaryColumn, PrimaryGeneratedColumn } from 'typeorm';

@Entity({ database: 'wow_user_app_db', name: 'user_app_categories' })
export class UserAppCategory {
  @PrimaryGeneratedColumn('increment')
  id: number;

  @Column({ length: 50 })
  user_app_category_id: string;

  @Column({ length: 50, nullable: true })
  parent_user_app_category_id: string;

  @Column({ length: 50 })
  user_app_category_name: string;

  @Column()
  is_the_user_app_category_hidden: boolean;

  @Column({ nullable: true })
  user_app_category_type: number;
}
