import { Column, Entity, PrimaryColumn, PrimaryGeneratedColumn } from 'typeorm';

@Entity({
  database: 'wow_user_app_db',
  name: 'user_app_cloud_file_storage_permission',
})
export class UserAppCloudFileStoragePermissions {
  @PrimaryColumn()
  user_app_id: number;

  @Column()
  delete_folder: boolean;

  @Column()
  delete_files: boolean;

  @Column()
  copy_files: boolean;
}
