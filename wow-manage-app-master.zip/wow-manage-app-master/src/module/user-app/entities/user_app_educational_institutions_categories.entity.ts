import { Column, Entity, PrimaryColumn, PrimaryGeneratedColumn } from 'typeorm';

@Entity({
  database: 'wow_user_app_db',
  name: 'user_app_educational_institutions_categories',
})
export class UserAppEducationalInstitutionsCategory {
  @PrimaryGeneratedColumn('increment')
  id: number;

  @Column({ length: 3 })
  country_code: string;

  @Column({ length: 50 })
  user_app_educational_institution_category_id: string;

  @Column({ length: 50, nullable: true })
  parent_user_app_educational_institution_category_id: string;

  @Column({ length: 50 })
  user_app_educational_institution_category_name: string;

  @Column()
  is_user_app_educational_institution_category_hidden: boolean;

  @Column({ nullable: true })
  user_app_educational_institution_category_type: number;
}
