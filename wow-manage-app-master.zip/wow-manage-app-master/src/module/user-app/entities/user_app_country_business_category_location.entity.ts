import { Column, Entity, PrimaryColumn, PrimaryGeneratedColumn } from 'typeorm';

@Entity({
  database: 'wow_user_app_db',
  name: 'user_app_country_educational_institution_category_location',
})
export class UserAppCountryBusinessCategoryLocation {
  @PrimaryGeneratedColumn('increment')
  id: number;

  @Column({ nullable: true, length: 50 })
  user_app_educational_institution_category_id: string;

  @Column({ nullable: true, length: 50 })
  user_app_category_id: string;

  @Column({ nullable: true })
  user_app_id: number;

  @Column({ nullable: true })
  custom_app_id: number;

  @Column({ nullable: true })
  user_app_category_location: number;

  @Column({ nullable: true })
  is_hidden: boolean;
}
