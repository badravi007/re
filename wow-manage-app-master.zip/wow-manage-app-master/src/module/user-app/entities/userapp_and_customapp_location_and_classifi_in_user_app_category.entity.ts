import { Column, Entity, PrimaryGeneratedColumn } from 'typeorm';

@Entity({
  database: 'wow_user_app_db',
  name: 'user_app_and_customapp_location_and_classify_user_app_category',
})
export class userappAndCustomappLocationAndClassifiInUserAppCategory {
  @PrimaryGeneratedColumn('increment')
  id: number;

  @Column({ nullable: true })
  user_app_id: number;

  @Column({ nullable: true })
  custom_app_id: number;

  @Column({
    length: 100,
    type: 'varchar',
  })
  user_app_category_id: string;

  @Column({ nullable: true })
  user_app_category_location: number;
}
