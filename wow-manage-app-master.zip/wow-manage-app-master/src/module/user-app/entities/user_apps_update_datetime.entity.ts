import { Column, Entity, PrimaryGeneratedColumn } from 'typeorm';

@Entity({ database: 'wow_user_app_db', name: 'user_apps_update_datetime' })
export class UserAppsUpdateDateTime {
  @PrimaryGeneratedColumn('increment')
  id: number;

  @Column({
    type: 'varchar',
    length: 255,
  })
  user_apps_update_utc_datetime: string;
}
