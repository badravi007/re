import { Column, Entity, PrimaryColumn, PrimaryGeneratedColumn } from 'typeorm';

@Entity({ database: 'wow_user_app_db', name: 'business_category_audit_trail' })
export class BusinessCategoryAuditTrail {
  @PrimaryGeneratedColumn('increment')
  id: number;

  @Column()
  user_app_business_category_id: string;

  @Column({ length: 20 })
  user_app_activity: string;

  @Column()
  user_app_activity_by_user_id: number;

  @Column({ length: 30 })
  user_app_activity_utc_date_time: string;
}
