import { Column, Entity, PrimaryGeneratedColumn } from 'typeorm';

@Entity({
  database: 'wow_user_app_db',
  name: 'user_app_suitability_to_educational_institution_categories',
})
export class userAppSuitabilityToEducationalInstitutionCategories {
  @PrimaryGeneratedColumn('increment')
  id: number;

  @Column()
  user_app_id: number;

  @Column()
  user_app_educational_institution_category_id: number;
}
