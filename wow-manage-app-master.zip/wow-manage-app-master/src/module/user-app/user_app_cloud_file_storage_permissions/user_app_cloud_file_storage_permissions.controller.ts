/*
https://docs.nestjs.com/controllers#controllers
*/

import { Body, Controller, Get, Post, Put, Query } from '@nestjs/common';
import { ApiTags } from '@nestjs/swagger';
import ResponseInterface from 'src/common/interface/response.interface';
import { UserAppCloudFileStoragePermissionsDto } from '../dto/user_app_cloud_file_storage_permissions.dto';
import { User_app_cloud_file_storage_permissionsService } from './user_app_cloud_file_storage_permissions.service';

// @UseGuards(JwtAuthGuard)
// @ApiBearerAuth('JWT-auth')
@ApiTags('User App Cloud Storage Permission')
@Controller('user_app_cloud_storage_permission')
export class User_app_cloud_file_storage_permissionsController {
  constructor(
    private readonly userAppCategoryService: User_app_cloud_file_storage_permissionsService,
  ) {}

  // @UseGuards(JwtAuthGuard)
  @Post('/add_update_user_app_cloud_file_storage_permission')
  async createUserAppAboutDemo(
    @Body() userAppAboutDemoDto: UserAppCloudFileStoragePermissionsDto,
  ): Promise<ResponseInterface> {
    const alreadyExists =
      await this.userAppCategoryService.checkUserAppCloudFileStoragePermissionExist(
        userAppAboutDemoDto.user_app_id,
      );
    if (alreadyExists) {
      const result =
        await this.userAppCategoryService.updateUserAppCloudFileStoragePermission(
          userAppAboutDemoDto,
        );
      return {
        statusCode: 200,
        message: `Updated User App Cloud File Storage Permission Successfully!`,
        data: result,
      };
    } else {
      const result =
        await this.userAppCategoryService.createUserAppCloudFileStoragePermission(
          userAppAboutDemoDto,
        );
      return {
        statusCode: 200,
        message: `User App Cloud File Storage Permission Created Successfully!`,
        data: result,
      };
    }
  }

  // @UseGuards(JwtAuthGuard)
  @Get('/get_user_app_cloud_storage_permission')
  async getUserAppAboutDemo(
    @Query('user_app_id') user_app_id: number,
  ): Promise<any> {
    const result =
      await this.userAppCategoryService.getUserAppCloudFileStoragePermission(
        user_app_id,
      );
    return {
      statusCode: 200,
      message: `Get User App Cloud File Storage Permission Video Successfully!`,
      data: result,
    };
  }

  // @UseGuards(JwtAuthGuard)
  @Put('/update_user_app_cloud_storage_permission')
  async updateUserAppAboutDemo(
    @Body() userAppAboutDemoDto: UserAppCloudFileStoragePermissionsDto,
  ): Promise<ResponseInterface> {
    const result =
      await this.userAppCategoryService.updateUserAppCloudFileStoragePermission(
        userAppAboutDemoDto,
      );
    return {
      statusCode: 200,
      message: `Updated User App Cloud File Storage PermissionF Video Successfully!`,
      data: result,
    };
  }
}
