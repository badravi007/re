import { Injectable } from '@nestjs/common';
import { InjectConnection, InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { UserAppCloudFileStoragePermissionsDto } from '../dto/user_app_cloud_file_storage_permissions.dto';
import { UserAppCloudFileStoragePermissions } from '../entities/user_app_cloud_file_storage_permissions.entity';

@Injectable()
export class User_app_cloud_file_storage_permissionsService {
  constructor(
    @InjectRepository(UserAppCloudFileStoragePermissions, 'wow_user_app_db')
    @InjectConnection('wow_user_app_db')
    private readonly userAppCloudFileStoragePermissionRepository: Repository<UserAppCloudFileStoragePermissions>,
  ) {}

  async createUserAppCloudFileStoragePermission(
    userAppCloudFileStoragePermissionDemoDto: UserAppCloudFileStoragePermissionsDto,
  ): Promise<UserAppCloudFileStoragePermissionsDto> {
    try {
      return await this.userAppCloudFileStoragePermissionRepository.save(
        userAppCloudFileStoragePermissionDemoDto,
      );
    } catch (err) {
      throw err;
    }
  }

  async updateUserAppCloudFileStoragePermission(
    userAppCloudFileStoragePermissionDemoDto: UserAppCloudFileStoragePermissionsDto,
  ): Promise<UserAppCloudFileStoragePermissionsDto> {
    try {
      await this.userAppCloudFileStoragePermissionRepository.update(
        userAppCloudFileStoragePermissionDemoDto.user_app_id,
        userAppCloudFileStoragePermissionDemoDto,
      );
      return this.userAppCloudFileStoragePermissionRepository.findOne({
        where: {
          user_app_id: userAppCloudFileStoragePermissionDemoDto.user_app_id,
        },
      });
    } catch (err) {
      throw err;
    }
  }
  async getUserAppCloudFileStoragePermission(
    user_app_id: number,
  ): Promise<UserAppCloudFileStoragePermissionsDto> {
    try {
      return await this.userAppCloudFileStoragePermissionRepository.findOne({
        where: { user_app_id: user_app_id },
      });
    } catch (err) {
      throw err;
    }
  }

  async checkUserAppCloudFileStoragePermissionExist(
    user_app_id: number,
  ): Promise<boolean> {
    try {
      const user =
        await this.userAppCloudFileStoragePermissionRepository.findOne({
          where: { user_app_id: user_app_id },
        });
      return user ? true : false;
    } catch (err) {
      throw err;
    }
  }
}
