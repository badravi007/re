import { Injectable } from '@nestjs/common';
import { InjectConnection } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import {
  UserAppCommunicationDto,
  UserAppCommunicationUpdateDto,
} from '../dto/user_app_communication.dto';

@Injectable()
export class User_app_communicationService {
  constructor(
    @InjectConnection('wow_user_app_db')
    private readonly userAppCommunicationRepository: Repository<null>,
  ) {}

  async insertUserAppCommunication(
    user_app_id: number,
    userAppCommunication: UserAppCommunicationDto,
  ): Promise<any> {
    return await this.userAppCommunicationRepository.query(
      `insert into ${user_app_id}_user_app_communication values(
        0,'${userAppCommunication.communication_utc_date_time}', 
        ${userAppCommunication.user_id}, 
        '${userAppCommunication.communication_text}'
        );`,
    );
  }

  async updateUserAppCommunication(
    user_app_id: number,
    communication_id: number,
    userAppCommunication: UserAppCommunicationUpdateDto,
  ): Promise<any> {
    return await this.userAppCommunicationRepository.query(
      `update into ${user_app_id}_user_app_communication set communication_text ='${userAppCommunication.communication_text}' where  communication_id=${communication_id};`,
    );
  }

  async deleteUserAppCommunication(
    user_app_id: number,
    communication_id: number,
  ): Promise<any> {
    return await this.userAppCommunicationRepository.query(
      `delete from ${user_app_id}_user_app_communication where  communication_id = ${communication_id}`,
    );
  }

  async getUserAppCommunication(user_app_id: number): Promise<any> {
    try {
      let mysql = require('mysql2');
      return this.userAppCommunicationRepository.query(
        `select * from ${user_app_id}_user_app_communication;`,
      );
    } catch (err) {
      throw err;
    }
  }
}
