/*
https://docs.nestjs.com/controllers#controllers
*/

import {
  Body,
  Controller,
  Delete,
  Get,
  HttpStatus,
  Post,
  Put,
  Query,
} from '@nestjs/common';
import { ApiTags } from '@nestjs/swagger';
import ResponseInterface from 'src/common/interface/response.interface';
import {
  UserAppCommunicationDto,
  UserAppCommunicationUpdateDto,
} from '../dto/user_app_communication.dto';
import { User_app_communicationService } from './user_app_communication.service';

// @UseGuards(JwtAuthGuard)
// @ApiBearerAuth('JWT-auth')
@ApiTags('User App Communication')
@Controller('user_app_communication')
export class User_app_communicationController {
  constructor(
    private readonly userAppCommunicationService: User_app_communicationService,
  ) {}

  @Post('/add_user_app_communication?')
  async insertUserAppCommunication(
    @Query('user_app_id') user_app_id: number,
    @Body() userAPpCommunicationDto: UserAppCommunicationDto,
  ): Promise<ResponseInterface> {
    const result =
      await this.userAppCommunicationService.insertUserAppCommunication(
        user_app_id,
        userAPpCommunicationDto,
      );
    return {
      statusCode: HttpStatus.CREATED,
      message: 'Sent successful!!',
      data: result,
    };
  }

  @Put('/update_user_app_communication?')
  async updateUserAppCommunication(
    @Query('user_app_id') user_app_id: number,
    @Query('communication_id') communication_id: number,
    @Body() userAPpCommunicationDto: UserAppCommunicationUpdateDto,
  ): Promise<ResponseInterface> {
    const result =
      await this.userAppCommunicationService.updateUserAppCommunication(
        user_app_id,
        communication_id,
        userAPpCommunicationDto,
      );
    return {
      statusCode: HttpStatus.CREATED,
      message: 'Updated successful !!',
      data: result,
    };
  }

  @Delete('/delete_user_app_communication?')
  async deleteUserAppCommunication(
    @Query('user_app_id') user_app_id: number,
    @Query('communication_id') communication_id: number,
  ): Promise<ResponseInterface> {
    const result =
      await this.userAppCommunicationService.deleteUserAppCommunication(
        user_app_id,
        communication_id,
      );
    return {
      statusCode: HttpStatus.CREATED,
      message: 'Deleted successful !!',
      data: result,
    };
  }
  @Get('/get_user_app_communication?')
  async getUserAppCommunication(
    @Query('user_app_id') user_app_id: number,
  ): Promise<ResponseInterface> {
    const result =
      await this.userAppCommunicationService.getUserAppCommunication(
        user_app_id,
      );
    return {
      statusCode: HttpStatus.CREATED,
      message: 'Get Communication successfully!!',
      data: result,
    };
  }
}
