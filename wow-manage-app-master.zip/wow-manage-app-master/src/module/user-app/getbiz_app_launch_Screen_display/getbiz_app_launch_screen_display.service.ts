/*
https://docs.nestjs.com/providers#services
*/

import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { unlink } from 'fs';
import * as mysql from 'mysql2';
import { Repository } from 'typeorm';
import { GetbizLaunchScreenDisplayDto } from '../dto/getbiz_app_launch_Screen_display.dto';
import { GetbizAppLaunchScreenDisplay } from '../entities/getbiz_app_launch_Screen_display.entity';

@Injectable()
export class Getbiz_app_launch_Screen_displayService {
  constructor(
    @InjectRepository(GetbizAppLaunchScreenDisplay, 'wow_user_app_db')
    private userAppGetbizLaunchScreenDisplayRepository: Repository<GetbizAppLaunchScreenDisplay>,
  ) {}
  private readonly; // @InjectConnection('wow_user_app_db')

  async createUserAppLaunchScreenDisplay(
    userAppGetbizLaunchScreenDisplayDto: GetbizLaunchScreenDisplayDto,
  ): Promise<GetbizLaunchScreenDisplayDto> {
    try {
      return await this.userAppGetbizLaunchScreenDisplayRepository.save(
        userAppGetbizLaunchScreenDisplayDto,
      );
    } catch (err) {
      throw err;
    }
  }

  async updateUserAppLaunchScreenDisplay(
    userAppGetbizLaunchScreenDisplayDto: GetbizLaunchScreenDisplayDto,
  ): Promise<any> {
    try {
      const {
        user_app_id,
        user_app_launch_screen_desktop_image_file_name,
        user_app_launch_screen_location,
        user_app_launch_screen_mobile_image_file_name,
        user_app_launch_screen_text1,
        user_app_launch_screen_text2,
        user_app_launch_screen_text3,
      } = userAppGetbizLaunchScreenDisplayDto;

      let appDetails = await this.userAppGetbizLaunchScreenDisplayRepository
        .query(
          `
          SELECT * FROM wow_user_app_db.getbiz_app_launch_screen_display
          WHERE user_app_id=${user_app_id}
        `,
        )
        .then((data) => data[0]);

      if (appDetails) {
        const {
          user_app_launch_screen_desktop_image_file_name:
            get_user_app_launch_screen_desktop_image_file_name,

          user_app_launch_screen_mobile_image_file_name:
            get_user_app_launch_screen_mobile_image_file_name,

          user_app_launch_screen_location: get_user_app_launch_screen_location,

          user_app_launch_screen_text1: get_user_app_launch_screen_text1,
          user_app_launch_screen_text2: get_user_app_launch_screen_text2,
          user_app_launch_screen_text3: get_user_app_launch_screen_text3,
        } = appDetails;

        unlink(
          './src/assets/getster/' +
            get_user_app_launch_screen_desktop_image_file_name,
          (err) => {
            if (err) {
              console.error(err);
            }
          },
        );

        unlink(
          './src/assets/getster/' +
            get_user_app_launch_screen_mobile_image_file_name,
          (err) => {
            if (err) {
              console.error(err);
            }
          },
        );

        await this.userAppGetbizLaunchScreenDisplayRepository.query(`
          UPDATE wow_user_app_db.getbiz_app_launch_screen_display
          SET
          user_app_id = ${user_app_id},
          user_app_launch_screen_mobile_image_file_name = ${mysql.escape(
            user_app_launch_screen_mobile_image_file_name != 'undefined'
              ? user_app_launch_screen_mobile_image_file_name
              : get_user_app_launch_screen_mobile_image_file_name,
          )},
          user_app_launch_screen_desktop_image_file_name = ${mysql.escape(
            user_app_launch_screen_desktop_image_file_name != 'undefined'
              ? user_app_launch_screen_desktop_image_file_name
              : get_user_app_launch_screen_desktop_image_file_name,
          )},
          user_app_launch_screen_text1 = ${mysql.escape(
            user_app_launch_screen_text1 ?? get_user_app_launch_screen_text1,
          )},
          user_app_launch_screen_text2 = ${mysql.escape(
            user_app_launch_screen_text2 ?? get_user_app_launch_screen_text2,
          )},
          user_app_launch_screen_text3 = ${mysql.escape(
            user_app_launch_screen_text3 ?? get_user_app_launch_screen_text3,
          )},
          user_app_launch_screen_location = ${mysql.escape(
            user_app_launch_screen_location ??
              get_user_app_launch_screen_location,
          )}
          WHERE user_app_id = ${user_app_id}
        `);
      } else {
        await this.userAppGetbizLaunchScreenDisplayRepository.query(`
        INSERT INTO wow_user_app_db.getbiz_app_launch_screen_display
          (user_app_id,
          user_app_launch_screen_mobile_image_file_name,
          user_app_launch_screen_desktop_image_file_name,
          user_app_launch_screen_text1,
          user_app_launch_screen_text2,
          user_app_launch_screen_text3,
          user_app_launch_screen_location)
          VALUES
          (${mysql.escape(user_app_id)},
          ${mysql.escape(user_app_launch_screen_mobile_image_file_name)},
          ${mysql.escape(user_app_launch_screen_desktop_image_file_name)},
          ${mysql.escape(user_app_launch_screen_text1)},
          ${mysql.escape(user_app_launch_screen_text2)},
          ${mysql.escape(user_app_launch_screen_text3)},
          ${mysql.escape(user_app_launch_screen_location)});
      `);
      }

      return this.userAppGetbizLaunchScreenDisplayRepository.findOne({
        where: { user_app_id: userAppGetbizLaunchScreenDisplayDto.user_app_id },
      });
    } catch (error) {
      throw error;
    }
  }
  async getUserAppLaunchScreenDisplay(
    user_app_id: number,
  ): Promise<GetbizLaunchScreenDisplayDto> {
    try {
      return await this.userAppGetbizLaunchScreenDisplayRepository.findOne({
        where: { user_app_id: user_app_id },
      });
    } catch (err) {
      throw err;
    }
  }

  async checkUserAppLaunchScreenDisplayExist(
    user_app_id: number,
  ): Promise<boolean> {
    try {
      const user =
        await this.userAppGetbizLaunchScreenDisplayRepository.findOne({
          where: { user_app_id: user_app_id },
        });
      return user ? true : false;
    } catch (err) {
      throw err;
    }
  }
}
