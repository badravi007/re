/*
https://docs.nestjs.com/controllers#controllers
*/

import {
  Body,
  Controller,
  Get,
  NotFoundException,
  Post,
  Put,
  Query,
  Res,
  UploadedFiles,
  UseInterceptors,
} from '@nestjs/common';
import { FileFieldsInterceptor } from '@nestjs/platform-express';
import { ApiBody, ApiConsumes, ApiTags } from '@nestjs/swagger';
import { existsSync } from 'fs';
import { diskStorage } from 'multer';
import {
  editFileName,
  imageFileFilter,
} from 'src/shared/utils/file-upload.utils';
import { GetbizLaunchScreenDisplayDto } from '../dto/getbiz_app_launch_Screen_display.dto';
import { Getbiz_app_launch_Screen_displayService } from './getbiz_app_launch_screen_display.service';

// @UseGuards(JwtAuthGuard)
// @ApiBearerAuth('JWT-auth')
@ApiTags('User App Getbiz Launch Screen Display')
@Controller('getbiz_app_launch_Screen_display')
export class Getbiz_app_launch_Screen_displayController {
  constructor(
    private readonly userAppGetbizLaunchScreenDisplayService: Getbiz_app_launch_Screen_displayService,
  ) {}

  // @UseGuards(JwtAuthGuard)
  @Post('/add_update_user_app_launch_screen_display')
  @ApiConsumes('multipart/form-data')
  // @ApiConsumes('application/json')
  @ApiBody({ type: GetbizLaunchScreenDisplayDto, required: true })
  @UseInterceptors(
    FileFieldsInterceptor(
      [
        { name: 'user_app_launch_screen_mobile_image_file_name', maxCount: 1 },
        { name: 'user_app_launch_screen_desktop_image_file_name', maxCount: 1 },
      ],
      {
        storage: diskStorage({
          destination: './src/assets/getster',
          filename: editFileName,
        }),
        fileFilter: imageFileFilter,
      },
    ),
  )
  async createUserAppLaunchScreenDisplay(
    @Body() userAppGetbizLaunchScreenDisplayDto: GetbizLaunchScreenDisplayDto,
    @UploadedFiles()
    files: {
      user_app_launch_screen_mobile_image_file_name?: Express.Multer.File[];
      user_app_launch_screen_desktop_image_file_name?: Express.Multer.File[];
    },
  ): Promise<any> {
    userAppGetbizLaunchScreenDisplayDto.user_app_launch_screen_mobile_image_file_name =
      files.user_app_launch_screen_mobile_image_file_name[0].filename;
    userAppGetbizLaunchScreenDisplayDto.user_app_launch_screen_desktop_image_file_name =
      files.user_app_launch_screen_desktop_image_file_name[0].filename;

    const alreadyExists =
      await this.userAppGetbizLaunchScreenDisplayService.checkUserAppLaunchScreenDisplayExist(
        userAppGetbizLaunchScreenDisplayDto.user_app_id,
      );

    if (alreadyExists) {
      const result =
        await this.userAppGetbizLaunchScreenDisplayService.updateUserAppLaunchScreenDisplay(
          userAppGetbizLaunchScreenDisplayDto,
        );
      return {
        statusCode: 200,
        message: `Updated User App Getbiz Launch Screen Display Successfully!`,
        data: result,
      };
    } else {
      const result =
        await this.userAppGetbizLaunchScreenDisplayService.createUserAppLaunchScreenDisplay(
          userAppGetbizLaunchScreenDisplayDto,
        );
      return {
        statusCode: 200,
        message: `User App Getbiz Launch Screen Display Created Successfully!`,
        data: result,
      };
    }
  }

  // @UseGuards(JwtAuthGuard)
  @Get('/get_user_app_launch_screen_display')
  async getUserAppLaunchScreenDisplay(
    @Query('user_app_id') user_app_id: number,
  ): Promise<any> {
    const result =
      await this.userAppGetbizLaunchScreenDisplayService.getUserAppLaunchScreenDisplay(
        user_app_id,
      );
    return {
      statusCode: 200,
      message: `Get User App Getbiz Launch Screen Display Successfully!`,
      data: result,
    };
  }

  // @UseGuards(JwtAuthGuard)
  @Put('/update_user_app_launch_screen_display')
  @ApiConsumes('multipart/form-data')
  // @ApiConsumes('application/json')
  @ApiBody({ type: GetbizLaunchScreenDisplayDto, required: true })
  @UseInterceptors(
    FileFieldsInterceptor(
      [
        { name: 'user_app_launch_screen_mobile_image_file_name', maxCount: 1 },
        { name: 'user_app_launch_screen_desktop_image_file_name', maxCount: 1 },
      ],
      {
        storage: diskStorage({
          destination: './src/assets/getster',
          filename: editFileName,
        }),
        fileFilter: imageFileFilter,
      },
    ),
  )
  async updateUserAppLaunchScreenDisplay(
    @Body() userAppAboutDemoDto: GetbizLaunchScreenDisplayDto,
    @UploadedFiles()
    files: {
      user_app_launch_screen_mobile_image_file_name?: Express.Multer.File[];
      user_app_launch_screen_desktop_image_file_name?: Express.Multer.File[];
    },
  ): Promise<any> {
    try {
      if (
        userAppAboutDemoDto?.user_app_launch_screen_mobile_image_file_name !=
          'undefined' &&
        userAppAboutDemoDto?.user_app_launch_screen_desktop_image_file_name !=
          'undefined'
      ) {
        userAppAboutDemoDto.user_app_launch_screen_mobile_image_file_name =
          files.user_app_launch_screen_mobile_image_file_name[0].filename;
        userAppAboutDemoDto.user_app_launch_screen_desktop_image_file_name =
          files.user_app_launch_screen_desktop_image_file_name[0].filename;
      }

      const result =
        await this.userAppGetbizLaunchScreenDisplayService.updateUserAppLaunchScreenDisplay(
          userAppAboutDemoDto,
        );
      return {
        statusCode: 200,
        message: `Updated User App Getbiz Launch Screen Display Successfully!`,
        data: result,
      };
    } catch (error) {
      throw error;
    }
  }

  @Get('/get_file_user_app_launch_screen_display')
  async getFileUserAppMaster(
    @Query('file_name') file_name: string,
    @Res() res,
  ): Promise<any> {
    try {
      if (!existsSync(`src/assets/getster/${file_name}`)) {
        throw new NotFoundException();
      }
      return res.sendFile(file_name, {
        root: 'src/assets/getster',
      });
    } catch (error) {
      throw error.response;
    }
  }
}
