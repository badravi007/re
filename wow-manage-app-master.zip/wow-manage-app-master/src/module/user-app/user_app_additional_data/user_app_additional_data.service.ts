/*
https://docs.nestjs.com/providers#services
*/

import { Injectable } from '@nestjs/common';
import { InjectConnection, InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { UserAppAdditionalDataDto } from '../dto/user_app_additional_data.dto';
import { UserAppAdditionalData } from '../entities/user_app_additional_data.entity';

@Injectable()
export class User_app_additional_dataService {
  constructor(
    @InjectRepository(UserAppAdditionalData, 'wow_user_app_db')
    @InjectConnection('wow_user_app_db')
    private readonly userAppAdditionalDataRepository: Repository<UserAppAdditionalData>,
  ) {}

  async createUserAppAdditionalData(
    userAppAdditionalDataDto: UserAppAdditionalDataDto,
  ): Promise<UserAppAdditionalDataDto> {
    try {
      return await this.userAppAdditionalDataRepository.save(
        userAppAdditionalDataDto,
      );
    } catch (err) {
      throw err;
    }
  }

  async updateUserAppAdditionalData(
    userAppAdditionalDataDto: UserAppAdditionalDataDto,
  ): Promise<UserAppAdditionalDataDto> {
    try {
      await this.userAppAdditionalDataRepository.update(
        userAppAdditionalDataDto.user_app_id,
        userAppAdditionalDataDto,
      );
      return this.userAppAdditionalDataRepository.findOne({
        where: { user_app_id: userAppAdditionalDataDto.user_app_id },
      });
    } catch (err) {
      throw err;
    }
  }

  async getUserAppAdditionalData(
    user_app_id: number,
  ): Promise<UserAppAdditionalDataDto> {
    try {
      return await this.userAppAdditionalDataRepository.findOne({
        where: { user_app_id: user_app_id },
      });
    } catch (err) {
      throw err;
    }
  }
  async checkUserAppAdditionalDataExist(user_app_id: number): Promise<boolean> {
    try {
      const user = await this.userAppAdditionalDataRepository.findOne({
        where: { user_app_id: user_app_id },
      });
      return user ? true : false;
    } catch (err) {
      throw err;
    }
  }
}
