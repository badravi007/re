import { Body, Controller, Get, Post, Put, Query } from '@nestjs/common';
import { ApiTags } from '@nestjs/swagger';
import ResponseInterface from 'src/common/interface/response.interface';
import { UserAppAdditionalDataDto } from '../dto/user_app_additional_data.dto';
import { User_app_additional_dataService } from './user_app_additional_data.service';

// @UseGuards(JwtAuthGuard)
// @ApiBearerAuth('JWT-auth')
@ApiTags('User App Additional Data')
@Controller('user_app_additional_data')
export class User_app_additional_dataController {
  constructor(
    private readonly userAppAdditionalDataService: User_app_additional_dataService,
  ) {}

  // @UseGuards(JwtAuthGuard)
  @Post('/add_user_app_additional_data')
  async createUserAppAboutDemo(
    @Body() userAppAdditionalDataDto: UserAppAdditionalDataDto,
  ): Promise<ResponseInterface> {
    const alreadyExists =
      await this.userAppAdditionalDataService.checkUserAppAdditionalDataExist(
        userAppAdditionalDataDto.user_app_id,
      );
    if (alreadyExists) {
      const result =
        await this.userAppAdditionalDataService.updateUserAppAdditionalData(
          userAppAdditionalDataDto,
        );
      return {
        statusCode: 200,
        message: `Updated User App Additional Data Successfully!`,
        data: result,
      };
    } else {
      const result =
        await this.userAppAdditionalDataService.createUserAppAdditionalData(
          userAppAdditionalDataDto,
        );
      return {
        statusCode: 200,
        message: `User App Additional Data Created Successfully!`,
        data: result,
      };
    }
  }

  // @UseGuards(JwtAuthGuard)
  @Get('/get_user_app_additional_data')
  async getUserAppAboutDemo(
    @Query('user_app_id') user_app_id: number,
  ): Promise<any> {
    const result =
      await this.userAppAdditionalDataService.getUserAppAdditionalData(
        user_app_id,
      );
    return {
      statusCode: 200,
      message: `Get User App Additional Data Successfully!`,
      data: result,
    };
  }

  // @UseGuards(JwtAuthGuard)
  @Put('/update_user_app_additional_data')
  async updateUserAppAboutDemo(
    @Body() userAppAdditionalDataDto: UserAppAdditionalDataDto,
  ): Promise<ResponseInterface> {
    const result =
      await this.userAppAdditionalDataService.updateUserAppAdditionalData(
        userAppAdditionalDataDto,
      );
    return {
      statusCode: 200,
      message: `Updated User App Additional Data Successfully!`,
      data: result,
    };
  }
}
