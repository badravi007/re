import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { AuthModule } from 'src/auth/auth.module';
import { DateTimeService } from 'src/shared/service/date-time.service';
import { GetbizAppLaunchScreenDisplay } from './entities/getbiz_app_launch_Screen_display.entity';
import { UserAppCategory } from './entities/user-app-category.entity';
import { UserAppAboutDemo } from './entities/user_app_about_demo.entity';
import { UserAppAdditionalData } from './entities/user_app_additional_data.entity';
import { UserAppCloudFileStoragePermissions } from './entities/user_app_cloud_file_storage_permissions.entity';
import { UserAppCountryBusinessCategoryLocation } from './entities/user_app_country_business_category_location.entity';
import { UserAppEducationalInstitutionsCategory } from './entities/user_app_educational_institutions_categories.entity';
import { UserAppEducationalInstitutionsCategoryAboutDemo } from './entities/user_app_educational_institutions_category_about_demo.entity';
import { UserAppMaster } from './entities/user_app_master.entity';
import { userAppSuitabilityToEducationalInstitutionCategories } from './entities/user_app_suitability_to_educational_institution_categories.entity';
import { UserAppsAuditTrail } from './entities/user_apps_audit_trail.entity';
import { UserAppsUpdateDateTime } from './entities/user_apps_update_datetime.entity';
import { userappAndCustomappLocationAndClassifiInUserAppCategory } from './entities/userapp_and_customapp_location_and_classifi_in_user_app_category.entity';
import { Getbiz_app_launch_Screen_displayController } from './getbiz_app_launch_Screen_display/getbiz_app_launch_screen_display.controller';
import { Getbiz_app_launch_Screen_displayService } from './getbiz_app_launch_Screen_display/getbiz_app_launch_screen_display.service';
import { User_app_about_demoController } from './user_app_about_demo/user_app_about_demo.controller';
import { User_app_about_demoService } from './user_app_about_demo/user_app_about_demo.service';
import { User_app_additional_dataController } from './user_app_additional_data/user_app_additional_data.controller';
import { User_app_additional_dataService } from './user_app_additional_data/user_app_additional_data.service';
import { User_app_categoriesController } from './user_app_categories/user_app_categories.controller';
import { User_app_categoriesService } from './user_app_categories/user_app_categories.service';
import { User_app_cloud_file_storage_permissionsController } from './user_app_cloud_file_storage_permissions/user_app_cloud_file_storage_permissions.controller';
import { User_app_cloud_file_storage_permissionsService } from './user_app_cloud_file_storage_permissions/user_app_cloud_file_storage_permissions.service';
import { User_app_commentsController } from './user_app_comments/user_app_comments.controller';
import { User_app_commentsService } from './user_app_comments/user_app_comments.service';
import { User_app_communicationController } from './user_app_communication/user_app_communication.controller';
import { User_app_communicationService } from './user_app_communication/user_app_communication.service';
import { User_app_country_business_category_locationController } from './user_app_country_business_category_location/user_app_country_business_category_location.controller';
import { User_app_country_business_category_locationService } from './user_app_country_business_category_location/user_app_country_business_category_location.service';
import { User_app_masterController } from './user_app_master/user_app_master.controller';
import { User_app_masterService } from './user_app_master/user_app_master.service';

@Module({
  imports: [
    TypeOrmModule.forFeature(
      [
        UserAppCountryBusinessCategoryLocation,
        UserAppsAuditTrail,
        UserAppCategory,
        UserAppAboutDemo,
        UserAppCloudFileStoragePermissions,
        UserAppAdditionalData,
        GetbizAppLaunchScreenDisplay,
        UserAppEducationalInstitutionsCategory,
        UserAppMaster,
        UserAppsUpdateDateTime,
        UserAppEducationalInstitutionsCategoryAboutDemo,
        userappAndCustomappLocationAndClassifiInUserAppCategory,
        userAppSuitabilityToEducationalInstitutionCategories,
      ],
      'wow_user_app_db',
    ),
    AuthModule,
  ],
  controllers: [
    User_app_country_business_category_locationController,
    User_app_masterController,
    User_app_categoriesController,
    User_app_about_demoController,
    User_app_cloud_file_storage_permissionsController,
    User_app_additional_dataController,
    Getbiz_app_launch_Screen_displayController,
    User_app_communicationController,
    User_app_commentsController,
  ],
  providers: [
    User_app_country_business_category_locationService,
    User_app_masterService,
    User_app_categoriesService,
    User_app_about_demoService,
    User_app_cloud_file_storage_permissionsService,
    User_app_additional_dataService,
    Getbiz_app_launch_Screen_displayService,
    User_app_communicationService,
    User_app_commentsService,
    DateTimeService,
  ],
  exports: [
    User_app_country_business_category_locationService,
    User_app_masterService,
    User_app_categoriesService,
    User_app_about_demoService,
    User_app_cloud_file_storage_permissionsService,
    User_app_additional_dataService,
    Getbiz_app_launch_Screen_displayService,
    User_app_communicationService,
    User_app_commentsService,
  ],
})
export class UserAppModule {}
