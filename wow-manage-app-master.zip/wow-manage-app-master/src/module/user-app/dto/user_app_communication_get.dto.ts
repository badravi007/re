import { ApiProperty } from '@nestjs/swagger';
import { Column, PrimaryColumn } from 'typeorm';

export class UserAppCommunicationGetDto {
  @ApiProperty()
  communication_utc_date_time: string;

  @ApiProperty()
  user_id: number;

  @ApiProperty()
  communication_text: number;
}
