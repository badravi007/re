import { ApiProperty } from '@nestjs/swagger';

export class UpdateUserAppDevelopmentStatusDto {
  @ApiProperty()
  user_app_id: number;

  @ApiProperty()
  user_app_development_status: boolean;
}
