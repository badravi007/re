import { ApiProperty } from '@nestjs/swagger';
import { Column, PrimaryColumn } from 'typeorm';

export class UserAppCategoryDto {
  @ApiProperty()
  user_app_category_id: string;

  @ApiProperty()
  parent_user_app_category_id: string | null;

  @ApiProperty()
  user_app_category_name: string;

  @ApiProperty()
  is_the_user_app_category_hidden: boolean;

  @ApiProperty()
  children: any;

  @ApiProperty()
  user_app_category_type: number;
}
