import { ApiProperty } from '@nestjs/swagger';

export class UserAppAdditionalDataDto {
  @ApiProperty()
  user_app_id: number;

  @ApiProperty()
  can_this_user_app_be_blocked_by_app_administrator: boolean;

  @ApiProperty()
  can_this_app_be_displayed_in_customerbizapp_launch_screen: boolean;

  @ApiProperty()
  does_this_app_have_configuration_data_specific_to_this_app: boolean;

  @ApiProperty()
  is_the_app_suitable_to_be_displayed_in_launch_screen: boolean;
}
