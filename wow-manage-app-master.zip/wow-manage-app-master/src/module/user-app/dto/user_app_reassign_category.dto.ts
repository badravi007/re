import { ApiProperty } from '@nestjs/swagger';

export class UserAppReassignCategoryDto {
  @ApiProperty()
  user_app_id: number;

  @ApiProperty()
  user_app_icon_name: string;

  @ApiProperty()
  user_app_full_name: string;

  @ApiProperty()
  user_app_icon_image_path: string;

  @ApiProperty()
  user_app_title_bar_name: string;

  @ApiProperty()
  user_app_development_status: boolean;

  @ApiProperty()
  user_app_category_location: number;

  @ApiProperty()
  user_app_business_category_id: string;

  @ApiProperty()
  user_app_country_code: string;

  @ApiProperty()
  custom_app_id: number;

  @ApiProperty()
  CategoryName: string;

  @ApiProperty()
  user_app_category_name: string;

  @ApiProperty()
  user_app_category_path: string;

  @ApiProperty()
  user_app_category_id: string;
}
