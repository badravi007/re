import { ApiProperty } from '@nestjs/swagger';

export class userappAndCustomappLocationAndClassifiInUserAppCategoryDto {
  @ApiProperty()
  id: number;
  @ApiProperty()
  user_app_id: number;
  @ApiProperty()
  custom_app_id: number;
  @ApiProperty()
  user_app_category_id: number;
  @ApiProperty()
  user_app_category_location: number;
}
