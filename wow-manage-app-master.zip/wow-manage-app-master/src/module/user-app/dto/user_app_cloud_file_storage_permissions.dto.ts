import { ApiProperty } from '@nestjs/swagger';

export class UserAppCloudFileStoragePermissionsDto {
  @ApiProperty()
  user_app_id: number;

  @ApiProperty()
  delete_folder: boolean;

  @ApiProperty()
  delete_files: boolean;

  @ApiProperty()
  copy_files: boolean;
}
