import { ApiProperty } from '@nestjs/swagger';

export class UserAppMasterDto {
  @ApiProperty()
  user_app_id: number;

  @ApiProperty()
  user_app_icon_name: string;

  @ApiProperty()
  user_app_full_name: string;

  @ApiProperty()
  user_app_icon_image_path: string;

  // @ApiProperty()
  // user_app_title_bar_name: string;

  @ApiProperty()
  user_app_development_status: boolean;
}

export class UserAppAuditTrailDto extends UserAppMasterDto {
  @ApiProperty()
  getster_id: string;

  @ApiProperty()
  user_app_activity_utc_date_time: string;
}
