import { ApiProperty } from "@nestjs/swagger";

export class UpdateUserAppMasterDto {
    @ApiProperty()
    user_app_id: number;

    @ApiProperty()
    user_app_icon_name: string;

    @ApiProperty()
    user_app_full_name: string;

    @ApiProperty()
    user_app_icon_image_path: string;
}