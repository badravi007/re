import { ApiProperty } from '@nestjs/swagger';
import { Column, PrimaryColumn } from 'typeorm';

export class BusinessCategoryAuditTrailDto {
  @ApiProperty()
  user_app_business_category_id: string;

  @ApiProperty()
  user_app_activity: string;

  @ApiProperty()
  user_app_activity_by_user_id: number;

  @ApiProperty()
  user_app_activity_utc_date_time: string;
}
