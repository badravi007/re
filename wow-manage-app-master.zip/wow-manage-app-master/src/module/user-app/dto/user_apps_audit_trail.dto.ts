import { ApiProperty } from '@nestjs/swagger';
import { Column, PrimaryColumn } from 'typeorm';

export class UserAppsAuditTrailDto {
  @ApiProperty()
  user_app_id: number;

  @ApiProperty()
  user_app_activity: string;

  @ApiProperty()
  user_app_activity_by_user_id: string;

  @ApiProperty()
  user_app_activity_utc_date_time: string;
}
