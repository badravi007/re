import { ApiProperty } from '@nestjs/swagger';

export class UserAppCountryBusinessCategoryLocationDto {
  @ApiProperty()
  id: number;

  @ApiProperty()
  user_app_educational_institution_category_id: string;

  @ApiProperty()
  user_app_id: number;

  @ApiProperty()
  custom_app_id: number;

  @ApiProperty()
  user_app_category_ids: string;

  @ApiProperty()
  user_app_category_location: number;

  @ApiProperty()
  is_hidden: boolean;
}
