import { ApiProperty } from '@nestjs/swagger';

export class UserAppAboutDemoDto {
  @ApiProperty()
  user_app_id: number;
  @ApiProperty()
  user_app_demo_video_thumb_nail_path: string;
  @ApiProperty()
  user_app_demo_video_path: string;
  @ApiProperty()
  user_app_datetime_description: TimeStampDescription[];
  @ApiProperty()
  user_app_attachments_path: object[];
}

class TimeStampDescription {
  @ApiProperty()
  description: string;
  @ApiProperty()
  title: string;
  @ApiProperty()
  time_stamp: string;
}
