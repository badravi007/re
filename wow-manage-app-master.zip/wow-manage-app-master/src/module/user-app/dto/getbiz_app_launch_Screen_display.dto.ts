import { ApiProperty } from '@nestjs/swagger';

export class GetbizLaunchScreenDisplayDto {
  @ApiProperty()
  user_app_id: number;

  @ApiProperty({ type: 'string', format: 'binary' })
  user_app_launch_screen_mobile_image_file_name: any;

  @ApiProperty({ type: 'string', format: 'binary' })
  user_app_launch_screen_desktop_image_file_name: any;

  @ApiProperty()
  user_app_launch_screen_text1: string;

  @ApiProperty()
  user_app_launch_screen_text2: string;

  @ApiProperty()
  user_app_launch_screen_text3: string;

  @ApiProperty()
  user_app_launch_screen_location: number;
}
