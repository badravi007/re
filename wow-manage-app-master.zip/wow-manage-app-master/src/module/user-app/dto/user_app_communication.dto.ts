import { ApiProperty } from '@nestjs/swagger';
import { Column, PrimaryColumn } from 'typeorm';

export class UserAppCommunicationDto {
  @ApiProperty()
  communication_utc_date_time: string;

  @ApiProperty()
  user_id: number;

  @ApiProperty()
  communication_text: string;
}

export class UserAppCommunicationUpdateDto extends UserAppCommunicationDto {
  @ApiProperty()
  comment_text: string;

  @ApiProperty()
  comment_utc_date_time: string;
}
