import { ApiProperty } from '@nestjs/swagger';
import { Column, PrimaryColumn } from 'typeorm';

export class UserAppCommentsGetDto {
  @ApiProperty()
  comment_utc_date_time: string;

  @ApiProperty()
  user_id: number;

  @ApiProperty()
  comment_text: string;

  @ApiProperty()
  is_the_comment_private: number;

  @ApiProperty()
  comment_reply: string;

  @ApiProperty()
  comment_reply_by_user_id: number;
}

export class UserAppCommentsUpdateDto {
  @ApiProperty()
  comment_text: string;

  @ApiProperty()
  comment_utc_date_time: string;
}

export class UserAppReplayCommentsDto {
  @ApiProperty()
  comment_reply: string;

  // @ApiProperty()
  // comment_utc_date_time: string;
}
