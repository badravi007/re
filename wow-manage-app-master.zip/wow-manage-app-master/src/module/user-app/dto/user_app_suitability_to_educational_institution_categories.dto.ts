import { ApiProperty } from '@nestjs/swagger';

export class userAppSuitabilityToEducationalInstitutionCategoriesDto {
  @ApiProperty()
  id: number;
  @ApiProperty()
  user_app_id: number;
  @ApiProperty()
  user_app_educational_institution_category_id: number;
}
