import { Injectable } from '@nestjs/common';
import { InjectConnection, InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import {
  UserAppCommentsGetDto,
  UserAppCommentsUpdateDto,
  UserAppReplayCommentsDto,
} from '../dto/user_app_comments.dto';

@Injectable()
export class User_app_commentsService {
  constructor(
    @InjectConnection('wow_user_app_db')
    private readonly userAppCommentsRepository: Repository<null>,
  ) {}

  async creatDynamicTable(user_app_id: number): Promise<any> {
    await this.userAppCommentsRepository.query(
      `create table ${user_app_id}_user_app_comments (comment_id int not null auto_increment, comment_utc_date_time varchar(30) not null,
      user_id  int not null,comment_text varchar(100) not null,is_the_comment_private int not null ,comment_reply varchar(100) null,
      comment_reply_by_user_id int null,primary key(comment_id));`,
    );

    await this.userAppCommentsRepository.query(
      `create table ${user_app_id}_user_app_communication (communication_id int not null auto_increment, communication_utc_date_time varchar(30) not null,
      user_id  int not null,	communication_text varchar(100) not null,primary key(communication_id));`,
    );

    return 'Success';
    // `call wow_user_app_db.sp_user_app_comments(${user_app_id}, 'create_table', 0, 'null', 0, 'null',false,'null',0)`,
  }

  async insertUserAppComments(
    user_app_id: number,
    userAppComments: UserAppCommentsGetDto,
  ): Promise<any> {
    return await this.userAppCommentsRepository.query(
      `insert into ${user_app_id}_user_app_comments values(
      0,'${userAppComments.comment_utc_date_time}', 
      ${userAppComments.user_id}, 
      '${userAppComments.comment_text}',
      ${userAppComments.is_the_comment_private},
      '${userAppComments.comment_reply}',
      ${userAppComments.comment_reply_by_user_id}
      )`,
    );
  }

  async updateUserAppComments(
    user_app_id: number,
    comment_id: number,
    update_comment_text: UserAppCommentsUpdateDto,
  ): Promise<any> {
    return await this.userAppCommentsRepository.query(
      `update ${user_app_id}_user_app_comments set comment_text ='${update_comment_text.comment_text}' where  comment_id=${comment_id};`,
    );
  }

  async updateUserAppCommentsType(
    user_app_id: number,
    comment_id: number,
    is_the_comment_private: number,
    body: UserAppReplayCommentsDto,
  ): Promise<any> {
    return await this.userAppCommentsRepository.query(
      `update ${user_app_id}_user_app_comments set 
      is_the_comment_private =${is_the_comment_private},
      comment_reply = '${body.comment_reply}'
      where  comment_id=${comment_id};`,
    );
  }

  async deleteUserAppComments(
    user_app_id: number,
    comment_id: number,
  ): Promise<any> {
    return await this.userAppCommentsRepository.query(
      `delete from ${user_app_id}_user_app_comments where  comment_id = ${comment_id}`,
    );
  }

  async getUserAppComments(
    user_app_id: number,
  ): Promise<UserAppCommentsGetDto> {
    try {
      return await this.userAppCommentsRepository.query(
        `select * from ${user_app_id}_user_app_comments;`,
      );
    } catch (err) {
      throw err;
    }
  }
}
