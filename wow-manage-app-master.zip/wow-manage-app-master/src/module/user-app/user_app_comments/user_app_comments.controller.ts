import {
  Body,
  Controller,
  Delete,
  Get,
  HttpStatus,
  Post,
  Put,
  Query,
} from '@nestjs/common';
import { ApiTags } from '@nestjs/swagger';
import ResponseInterface from 'src/common/interface/response.interface';
import {
  UserAppCommentsGetDto,
  UserAppCommentsUpdateDto,
  UserAppReplayCommentsDto,
} from '../dto/user_app_comments.dto';
import { User_app_commentsService } from './user_app_comments.service';

// @UseGuards(JwtAuthGuard)
// @ApiBearerAuth('JWT-auth')
@ApiTags('User App Comments')
@Controller('user_app_comments')
export class User_app_commentsController {
  constructor(
    private readonly userAppCommentsService: User_app_commentsService,
  ) {}

  @Post('/create_user_app_comments_communication_table?')
  async creatDynamicTable(
    @Query('user_app_id') user_app_id: number,
  ): Promise<ResponseInterface> {
    const result = await this.userAppCommentsService.creatDynamicTable(
      user_app_id,
    );
    return {
      statusCode: HttpStatus.CREATED,
      message: 'Table created successful !!',
      data: result,
    };
  }

  @Post('/add_user_app_comments?')
  async insertUserAppComments(
    @Query('user_app_id') user_app_id: number,
    @Body() userAPpCommunicationDto: UserAppCommentsGetDto,
  ): Promise<ResponseInterface> {
    const result = await this.userAppCommentsService.insertUserAppComments(
      user_app_id,
      userAPpCommunicationDto,
    );
    return {
      statusCode: HttpStatus.CREATED,
      message: 'Sent successful!!',
      data: result,
    };
  }

  @Put('/update_user_app_comments?')
  async updateUserAppComments(
    @Query('user_app_id') user_app_id: number,
    @Query('comment_id') comment_id: number,
    @Body() update_comment_text: UserAppCommentsUpdateDto,
  ): Promise<ResponseInterface> {
    const result = await this.userAppCommentsService.updateUserAppComments(
      user_app_id,
      comment_id,
      update_comment_text,
    );
    return {
      statusCode: HttpStatus.CREATED,
      message: 'Updated successful !!',
      data: result,
    };
  }

  @Put('/update_user_app_comments_type?')
  async updateUserAppCommentsType(
    @Query('user_app_id') user_app_id: number,
    @Query('comment_id') comment_id: number,
    @Query('is_the_comment_private') is_the_comment_private: number,
    @Body() comment_reply: UserAppReplayCommentsDto,
  ): Promise<ResponseInterface> {
    const result = await this.userAppCommentsService.updateUserAppCommentsType(
      user_app_id,
      comment_id,
      is_the_comment_private,
      comment_reply,
    );
    return {
      statusCode: HttpStatus.CREATED,
      message: 'Updated successful !!',
      data: result,
    };
  }

  @Delete('/delete_user_app_comments?')
  async deleteUserAppComments(
    @Query('user_app_id') user_app_id: number,
    @Query('comment_id') comment_id: number,
  ): Promise<ResponseInterface> {
    const result = await this.userAppCommentsService.deleteUserAppComments(
      user_app_id,
      comment_id,
    );
    return {
      statusCode: HttpStatus.CREATED,
      message: 'Deleted successful !!',
      data: result,
    };
  }
  @Get('/get_user_app_comments?')
  async getUserAppComments(
    @Query('user_app_id') user_app_id: number,
  ): Promise<ResponseInterface> {
    const result = await this.userAppCommentsService.getUserAppComments(
      user_app_id,
    );
    return {
      statusCode: HttpStatus.CREATED,
      message: 'Get Comments successfully!!',
      data: result,
    };
  }
}
