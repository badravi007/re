import { HttpStatus } from '@nestjs/common';
/*
https://docs.nestjs.com/controllers#controllers
*/

import { Body, Controller, Post, Put, Query } from '@nestjs/common';
import { ApiTags } from '@nestjs/swagger';
import ResponseInterface from 'src/common/interface/response.interface';
import { UserAppCountryBusinessCategoryLocationDto } from '../dto/user_app_country_business_category_location.dto';
import { UserAppReassignCategoryDto } from '../dto/user_app_reassign_category.dto';
import { User_app_country_business_category_locationService } from './user_app_country_business_category_location.service';

// @UseGuards(JwtAuthGuard)
// @ApiBearerAuth('JWT-auth')
@ApiTags('User app country business category location ')
@Controller('user_app_master')
export class User_app_country_business_category_locationController {
  constructor(
    private readonly user_app_country_business_category_location_service: User_app_country_business_category_locationService,
  ) {}

  @Post('/assign_category_to_user_app_custom_app')
  async assignUserAppCustomAppCountryBusinessCategory(
    @Body()
    userAppCountryBusinessCategoryDto: UserAppCountryBusinessCategoryLocationDto,
  ): Promise<ResponseInterface> {
    await this.user_app_country_business_category_location_service.assignUserAppCustomAppCountryBusinessCategory(
      userAppCountryBusinessCategoryDto,
    );
    return {
      statusCode: 200,
      message: `User App Country/Business/Category Assigned Successfully!`,
      data: HttpStatus.CREATED,
    };
  }

  @Put('/reassign_user_app_category')
  async reassignUserAppCategory(
    @Query('old_user_app_id') old_user_app_id,
    @Query('user_app_category_id') user_app_category_id,
    @Query('getster_id') getster_id,
    @Query('user_app_activity_utc_date_time') user_app_activity_utc_date_time,
    @Body()
    userAppCountryBusinessCategoryDto: UserAppReassignCategoryDto,
  ): Promise<ResponseInterface> {
    await this.user_app_country_business_category_location_service.reAssignUserAppCategory(
      old_user_app_id,
      user_app_category_id,
      getster_id,
      user_app_activity_utc_date_time,
      userAppCountryBusinessCategoryDto,
    );
    return {
      statusCode: 200,
      message: `User App Reassigned Successfully!`,
      data: HttpStatus.CREATED,
    };
  }
}
