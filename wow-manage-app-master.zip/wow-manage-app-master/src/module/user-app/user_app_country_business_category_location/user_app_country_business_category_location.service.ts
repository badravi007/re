/*
https://docs.nestjs.com/providers#services
*/

import { Injectable } from '@nestjs/common';
import { InjectConnection, InjectRepository } from '@nestjs/typeorm';
import * as mysql from 'mysql2';
import { Repository } from 'typeorm';
import { UserAppCountryBusinessCategoryLocationDto } from '../dto/user_app_country_business_category_location.dto';
import { UserAppReassignCategoryDto } from '../dto/user_app_reassign_category.dto';
import { UserAppsAuditTrailDto } from '../dto/user_apps_audit_trail.dto';
import { UserAppCountryBusinessCategoryLocation } from '../entities/user_app_country_business_category_location.entity';
@Injectable()
export class User_app_country_business_category_locationService {
  constructor(
    @InjectRepository(UserAppCountryBusinessCategoryLocation, 'wow_user_app_db')
    @InjectConnection('wow_user_app_db')
    private readonly userAppCountryBusinessCategoryLocation: Repository<UserAppCountryBusinessCategoryLocation>,
  ) {}

  async assignUserAppCustomAppCountryBusinessCategory(
    userAppMasters: UserAppCountryBusinessCategoryLocationDto,
  ): Promise<any> {
    try {
      const {
        custom_app_id,
        id,
        is_hidden,
        user_app_category_ids,
        user_app_category_location,
        user_app_educational_institution_category_id,
        user_app_id,
      } = userAppMasters;

      let appCategoryIds = user_app_category_ids.split(',');

      if (user_app_id) {
        let getUserAppCategoryIds =
          await this.userAppCountryBusinessCategoryLocation
            .query(
              `
              SELECT a.*,b.user_app_educational_institution_category_id FROM wow_user_app_db.user_app_and_customapp_location_and_classify_user_app_category a
              left join wow_user_app_db.user_app_suitability_to_educational_institution_categories b on a.user_app_id=b.user_app_id
              WHERE
              b.user_app_educational_institution_category_id=${user_app_educational_institution_category_id} AND
              a.user_app_id=${user_app_id}

            `,
            )
            .then((data: any[]) => {
              let category_id: any[] = [];
              data.map((m) => {
                category_id.push(m.user_app_category_id);
              });

              return category_id;
            });

        let newCategoryIds: any[] = [];
        let alreadyExistsCategoryIds: any[] = [];
        appCategoryIds.map((ids) => {
          let removeIndexValue = getUserAppCategoryIds.indexOf(ids);
          // Get New Category Ids
          if (removeIndexValue < 0) {
            newCategoryIds.push(ids);
          }
          // Get Already Exists Category Ids
          if (removeIndexValue >= 0) {
            // newCategoryIds.push(ids);
            alreadyExistsCategoryIds.push(ids);
          }
        });

        let removeExistsCategoryIds: any[] = [];
        getUserAppCategoryIds.map((ids) => {
          let index = alreadyExistsCategoryIds.indexOf(ids);
          if (index == -1) removeExistsCategoryIds.push(ids);
        });

        if (removeExistsCategoryIds.length > 0) {
          for (let i = 0; i < removeExistsCategoryIds.length; i++) {
            const id = removeExistsCategoryIds[i];
            await this.userAppCountryBusinessCategoryLocation.query(`
                  DELETE FROM wow_user_app_db.user_app_and_customapp_location_and_classify_user_app_category
                  WHERE user_app_id=${user_app_id} AND user_app_category_id='${id}'
            `);
            await this.userAppCountryBusinessCategoryLocation.query(`
              DELETE FROM wow_user_app_db.user_app_suitability_to_educational_institution_categories
              WHERE user_app_id=${user_app_id} AND user_app_educational_institution_category_id=${user_app_educational_institution_category_id}
            `);
          }
        }

        for (let i = 0; i < newCategoryIds.length; i++) {
          const userAppCategoryId = newCategoryIds[i];

          let isAppExist = await this.userAppCountryBusinessCategoryLocation
            .query(`
                SELECT a.*,b.user_app_educational_institution_category_id FROM wow_user_app_db.user_app_and_customapp_location_and_classify_user_app_category a
                left join wow_user_app_db.user_app_suitability_to_educational_institution_categories b on a.user_app_id=b.user_app_id
                WHERE
                b.user_app_educational_institution_category_id=${user_app_educational_institution_category_id} AND
                a.user_app_category_id='${userAppCategoryId}' AND
                a.user_app_id=${user_app_id}
              `);

          if (isAppExist.length == 0) {
            await this.userAppCountryBusinessCategoryLocation.query(`
                  INSERT INTO wow_user_app_db.user_app_and_customapp_location_and_classify_user_app_category
                    (
                      user_app_id,
                      custom_app_id,
                      user_app_category_id,
                      user_app_category_location
                    )
                    VALUES
                    (
                      ${mysql.escape(user_app_id)},
                      ${mysql.escape(custom_app_id)},
                      ${mysql.escape(userAppCategoryId)},
                      ${mysql.escape(user_app_category_location)}
                      );
                      `);

            await this.userAppCountryBusinessCategoryLocation.query(`
              INSERT INTO wow_user_app_db.user_app_suitability_to_educational_institution_categories
                (user_app_id,
                  user_app_educational_institution_category_id)
                VALUES
                (${mysql.escape(user_app_id)},
                ${mysql.escape(user_app_educational_institution_category_id)});
            `);
          }
        }
      }

      if (custom_app_id) {
        let getCustomAppCategoryIds =
          await this.userAppCountryBusinessCategoryLocation
            .query(
              `
                  SELECT * FROM wow_user_app_db.user_app_and_customapp_location_and_classify_user_app_category
                  WHERE custom_app_id=${custom_app_id}
                `,
            )
            .then((data: any[]) => {
              let category_id: any[] = [];
              data.map((m) => {
                category_id.push(m.user_app_category_id);
              });
              return category_id;
            });

        let newCategoryIds: any[] = [];
        let alreadyExistsCategoryIds: any[] = [];
        appCategoryIds.map((ids) => {
          let removeIndexValue = getCustomAppCategoryIds.indexOf(ids);
          // Get New Category Ids
          if (removeIndexValue < 0) {
            newCategoryIds.push(ids);
          }
          // Get Already Exists Category Ids
          if (removeIndexValue >= 0) {
            // newCategoryIds.push(ids);
            alreadyExistsCategoryIds.push(ids);
          }
        });

        let removeExistsCategoryIds: any[] = [];
        getCustomAppCategoryIds.map((ids) => {
          let index = alreadyExistsCategoryIds.indexOf(ids);
          if (index == -1) removeExistsCategoryIds.push(ids);
        });

        if (removeExistsCategoryIds.length > 0) {
          for (let i = 0; i < removeExistsCategoryIds.length; i++) {
            const id = removeExistsCategoryIds[i];
            await this.userAppCountryBusinessCategoryLocation.query(`
              DELETE FROM wow_user_app_db.user_app_and_customapp_location_and_classify_user_app_category
              WHERE custom_app_id=${custom_app_id} AND user_app_category_id='${id}'
            `);
          }
        }

        for (let i = 0; i < newCategoryIds.length; i++) {
          const customAppCategoryId = newCategoryIds[i];

          let isAppExist = await this.userAppCountryBusinessCategoryLocation
            .query(`
              SELECT * FROM wow_user_app_db.user_app_and_customapp_location_and_classify_user_app_category
              WHERE user_app_category_id='${customAppCategoryId}' AND custom_app_id=${custom_app_id}
          `);

          if (isAppExist.length == 0) {
            await this.userAppCountryBusinessCategoryLocation.query(`
                INSERT INTO wow_user_app_db.user_app_and_customapp_location_and_classify_user_app_category
                  (
                    user_app_id,
                    custom_app_id,
                    user_app_category_id,
                    user_app_category_location
                  )
                  VALUES
                  (
                    ${mysql.escape(user_app_id)},
                    ${mysql.escape(custom_app_id)},
                    ${mysql.escape(customAppCategoryId)},
                    ${mysql.escape(user_app_category_location)}
                    );
                    `);
          }
        }
      }
    } catch (err) {
      throw err;
    }
  }

  async reAssignUserAppCategory(
    old_user_app_id: string,
    user_app_category_id: string,
    getster_id: number,
    user_app_activity_utc_date_time: string,
    userAppMaster: UserAppReassignCategoryDto,
  ): Promise<any> {
    try {
      let result: any;
      let userApps = await this.userAppCountryBusinessCategoryLocation.query(`
          SELECT * FROM wow_user_app_db.user_app_country_business_category_location;
      `);
      // let findUserAppCategory = await this
      //   .userAppCountryBusinessCategoryLocation.query(`
      //   SELECT * FROM wow_user_app_db.user_app_country_business_category_location where user_app_category_id = '${user_app_category_id}';
      // `);

      for (let i = 0; i < userApps.length; i++) {
        let user_apps: any = userAppMaster;
        if (userApps[i].user_app_id != null) {
          for (let j = 0; j < user_apps.length; j++) {
            if (
              userApps[i].user_app_id == user_apps[j].user_app_id &&
              userApps[i].user_app_category_id ==
                user_apps[j].user_app_category_id
            ) {
              // audit trail
              let audit_trail_body = {
                user_app_id: user_apps[j].user_app_id,
                user_app_activity: 'Delete Category',
                user_app_activity_by_user_id: `${getster_id}`,
                user_app_activity_utc_date_time:
                  user_app_activity_utc_date_time,
              };
              await this.insertUserAppAuditTrailDto(audit_trail_body);
              //
              let alreadyExists = await this.checkIfExist(
                user_app_category_id,
                userApps[i].user_app_id,
                user_apps[j].user_app_business_category_id,
                user_apps[j].user_app_country_code,
              );
              if (alreadyExists) {
                await this.userAppCountryBusinessCategoryLocation.query(`
                delete from wow_user_app_db.user_app_country_business_category_location where
                user_app_category_id='${user_apps[j].user_app_category_id}' and
                user_app_id='${user_apps[j].user_app_id}';
                `);
              } else {
                let body: UserAppCountryBusinessCategoryLocationDto;
                body = {
                  id: 0,
                  user_app_educational_institution_category_id:
                    user_apps[j].user_app_educational_institution_category_id,
                  user_app_category_ids: user_app_category_id,
                  user_app_id: user_apps[j].user_app_id,
                  custom_app_id: userApps[i].custom_app_id,
                  user_app_category_location:
                    user_apps[j].user_app_category_location,
                  is_hidden: false,
                };

                // let country_code: any = userAppMaster.user_app_country_code;
                // for (let i = 0; i < country_code.length; i++) {}
                result = await this.userAppCountryBusinessCategoryLocation
                  .query(`
              insert into wow_user_app_db.user_app_country_business_category_location values(
                0,'${user_apps[j].user_app_country_code}',
                '${user_apps[j].user_app_business_category_id}',
                '${user_app_category_id}',
                ${user_apps[j].user_app_id},
                ${user_apps[j].custom_app_id},
                '${user_apps[j].user_app_category_location}'
                )
              `);
                await this.userAppCountryBusinessCategoryLocation.query(`
                delete from wow_user_app_db.user_app_country_business_category_location where
                user_app_category_id='${user_apps[j].user_app_category_id}' and
                user_app_id='${user_apps[j].user_app_id}';
                `);
              }
            }
          }
        } else {
          if (userApps[i].custom_app_id != null) {
            let alreadyExists = await this.checkIfExistCustomApp(
              user_app_category_id,
              userApps[i].custom_app_id,
              userApps[i].user_app_business_category_id,
              userApps[i].user_app_country_code,
            );
            if (alreadyExists) {
              await this.userAppCountryBusinessCategoryLocation.query(`
                  delete from wow_user_app_db.user_app_country_business_category_location where
                  user_app_category_id='${userApps[i].user_app_category_id}' and
                  custom_app_id='${userApps[i].custom_app_id}';
                  `);
            } else {
              let body: UserAppCountryBusinessCategoryLocationDto;
              body = {
                id: 0,
                user_app_educational_institution_category_id:
                  userApps[i].user_app_educational_institution_category_id,
                user_app_category_ids: user_app_category_id,
                user_app_id: userApps[i].user_app_id,
                custom_app_id: userApps[i].custom_app_id,
                user_app_category_location:
                  userApps[i].user_app_category_location,
                is_hidden: true,
              };

              result = await this.userAppCountryBusinessCategoryLocation.query(`
            insert into wow_user_app_db.user_app_country_business_category_location values(
              0,'${userApps[i].user_app_country_code}',
              '${userApps[i].user_app_educational_institution_category_id}',
              '${user_app_category_id}',
              ${userApps[i].user_app_id},
              ${userApps[i].custom_app_id},
              '${userApps[i].user_app_category_location}'
              )
            `);
              await this.userAppCountryBusinessCategoryLocation.query(`
                  delete from wow_user_app_db.user_app_country_business_category_location where
                  user_app_category_id='${userApps[i].user_app_category_id}' and
                  custom_app_id='${userApps[i].custom_app_id}';
                  `);

              let test = '';
            }
          }

          // await this.userAppCountryBusinessCategoryLocation.query(`
          //       delete from wow_user_app_db.user_app_country_business_category_location where
          //       user_app_category_id='${userApps[i].user_app_category_id}' and
          //       user_app_id='null';
          //       `);
        }
      }

      return result;
    } catch (err) {
      throw err;
    }
  }

  async checkIfExist(
    user_app_category_id: any,
    user_app_id: any,
    user_app_business_category_id: any,
    user_app_country_code: any,
  ): Promise<boolean> {
    try {
      let userApps = await this.userAppCountryBusinessCategoryLocation.query(`
      SELECT * FROM wow_user_app_db.user_app_country_business_category_location;
      `);
      let result: boolean = false;
      for (let i = 0; i < userApps.length; i++) {
        if (
          userApps[i].user_app_id == user_app_id &&
          userApps[i].user_app_category_id == user_app_category_id &&
          userApps[i].user_app_business_category_id ==
            user_app_business_category_id &&
          userApps[i].user_app_country_code == user_app_country_code
        ) {
          result = true;
        }
      }
      return result;
    } catch (err) {
      throw err;
    }
  }

  async checkIfExistCustomApp(
    user_app_category_id: any,
    custom_app_id: any,
    user_app_business_category_id: any,
    user_app_country_code: any,
  ): Promise<boolean> {
    try {
      let userApps = await this.userAppCountryBusinessCategoryLocation.query(`
      SELECT * FROM wow_user_app_db.user_app_country_business_category_location;
      `);
      let result: boolean = false;
      for (let i = 0; i < userApps.length; i++) {
        if (
          userApps[i].custom_app_id == custom_app_id &&
          userApps[i].user_app_category_id == user_app_category_id &&
          userApps[i].user_app_business_category_id ==
            user_app_business_category_id &&
          userApps[i].user_app_country_code == user_app_country_code
        ) {
          result = true;
        }
      }
      return result;
    } catch (err) {
      throw err;
    }
  }

  async insertUserAppAuditTrailDto(
    businessCategoryCategory: UserAppsAuditTrailDto,
  ): Promise<any> {
    try {
      return await this.userAppCountryBusinessCategoryLocation.query(`
      insert into wow_user_app_db.user_apps_audit_trail values(
        0,'${businessCategoryCategory.user_app_id}',
        '${businessCategoryCategory.user_app_activity}',
        '${businessCategoryCategory.user_app_activity_by_user_id}',
        '${businessCategoryCategory.user_app_activity_utc_date_time}'
      )
      `);
    } catch (err) {
      throw err;
    }
  }
}
