/*
https://docs.nestjs.com/controllers#controllers
*/

import { Body, Controller, Get, Post, Put, Query } from '@nestjs/common';
import { ApiTags } from '@nestjs/swagger';
import ResponseInterface from 'src/common/interface/response.interface';
import { UserAppAboutDemoDto } from '../dto/create_user_app_about_demo.dto';
import { User_app_about_demoService } from './user_app_about_demo.service';

// @UseGuards(JwtAuthGuard)
// @ApiBearerAuth('JWT-auth')
@ApiTags('User App About Demo Video')
@Controller('user_app_about_demo_video')
export class User_app_about_demoController {
  constructor(
    private readonly userAppCategoryService: User_app_about_demoService,
  ) {}

  // @UseGuards(JwtAuthGuard)
  @Post('/add_update_user_app_about_demo_video')
  async createUserAppAboutDemo(
    @Body() userAppAboutDemoDto: UserAppAboutDemoDto,
  ): Promise<ResponseInterface> {
    const alreadyExists =
      await this.userAppCategoryService.checkUserAppAboutDemoExist(
        userAppAboutDemoDto.user_app_id,
      );
    if (alreadyExists) {
      const result = await this.userAppCategoryService.updateUserAppAboutDemo(
        userAppAboutDemoDto,
      );
      return {
        statusCode: 200,
        message: `Updated User App About Demo Video Successfully!`,
        data: result,
      };
    } else {
      const result = await this.userAppCategoryService.createUserAppAboutDemo(
        userAppAboutDemoDto,
      );
      return {
        statusCode: 200,
        message: `User App About Demo Created Successfully!`,
        data: result,
      };
    }
  }

  // @UseGuards(JwtAuthGuard)
  @Get('/get_user_app_about_demo_video')
  async getUserAppAboutDemo(
    @Query('user_app_id') user_app_id: number,
  ): Promise<any> {
    const result = await this.userAppCategoryService.getUserAppAboutDemo(
      user_app_id,
    );
    let data;
    if (result != null) {
      data = result;
    } else {
      data = null;
    }
    return {
      statusCode: 200,
      message: `Get User App About Demo Video Successfully!`,
      data: data,
    };
  }

  // @UseGuards(JwtAuthGuard)
  @Put('/update_user_app_about_demo')
  async updateUserAppAboutDemo(
    @Body() userAppAboutDemoDto: UserAppAboutDemoDto,
  ): Promise<ResponseInterface> {
    const result = await this.userAppCategoryService.updateUserAppAboutDemo(
      userAppAboutDemoDto,
    );
    return {
      statusCode: 200,
      message: `Updated User App About Demo Video Successfully!`,
      data: result,
    };
  }
}
