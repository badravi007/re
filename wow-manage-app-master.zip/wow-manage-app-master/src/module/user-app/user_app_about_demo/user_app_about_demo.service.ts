/*
https://docs.nestjs.com/providers#services
*/

import { Injectable } from '@nestjs/common';
import { InjectConnection, InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { UserAppAboutDemoDto } from '../dto/create_user_app_about_demo.dto';
import { UserAppAboutDemo } from '../entities/user_app_about_demo.entity';

@Injectable()
export class User_app_about_demoService {
  constructor(
    @InjectRepository(UserAppAboutDemo, 'wow_user_app_db')
    @InjectConnection('wow_user_app_db')
    private readonly userAppAboutDemoRepository: Repository<UserAppAboutDemo>,
  ) {}

  async createUserAppAboutDemo(
    userAppAboutDemoDto: UserAppAboutDemoDto,
  ): Promise<UserAppAboutDemoDto> {
    try {
      return await this.userAppAboutDemoRepository.save(userAppAboutDemoDto);
    } catch (err) {
      throw err;
    }
  }

  async updateUserAppAboutDemo(
    userAppAboutDemoDto: UserAppAboutDemoDto,
  ): Promise<UserAppAboutDemoDto> {
    try {
      let isFound = await this.userAppAboutDemoRepository.findOne({
        where: { user_app_id: userAppAboutDemoDto.user_app_id },
      });
      if (isFound) {
        await this.userAppAboutDemoRepository.update(
          userAppAboutDemoDto.user_app_id,
          userAppAboutDemoDto,
        );
      } else {
        await this.userAppAboutDemoRepository.save(userAppAboutDemoDto);
      }
      return await this.userAppAboutDemoRepository.findOne({
        where: { user_app_id: userAppAboutDemoDto.user_app_id },
      });
    } catch (err) {
      throw err;
    }
  }
  async getUserAppAboutDemo(user_app_id: number): Promise<UserAppAboutDemoDto> {
    try {
      return await this.userAppAboutDemoRepository.findOne({
        where: { user_app_id: user_app_id },
      });
    } catch (err) {
      throw err;
    }
  }

  async checkUserAppAboutDemoExist(user_app_id: number): Promise<boolean> {
    try {
      const user = await this.userAppAboutDemoRepository.findOne({
        where: { user_app_id: user_app_id },
      });
      return user ? true : false;
    } catch (err) {
      throw err;
    }
  }
}
