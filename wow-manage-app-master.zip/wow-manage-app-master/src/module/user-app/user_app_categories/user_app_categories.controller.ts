import {
  Body,
  Controller,
  Get,
  HttpStatus,
  Post,
  Put,
  Query,
} from '@nestjs/common';
import { ApiTags } from '@nestjs/swagger';
import { User_app_categoriesService } from './user_app_categories.service';

import { UserAppCategoryDto } from '../dto/user-app-category.dto';

// @UseGuards(JwtAuthGuard)
@ApiTags('User App Category')
// @ApiBearerAuth('JWT-auth')
@Controller('user_app_categories')
export class User_app_categoriesController {
  constructor(private _treeViewService: User_app_categoriesService) {}

  @Post('add_user_app_category')
  async addCategory(@Body() category: UserAppCategoryDto): Promise<any> {
    try {
      await this._treeViewService.postCategory(category);
      return {
        status: 200,
        message: 'Created Successfully',
      };
    } catch (error) {
      throw error;
    }
  }

  @Get('get_all_user_app_category')
  async GetAllCategories(): Promise<any> {
    try {
      const tasksData = await this._treeViewService.GetAllCategories();
      return {
        status: HttpStatus.OK,
        message: 'Fetched Successfully',
        data: tasksData,
      };
    } catch (error) {
      throw error;
    }
  }

  @Put('update_user_app_category')
  async updateCategory(@Body() category: UserAppCategoryDto): Promise<any> {
    try {
      await this._treeViewService.updateCategory(category);
      return {
        status: 200,
        message: 'Updated Successfully',
      };
    } catch (error) {
      throw error;
    }
  }

  @Put('hide_user_app_category')
  async hideCategory(@Body() category: UserAppCategoryDto): Promise<any> {
    try {
      await this._treeViewService.hideCategory(category);
      return {
        status: 200,
        message: 'Hide Successfully',
      };
    } catch (error) {
      throw error;
    }
  }

  @Get('check_user_app_is_assigned_user_app_category')
  async checkGetsterAssignedGetsterCategory(
    @Query('user_app_category_id') user_app_category_id: string,
  ) {
    let info = await this._treeViewService.checkGetsterAssignedGetsterCategory(
      user_app_category_id,
    );

    if (info == true) {
      return {
        status: 200,
        message:
          'User is present in this category in-order to hide parent category / sub category kindly reassign the user to another category',
        userIsAssigned: true,
      };
    } else if (info == false) {
      return {
        status: 200,
        message: 'User is not present in this category',
        userIsAssigned: false,
      };
    }
  }

  // @UseGuards(JwtAuthGuard)
  @Get('/get_all_user_apps')
  async getAllUserApps(): Promise<any> {
    const result = await this._treeViewService.getAllUserApps();
    return {
      statusCode: 200,
      message: `Get User App Category List Successfully.`,
      data: result,
    };
  }
  // @UseGuards(JwtAuthGuard)
  @Get('/get_all_custom_apps')
  async getAllCustomApps(): Promise<any> {
    const result = await this._treeViewService.getAllCustomApps();
    return {
      statusCode: 200,
      message: `Get User App Category List Successfully.`,
      data: result,
    };
  }

  @Get('/get_all_user_custom_apps')
  async getAllUserCustomApps(): Promise<any> {
    const result = await this._treeViewService.getAllUserCustomApps();
    return {
      statusCode: 200,
      message: `Get All User App List Successfully!`,
      data: result,
    };
  }
}
