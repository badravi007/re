/*
https://docs.nestjs.com/providers#services
*/

import { Injectable } from '@nestjs/common';
import { InjectConnection, InjectRepository } from '@nestjs/typeorm';
import * as mysql from 'mysql2';
import { IUserAppCategory } from 'src/models/interface/user_app_category.interface';
import { Repository } from 'typeorm';
import { UserAppCategory } from '../entities/user-app-category.entity';

@Injectable()
export class User_app_categoriesService {
  constructor(
    @InjectRepository(UserAppCategory, 'wow_user_app_db')
    @InjectConnection('wow_user_app_db')
    private readonly userCategoryRepository: Repository<UserAppCategory>, // private _dateTimeService: DateTimeService,
  ) {}
  async postCategory(category_details: IUserAppCategory) {
    try {
      await this.userCategoryRepository.query(`
            INSERT INTO wow_user_app_db.user_app_categories (user_app_category_id, parent_user_app_category_id, user_app_category_name, 	is_the_user_app_category_hidden,	user_app_category_type) VALUES (
              ${mysql.escape(category_details.user_app_category_id)},
              ${mysql.escape(category_details.parent_user_app_category_id)},
              ${mysql.escape(category_details.user_app_category_name)},
              ${mysql.escape(category_details.is_the_user_app_category_hidden)},
              ${mysql.escape(category_details.user_app_category_type)}
              );
            `);
    } catch (error) {
      throw error;
    }
  }

  async updateCategory(category_details: IUserAppCategory) {
    try {
      if (category_details.user_app_category_name) {
        await this.userCategoryRepository.query(`
        UPDATE wow_user_app_db.user_app_categories
        SET user_app_category_name = ${mysql.escape(
          category_details.user_app_category_name,
        )} WHERE
        user_app_category_id = '${category_details.user_app_category_id}' `);
      }
    } catch (error) {
      throw error;
    }
  }

  async hideCategory(category_details: IUserAppCategory) {
    try {
      if (category_details.is_the_user_app_category_hidden) {
        await this.userCategoryRepository.query(`
          UPDATE wow_user_app_db.user_app_categories
          SET is_the_user_app_category_hidden = ${mysql.escape(
            category_details.is_the_user_app_category_hidden,
          )} WHERE
          user_app_category_id = '${category_details.user_app_category_id}' `);
      }
    } catch (error) {
      throw error;
    }
  }

  async GetAllCategories() {
    try {
      const TaskData = await this.userCategoryRepository.query(
        `SELECT * FROM wow_user_app_db.user_app_categories order by id`,
      );
      // console.log(TaskData);

      let data;
      if (TaskData.length > 1) {
        data = await this.treeConstruct(TaskData);
        // console.log(data, "tree");

        return data;
      }
      // console.log(data);

      // console.log(TaskData, "taskdata");

      const obj = TaskData[0];
      const pair = { children: [] };
      const objData = { ...obj, ...pair };
      if (obj !== undefined) {
        return [objData];
      }
      return [];
    } catch (error) {
      throw error;
    }
  }

  treeConstruct(treeData) {
    let constructedTree = [];
    for (let i of treeData) {
      let treeObj = i;
      let assigned = false;
      this.constructTree(constructedTree, treeObj, assigned);
    }
    return constructedTree;
  }

  constructTree(constructedTree, treeObj, assigned) {
    if (treeObj.parent_user_app_category_id == null) {
      treeObj.children = [];
      constructedTree.push(treeObj);
      return true;
    } else if (
      treeObj.parent_user_app_category_id ===
      constructedTree.user_app_category_id
    ) {
      treeObj.children = [];
      constructedTree.children.push(treeObj);
      return true;
    } else {
      if (constructedTree.children != undefined) {
        for (let index = 0; index < constructedTree.children.length; index++) {
          let constructedObj = constructedTree.children[index];
          if (assigned == false) {
            assigned = this.constructTree(constructedObj, treeObj, assigned);
          }
        }
      } else {
        for (let index = 0; index < constructedTree.length; index++) {
          let constructedObj = constructedTree[index];
          if (assigned == false) {
            assigned = this.constructTree(constructedObj, treeObj, assigned);
          }
        }
      }
      return false;
    }
  }

  //

  async checkGetsterAssignedGetsterCategory(user_app_category_id: string) {
    let datas: any[] = await this.userCategoryRepository.query(
      `select * from wow_user_app_db.user_app_country_educational_institution_category_location where 	user_app_category_id = ${mysql.escape(
        user_app_category_id,
      )}`,
    );

    if (datas.length == 0) {
      return false;
    }
    return datas[0].user_id !== null ? true : false;
  }

  async getAllUserApps(): Promise<UserApp[]> {
    try {
      // let connection = getConnection('wow_user_app_db');
      let get_all_user_apps = await this.userCategoryRepository
        .query(`SELECT a.user_app_id,
        a.user_app_icon_name,
        a.user_app_icon_image_path,
        a.user_app_full_name,
        a.user_app_development_status,

        b.user_app_category_location,
        b.custom_app_id,
        d.user_app_educational_institution_category_id,

        c.user_app_category_name as CategoryName,
        c.user_app_category_name as user_app_category_name,
        c.parent_user_app_category_id,
        c.user_app_category_id

        from wow_user_app_db.user_app_master  a

        join wow_user_app_db.user_app_and_customapp_location_and_classify_user_app_category b on  a.user_app_id = b.user_app_id

        join wow_user_app_db.user_app_suitability_to_educational_institution_categories d on a.user_app_id = d.user_app_id
        join wow_user_app_db.user_app_categories c  on b.user_app_category_id=c.user_app_category_id
        `);

      let get_all_category = await this.userCategoryRepository.query(
        `SELECT * FROM wow_user_app_db.user_app_categories;`,
      );

      let body: any[] = [];
      let main_count = 0;
      for (let i = 0; i < get_all_category.length; i++) {
        let user_app_category_name = get_all_category[i].user_app_category_name;
        let data: any[] = [];

        let app_count = 0;
        for (let j = 0; j < get_all_user_apps.length; j++) {
          if (
            get_all_category[i].user_app_category_id ===
              get_all_user_apps[j].user_app_category_id &&
            get_all_user_apps[j].user_app_id != null
          ) {
            if (app_count === 0) {
              data.push(get_all_user_apps[j]);
              app_count++;
            }

            let valid: boolean = false;
            for (let k = 0; k < data.length; k++) {
              if (
                data[k].user_app_id === get_all_user_apps[j].user_app_id &&
                data[k].user_app_category_id ===
                  get_all_user_apps[j].user_app_category_id
              ) {
                valid = true;
              } else {
              }
            }
            if (!valid) {
              data.push(get_all_user_apps[j]);
            }
            //
          }
        }
        main_count++;
        if (main_count > i && data.length != 0) {
          body.push({
            user_app_category_name: user_app_category_name,
            data: data,
          });
        }
        user_app_category_name = null;
        data = [null];
      }

      return await body;
    } catch (err) {
      throw err;
    }
  }
  async getAllCustomApps(): Promise<UserApp[]> {
    try {
      // let connection = getConnection('wow_user_app_db');
      let get_all_custom_apps = await this.userCategoryRepository.query(`
          SELECT
          a.custom_app_id,
          a.custom_app_icon_name,
          a.custom_app_icon_image_path,
          a.custom_app_full_name,
          a.custom_app_development_status,

          b.user_app_category_location,
          b.custom_app_id,

          c.user_app_category_name as CategoryName,
          c.user_app_category_name as user_app_category_name,
          c.parent_user_app_category_id,
          c.user_app_category_id

          from wow_custom_app_db.custom_app_master  a

          join wow_user_app_db.user_app_and_customapp_location_and_classify_user_app_category b on  a.custom_app_id = b.custom_app_id

          join wow_user_app_db.user_app_categories c  on b.user_app_category_id=c.user_app_category_id
        `);

      let get_all_category = await this.userCategoryRepository.query(
        `SELECT * FROM wow_user_app_db.user_app_categories;`,
      );

      let body: any[] = [];
      let main_count = 0;
      for (let i = 0; i < get_all_category.length; i++) {
        let user_app_category_name = get_all_category[i].user_app_category_name;
        let data: any[] = [];

        let app_count = 0;
        for (let j = 0; j < get_all_custom_apps.length; j++) {
          if (
            get_all_category[i].user_app_category_id ===
              get_all_custom_apps[j].user_app_category_id &&
            get_all_custom_apps[j].custom_app_id != null
          ) {
            if (app_count === 0) {
              data.push(get_all_custom_apps[j]);
              app_count++;
            }

            let valid: boolean = false;
            for (let k = 0; k < data.length; k++) {
              if (
                data[k].custom_app_id ===
                  get_all_custom_apps[j].custom_app_id &&
                data[k].user_app_category_id ===
                  get_all_custom_apps[j].user_app_category_id
              ) {
                valid = true;
              } else {
              }
            }
            if (!valid) {
              data.push(get_all_custom_apps[j]);
            }
            //
          }
        }
        main_count++;
        if (main_count > i && data.length != 0) {
          body.push({
            user_app_category_name: user_app_category_name,
            data: data,
          });
        }
        user_app_category_name = null;
        data = [null];
      }

      return await body;
    } catch (err) {
      throw err;
    }
  }

  async getAllUserCustomApps(): Promise<UserAppCategory[]> {
    try {
      // let connection = getConnection('wow_user_app_db');
      let get_all_user_apps = await this.userCategoryRepository.query(
        `SELECT * FROM wow_user_app_db.user_app_master;`,
      );
      return get_all_user_apps;
    } catch (err) {
      throw err;
    }
  }
}

interface UserApp {
  category_name: string;
  data: any;
}
