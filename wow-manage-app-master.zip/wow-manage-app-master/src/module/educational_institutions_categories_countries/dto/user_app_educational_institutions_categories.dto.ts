import { ApiProperty } from '@nestjs/swagger';
import { IsNotEmpty } from 'class-validator';

export class UserAppEducationalInstitutionsCategoryDto {
  @ApiProperty()
  country_code: string;

  @ApiProperty()
  user_app_educational_institution_category_id: string;

  @ApiProperty()
  parent_user_app_educational_institution_category_id: string;

  @ApiProperty()
  user_app_educational_institution_category_name: string;

  @ApiProperty()
  user_app_educational_institution_category_type: number;

  @ApiProperty()
  is_user_app_educational_institution_category_hidden: boolean;
}

export class AddDemoVideoForEducationalInstitutionsCategoryDto {
  @ApiProperty()
  country_code: string;

  @ApiProperty()
  file_name_of_video: string;

  @ApiProperty()
  user_app_educational_institution_category_id: string;

  @ApiProperty({ type: 'string', format: 'binary' })
  user_app_educational_institution_category_demo_video_file: string;

  @ApiProperty()
  user_app_educational_institution_category_description_datetime: string;
}
