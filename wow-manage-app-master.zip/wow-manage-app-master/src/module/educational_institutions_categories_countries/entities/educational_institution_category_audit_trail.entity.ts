import { Column, Entity, PrimaryColumn, PrimaryGeneratedColumn } from 'typeorm';

@Entity({
  database: 'wow_user_app_db',
  name: 'educational_institution_category_audit_trail',
})
export class EducationalInstitutionCategoryAuditTrail {
  @PrimaryGeneratedColumn('increment')
  id: number;

  @Column({
    type: 'varchar',
    length: 50,
  })
  user_app_educational_institution_category_id: string;

  @Column({
    length: 255,
  })
  entry_type: string;

  @Column({
    length: 255,
  })
  entry_by_user_id: string;

  @Column({
    type: 'datetime',
  })
  entry_date_time: Date;
}
