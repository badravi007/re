import { Column, Entity, PrimaryColumn, PrimaryGeneratedColumn } from 'typeorm';

@Entity({
  database: 'wow_user_app_db',
  name: 'user_app_educational_institutions_category_about_demo',
})
export class UserAppEducationalInstitutionCategoryAboutDemo {
  @PrimaryGeneratedColumn('increment')
  id: number;

  @PrimaryColumn({
    length: 50,
  })
  user_app_educational_institution_category_id: string;

  @Column({ length: 255 })
  thumb_nail_image: string;

  @Column({
    type: 'varchar',
    length: '255',
  })
  user_app_educational_institution_category_demo_video_file: string;

  @Column({
    length: 1000,
  })
  user_app_educational_institution_category_description_datetime: string;
}
