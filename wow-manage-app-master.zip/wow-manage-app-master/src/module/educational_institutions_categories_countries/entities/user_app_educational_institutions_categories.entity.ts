import { Column, Entity, PrimaryColumn, PrimaryGeneratedColumn } from 'typeorm';

@Entity({
  database: 'wow_user_app_db',
  name: 'user_app_educational_institutions_categories',
})
export class UserAppEducationalInstitutionsCategory {
  @PrimaryGeneratedColumn('increment')
  id: number;

  @Column({
    type: 'varchar',
    length: 3,
  })
  country_code: string;

  @PrimaryColumn({
    type: 'varchar',
    length: 100,
  })
  user_app_educational_institution_category_id: string;

  @Column({
    length: 100,
  })
  parent_user_app_educational_institution_category_id: string;

  @Column({
    length: 100,
  })
  user_app_educational_institution_category_name: string;

  @Column()
  user_app_educational_institution_category_type: number;

  @Column()
  is_user_app_educational_institution_category_hidden: boolean;
}
