/*
https://docs.nestjs.com/modules
*/

import { Module } from '@nestjs/common';
import { MulterModule } from '@nestjs/platform-express';
import { TypeOrmModule } from '@nestjs/typeorm';
import { EducationalInstitutionCategoryAuditTrail } from './entities/educational_institution_category_audit_trail.entity';
import { UserAppEducationalInstitutionsCategory } from './entities/user_app_educational_institutions_categories.entity';
import { UserAppEducationalInstitutionCategoryAboutDemo } from './entities/user_app_educational_institutions_category_about_demo.entity';
import { UserAppEducationalInstitutionsCategoriesController } from './user_app_educational_institutions_categories/user_app_educational_institutions_categories.controller';
import { UserAppEducationalInstitutionsCategoriesService } from './user_app_educational_institutions_categories/user_app_educational_institutions_categories.service';

@Module({
  imports: [
    MulterModule.register({
      dest: './src/assets/uploads',
    }),
    TypeOrmModule.forFeature(
      [
        UserAppEducationalInstitutionsCategory,
        EducationalInstitutionCategoryAuditTrail,
        UserAppEducationalInstitutionCategoryAboutDemo,
      ],
      'wow_user_app_db',
    ),
  ],
  controllers: [UserAppEducationalInstitutionsCategoriesController],
  providers: [UserAppEducationalInstitutionsCategoriesService],
  exports: [UserAppEducationalInstitutionsCategoriesService],
})
export class EducationalInstitutionsCategoriesCountriesModule {}
