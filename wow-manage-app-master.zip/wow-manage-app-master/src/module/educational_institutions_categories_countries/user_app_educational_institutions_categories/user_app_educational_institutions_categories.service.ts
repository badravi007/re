import { Injectable } from '@nestjs/common';
import { InjectConnection, InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import * as mysql from 'mysql2';
import { DateTimeService } from 'src/shared/service/date-time.service';
import { IUserAppEducationalInstitutionsCategory } from 'src/models/interface/user_app_educational_institutions_categories.interface';
import { UserAppEducationalInstitutionsCategory } from '../entities/user_app_educational_institutions_categories.entity';
import { AddDemoVideoForEducationalInstitutionsCategoryDto } from '../dto/user_app_educational_institutions_categories.dto';

@Injectable()
export class UserAppEducationalInstitutionsCategoriesService {
  constructor(
    @InjectRepository(UserAppEducationalInstitutionsCategory, 'wow_user_app_db')
    @InjectConnection('wow_user_app_db')
    private readonly userCategoryRepository: Repository<UserAppEducationalInstitutionsCategory>,
  ) {}
  async postCategory(
    category_details: IUserAppEducationalInstitutionsCategory,
  ) {
    try {
      await this.userCategoryRepository.query(`
                INSERT INTO wow_user_app_db.user_app_educational_institutions_categories (country_code,user_app_educational_institution_category_id, 	parent_user_app_educational_institution_category_id, 	user_app_educational_institution_category_name, is_user_app_educational_institution_category_hidden,user_app_educational_institution_category_type) VALUES (
                  ${mysql.escape(category_details.country_code)},
                  ${mysql.escape(
                    category_details.user_app_educational_institution_category_id,
                  )},
                  ${mysql.escape(
                    category_details.parent_user_app_educational_institution_category_id,
                  )}, 
                  ${mysql.escape(
                    category_details.user_app_educational_institution_category_name,
                  )},
                  ${mysql.escape(
                    category_details.is_user_app_educational_institution_category_hidden,
                  )},
                  ${mysql.escape(
                    category_details.user_app_educational_institution_category_type,
                  )}
                  );
                `);
    } catch (error) {
      throw error;
    }
  }

  async updateCategory(
    category_details: IUserAppEducationalInstitutionsCategory,
  ) {
    try {
      if (category_details.user_app_educational_institution_category_name) {
        await this.userCategoryRepository.query(`
            UPDATE wow_user_app_db.user_app_educational_institutions_categories
            SET user_app_educational_institution_category_name = ${mysql.escape(
              category_details.user_app_educational_institution_category_name,
            )} WHERE 
            user_app_educational_institution_category_id = '${
              category_details.user_app_educational_institution_category_id
            }' `);
      }
    } catch (error) {
      throw error;
    }
  }

  async hideCategory(
    category_details: IUserAppEducationalInstitutionsCategory,
  ) {
    try {
      if (
        category_details.is_user_app_educational_institution_category_hidden
      ) {
        await this.userCategoryRepository.query(`
              UPDATE wow_user_app_db.user_app_educational_institutions_categories 
              SET is_user_app_educational_institution_category_hidden = ${mysql.escape(
                category_details.is_user_app_educational_institution_category_hidden,
              )} WHERE 
              user_app_educational_institution_category_id = '${
                category_details.user_app_educational_institution_category_id
              }' `);
      }
    } catch (error) {
      throw error;
    }
  }

  async GetAllCategories() {
    try {
      const TaskData = await this.userCategoryRepository.query(
        `SELECT * FROM wow_user_app_db.user_app_educational_institutions_categories order by id`,
      );
      // console.log(TaskData);

      let data;
      if (TaskData.length > 1) {
        data = await this.treeConstruct(TaskData);
        // console.log(data, "tree");

        return data;
      }
      // console.log(data);

      // console.log(TaskData, "taskdata");

      const obj = TaskData[0];
      const pair = { children: [] };
      const objData = { ...obj, ...pair };
      if (obj !== undefined) {
        return [objData];
      }
      return [];
    } catch (error) {
      throw error;
    }
  }

  treeConstruct(treeData) {
    let constructedTree = [];
    for (let i of treeData) {
      let treeObj = i;
      let assigned = false;
      this.constructTree(constructedTree, treeObj, assigned);
    }
    return constructedTree;
  }

  constructTree(constructedTree, treeObj, assigned) {
    if (treeObj.parent_user_app_educational_institution_category_id == null) {
      treeObj.children = [];
      constructedTree.push(treeObj);
      return true;
    } else if (
      treeObj.parent_user_app_educational_institution_category_id ===
      constructedTree.user_app_educational_institution_category_id
    ) {
      treeObj.children = [];
      constructedTree.children.push(treeObj);
      return true;
    } else {
      if (constructedTree.children != undefined) {
        for (let index = 0; index < constructedTree.children.length; index++) {
          let constructedObj = constructedTree.children[index];
          if (assigned == false) {
            assigned = this.constructTree(constructedObj, treeObj, assigned);
          }
        }
      } else {
        for (let index = 0; index < constructedTree.length; index++) {
          let constructedObj = constructedTree[index];
          if (assigned == false) {
            assigned = this.constructTree(constructedObj, treeObj, assigned);
          }
        }
      }
      return false;
    }
  }

  //

  async checkGetsterAssignedGetsterCategory(
    user_app_educational_institution_category_id: string,
  ) {
    let datas: any[] = await this.userCategoryRepository.query(
      `select * from wow_user_app_db.user_app_country_educational_institution_category_location where user_app_educational_institution_category_id = ${mysql.escape(
        user_app_educational_institution_category_id,
      )}`,
    );

    if (datas.length == 0) {
      return false;
    }
    return datas[0].user_id !== null ? true : false;
  }

  async addDemoVideoForEducationalInstitutionsCategory(
    category_details: AddDemoVideoForEducationalInstitutionsCategoryDto,
  ): Promise<any> {
    try {
      let result: any = await this.checkDemoVideoExist(
        category_details.user_app_educational_institution_category_id,
      );
      if (result == false) {
        console.log('in');
        await this.userCategoryRepository.query(`
        insert into wow_user_app_db.user_app_educational_institutions_category_about_demo
        (user_app_educational_institution_category_id,thumb_nail_image,user_app_educational_institution_category_demo_video_file, 	user_app_educational_institution_category_description_datetime) VALUES (
          ${mysql.escape(
            category_details.user_app_educational_institution_category_id,
          )},
          ${mysql.escape('null')},
            ${mysql.escape(category_details.file_name_of_video)},
        ${mysql.escape(
          category_details.user_app_educational_institution_category_description_datetime,
        )}
        )`);
      } else {
        console.log('out');
        await this.userCategoryRepository.query(`
        update wow_user_app_db.user_app_educational_institutions_category_about_demo 
        SET user_app_educational_institution_category_demo_video_file = ${mysql.escape(
          category_details.file_name_of_video,
        )} ,user_app_educational_institution_category_description_datetime = ${mysql.escape(
          category_details.user_app_educational_institution_category_description_datetime,
        )}, thumb_nail_image = ${mysql.escape('null')} WHERE 
        user_app_educational_institution_category_id = '${
          category_details.user_app_educational_institution_category_id
        }'`);
      }
    } catch (error) {
      throw error;
    }
  }

  async checkDemoVideoExist(
    user_app_educational_institution_category_id,
  ): Promise<any> {
    try {
      let result: any[] = await this.userCategoryRepository.query(`
      SELECT * FROM wow_user_app_db.user_app_educational_institutions_category_about_demo
      where user_app_educational_institution_category_id='${user_app_educational_institution_category_id}'
        `);

      console.log('sdf' + result.length);
      console.log('sdf1' + result.length);
      if (result.length == 0) {
        return false;
      } else {
        return true;
      }

      // return result.length == 0 ? true : false;
    } catch (err) {
      console.log('sdf' + err);
      throw err;
    }
  }

  async getDemoVideoForEducationalInstitutionsCategory(
    user_app_educational_institution_category_id: string,
  ): Promise<any> {
    try {
      return await this.userCategoryRepository.query(
        `select * from wow_user_app_db.user_app_educational_institutions_category_about_demo 
        where user_app_educational_institution_category_id='${user_app_educational_institution_category_id}'`,
      );
    } catch (err) {
      throw err;
    }
  }
}
