import {
  BadRequestException,
  Body,
  Controller,
  Delete,
  Get,
  HttpStatus,
  Post,
  Put,
  Query,
  UploadedFile,
  UseInterceptors,
} from '@nestjs/common';
import { ApiBody, ApiConsumes, ApiTags } from '@nestjs/swagger';
import {
  AddDemoVideoForEducationalInstitutionsCategoryDto,
  UserAppEducationalInstitutionsCategoryDto,
} from '../dto/user_app_educational_institutions_categories.dto';
import { UserAppEducationalInstitutionsCategoriesService } from './user_app_educational_institutions_categories.service';
import * as fs from 'fs';
import { FileInterceptor } from '@nestjs/platform-express';

import { diskStorage } from 'multer';
import {
  editFileName,
  imageFileFilter,
} from 'src/shared/utils/file-upload.utils';
import { VideoHelper } from 'src/shared/service/video-helper';

@ApiTags('User App Educational Institutions Category')
@Controller('educational_institutions_category')
export class UserAppEducationalInstitutionsCategoriesController {
  constructor(
    private _treeViewService: UserAppEducationalInstitutionsCategoriesService,
  ) {}

  @Post('add_educational_institutions_category')
  async addCategory(
    @Body() category: UserAppEducationalInstitutionsCategoryDto,
  ): Promise<any> {
    try {
      await this._treeViewService.postCategory(category);
      return {
        status: 200,
        message: 'Created Successfully',
      };
    } catch (error) {
      throw error;
    }
  }

  @Get('get_all_educational_institutions_category')
  async GetAllCategories(): Promise<any> {
    try {
      const tasksData = await this._treeViewService.GetAllCategories();
      return {
        status: HttpStatus.OK,
        message: 'Fetched Successfully',
        data: tasksData,
      };
    } catch (error) {
      throw error;
    }
  }

  @Put('update_educational_institutions_category')
  async updateCategory(
    @Body() category: UserAppEducationalInstitutionsCategoryDto,
  ): Promise<any> {
    try {
      await this._treeViewService.updateCategory(category);
      return {
        status: 200,
        message: 'Updated Successfully',
      };
    } catch (error) {
      throw error;
    }
  }

  @Put('hide_educational_institutions_category')
  async hideCategory(
    @Body() category: UserAppEducationalInstitutionsCategoryDto,
  ): Promise<any> {
    try {
      await this._treeViewService.hideCategory(category);
      return {
        status: 200,
        message: 'Hide Successfully',
      };
    } catch (error) {
      throw error;
    }
  }

  @Get('check_is_assigned_user_app_category')
  async checkGetsterAssignedGetsterCategory(
    @Query('user_app_educational_institution_category_id')
    user_app_educational_institution_category_id: string,
  ) {
    let info = await this._treeViewService.checkGetsterAssignedGetsterCategory(
      user_app_educational_institution_category_id,
    );

    if (info == true) {
      return {
        status: 200,
        message:
          'User is present in this category in-order to hide parent category / sub category kindly reassign the user to another category',
        userIsAssigned: true,
      };
    } else if (info == false) {
      return {
        status: 200,
        message: 'User is not present in this category',
        userIsAssigned: false,
      };
    }
  }

  @Post('add_demo_video_for_educational_institutions_category')
  @ApiConsumes('application/json')
  @ApiConsumes('multipart/form-data')
  @ApiBody({
    type: AddDemoVideoForEducationalInstitutionsCategoryDto,
  })
  @UseInterceptors(
    FileInterceptor(
      'user_app_educational_institution_category_demo_video_file',
      {
        storage: diskStorage({
          destination: VideoHelper.destinationPath,
          filename: VideoHelper.customFileName,
        }),
      },
    ),
  )
  async addDemoVideoForEducationalInstitutionsCategory(
    @UploadedFile()
    _attachments: Express.Multer.File,
    @Body() category: AddDemoVideoForEducationalInstitutionsCategoryDto,
  ): Promise<any> {
    try {
      if (!_attachments)
        throw new BadRequestException('Please attach the attachments');
      let body = {};
      console.log(_attachments);
      let result =
        await this._treeViewService.addDemoVideoForEducationalInstitutionsCategory(
          category,
        );
      return {
        status: 200,
        message: 'Added Successfully',
        data: result,
      };
    } catch (error) {
      console.log(error);
      throw error;
    }
  }

  @Get('get_demo_video_for_educational_institution_category_by_id')
  async getDemoVideoForEducationalInstitutionsCategory(
    @Query('user_app_educational_institution_category_id')
    user_app_educational_institution_category_id: string,
  ) {
    try {
      let result =
        await this._treeViewService.getDemoVideoForEducationalInstitutionsCategory(
          user_app_educational_institution_category_id,
        );
      return {
        status: 200,
        message: 'Get Successfully',
        date: result,
      };
    } catch (error) {
      throw error;
    }
  }
}
