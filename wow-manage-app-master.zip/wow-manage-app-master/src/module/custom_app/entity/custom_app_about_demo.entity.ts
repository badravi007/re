import { Column, Entity, PrimaryColumn } from 'typeorm';

@Entity({ database: 'wow_custom_app_db', name: 'custom_app_about_demo' })
export class CustomAppAboutDemo {
  @PrimaryColumn()
  custom_app_id: number;

  @Column({
    type: 'varchar',
    length: 255,
  })
  custom_app_demo_video_path: string;

  @Column({
    type: 'varchar',
    length: 255,
  })
  custom_app_demo_video_thumb_nail_path: string;

  @Column({
    type: 'json',
  })
  custom_app_demo_video_datetime_description_file: TimeStampDescription[];

  @Column({
    type: 'json',
  })
  custom_app_attachments_file: object[];
}

class TimeStampDescription {
  description: string;
  title: string;
  time_stamp: string;
}
