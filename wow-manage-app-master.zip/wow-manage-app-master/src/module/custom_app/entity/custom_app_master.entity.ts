import { Column, Entity, PrimaryGeneratedColumn } from 'typeorm';

@Entity({ database: 'wow_custom_app_db', name: 'custom_app_master' })
export class CustomAppMaster {
  @PrimaryGeneratedColumn('increment')
  custom_app_id: number;

  @Column({
    type: 'varchar',
    length: 100,
  })
  custom_app_icon_name: string;

  @Column({
    type: 'varchar',
    length: 100,
  })
  custom_app_icon_image_path: string;

  // @Column({
  //   type: 'varchar',
  //   length: 100,
  // })
  // custom_app_title_bar_name: string;

  @Column({
    type: 'varchar',
    length: 255,
  })
  custom_app_full_name: string;

  @Column()
  custom_app_development_status: boolean;
}
