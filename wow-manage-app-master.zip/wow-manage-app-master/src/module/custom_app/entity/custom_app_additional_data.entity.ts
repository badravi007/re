import { Column, Entity, PrimaryColumn } from 'typeorm';

@Entity({ database: 'wow_custom_app_db', name: 'custom_app_additional_data' })
export class CustomAppAdditionalData {
  @PrimaryColumn()
  custom_app_id: number;

  @Column()
  can_this_custom_app_be_blocked_by_app_administrator: boolean;

  @Column()
  can_this_app_be_displayed_in_customerbizapp_launch_screen: boolean;

  @Column()
  does_this_app_have_configuration_data_specific_to_this_app: boolean;
}
