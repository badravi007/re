import { Column, Entity, PrimaryColumn } from 'typeorm';

@Entity({ database: 'wow_custom_app_db', name: 'custom_apps_customers_list' })
export class CustomAppCustomersList {
  @PrimaryColumn()
  custom_app_id: number;

  @Column()
  custom_apps_customers_list_id: number;

  @Column()
  customer_id: number;

  @Column({
    type: 'json',
  })
  user_apps_to_be_hidden: string;

  @Column()
  custom_app_update_utc_datetime: string;
}
