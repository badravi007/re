import { Column, Entity, PrimaryGeneratedColumn } from 'typeorm';

@Entity({ database: 'wow_custom_app_db', name: 'custom_apps_audit_trail' })
export class CustomAppAuditTrail {
  @PrimaryGeneratedColumn('increment')
  id: number;

  @Column()
  custom_app_id: number;

  @Column({ length: 20 })
  custom_app_activity: string;

  @Column()
  custom_app_activity_by_user_id: string;

  @Column({ length: 30 })
  custom_app_activity_utc_date_time: string;
}
