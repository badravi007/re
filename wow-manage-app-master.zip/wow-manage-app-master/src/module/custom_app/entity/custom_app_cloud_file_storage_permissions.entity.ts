import { Column, Entity, PrimaryColumn } from 'typeorm';

@Entity({
  database: 'wow_custom_app_db',
  name: 'custom_app_cloud_file_storage_permissions',
})
export class CustomAppCloudFileStoragePermissions {
  @PrimaryColumn()
  custom_app_id: number;

  @Column()
  delete_folder: boolean;

  @Column()
  delete_file: boolean;

  @Column()
  copy_file: boolean;
}
