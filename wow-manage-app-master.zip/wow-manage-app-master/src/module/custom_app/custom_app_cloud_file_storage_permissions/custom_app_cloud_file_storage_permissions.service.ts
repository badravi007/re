/*
https://docs.nestjs.com/providers#services
*/

import { Injectable } from '@nestjs/common';
import { InjectConnection, InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { CustomAppCloudFileStoragePermissionsDto } from '../dto/custom_app_cloud_file_storage_permissions.dto';
import { CustomAppCloudFileStoragePermissions } from '../entity/custom_app_cloud_file_storage_permissions.entity';

@Injectable()
export class Custom_app_cloud_file_storage_permissionsService {
  constructor(
    @InjectRepository(CustomAppCloudFileStoragePermissions, 'wow_custom_app_db')
    @InjectConnection('wow_custom_app_db')
    private readonly customAppCloudFileStoragePermissionRepository: Repository<CustomAppCloudFileStoragePermissions>,
  ) {}

  async createCustomAppCloudFileStoragePermission(
    customAppCloudFileStoragePermissionDemoDto: CustomAppCloudFileStoragePermissionsDto,
  ): Promise<CustomAppCloudFileStoragePermissionsDto> {
    try {
      return await this.customAppCloudFileStoragePermissionRepository.save(
        customAppCloudFileStoragePermissionDemoDto,
      );
    } catch (err) {
      throw err;
    }
  }

  async updateCustomAppCloudFileStoragePermission(
    customAppCloudFileStoragePermissionDemoDto: CustomAppCloudFileStoragePermissionsDto,
  ): Promise<CustomAppCloudFileStoragePermissionsDto> {
    try {
      await this.customAppCloudFileStoragePermissionRepository.update(
        customAppCloudFileStoragePermissionDemoDto.custom_app_id,
        customAppCloudFileStoragePermissionDemoDto,
      );
      return this.customAppCloudFileStoragePermissionRepository.findOne({
        where: {
          custom_app_id:
            customAppCloudFileStoragePermissionDemoDto.custom_app_id,
        },
      });
    } catch (err) {
      throw err;
    }
  }
  async getCustomAppCloudFileStoragePermission(
    custom_app_id: number,
  ): Promise<CustomAppCloudFileStoragePermissionsDto> {
    try {
      return await this.customAppCloudFileStoragePermissionRepository.findOne({
        where: { custom_app_id: custom_app_id },
      });
    } catch (err) {
      throw err;
    }
  }

  async checkCustomAppCloudFileStoragePermissionExist(
    custom_app_id: number,
  ): Promise<boolean> {
    try {
      const user =
        await this.customAppCloudFileStoragePermissionRepository.findOne({
          where: { custom_app_id: custom_app_id },
        });
      return user ? true : false;
    } catch (err) {
      throw err;
    }
  }
}
