/*
https://docs.nestjs.com/controllers#controllers
*/

import { Body, Controller, Get, Post, Put, Query } from '@nestjs/common';
import { ApiTags } from '@nestjs/swagger';
import ResponseInterface from 'src/common/interface/response.interface';
import { CustomAppCloudFileStoragePermissionsDto } from '../dto/custom_app_cloud_file_storage_permissions.dto';
import { Custom_app_cloud_file_storage_permissionsService } from './custom_app_cloud_file_storage_permissions.service';

// @UseGuards(JwtAuthGuard)
// @ApiBearerAuth('JWT-auth')
@ApiTags('Custom App Cloud File Storage Permission')
@Controller('custom_app_cloud_file_storage_permission')
export class Custom_app_cloud_file_storage_permissionsController {
  constructor(
    private readonly custom_app_cloud_file_storage_permissionsService: Custom_app_cloud_file_storage_permissionsService,
  ) {}

  @Post('/add_custom_app_cloud_file_storage_permission')
  async createCustomAppAboutDemo(
    @Body() customAppAboutDemoDto: CustomAppCloudFileStoragePermissionsDto,
  ): Promise<ResponseInterface> {
    const alreadyExists =
      await this.custom_app_cloud_file_storage_permissionsService.checkCustomAppCloudFileStoragePermissionExist(
        customAppAboutDemoDto.custom_app_id,
      );
    if (alreadyExists) {
      const result =
        await this.custom_app_cloud_file_storage_permissionsService.updateCustomAppCloudFileStoragePermission(
          customAppAboutDemoDto,
        );
      return {
        statusCode: 200,
        message: `Updated Custom App Cloud File Storage Permission Successfully!`,
        data: result,
      };
    } else {
      const result =
        await this.custom_app_cloud_file_storage_permissionsService.createCustomAppCloudFileStoragePermission(
          customAppAboutDemoDto,
        );
      return {
        statusCode: 200,
        message: `Custom App Cloud File Storage Permission Created Successfully!`,
        data: result,
      };
    }
  }

  // @UseGuards(JwtAuthGuard)
  @Get('/get_custom_app_cloud_file_storage_permission')
  async getCustomAppAboutDemo(
    @Query('custom_app_id') custom_app_id: number,
  ): Promise<any> {
    const result =
      await this.custom_app_cloud_file_storage_permissionsService.getCustomAppCloudFileStoragePermission(
        custom_app_id,
      );
    return {
      statusCode: 200,
      message: `Get Custom App Cloud File Storage Permission Video Successfully!`,
      data: result,
    };
  }

  // @UseGuards(JwtAuthGuard)
  @Put('/update_custom_app_cloud_file_storage_permission')
  async updateCustomAppAboutDemo(
    @Body() customAppAboutDemoDto: CustomAppCloudFileStoragePermissionsDto,
  ): Promise<ResponseInterface> {
    const result =
      await this.custom_app_cloud_file_storage_permissionsService.updateCustomAppCloudFileStoragePermission(
        customAppAboutDemoDto,
      );
    return {
      statusCode: 200,
      message: `Updated Custom App Cloud File Storage PermissionF Video Successfully!`,
      data: result,
    };
  }
}
