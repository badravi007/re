import { ApiProperty } from '@nestjs/swagger';

export class CustomAppCommentsDto {
  @ApiProperty()
  comment_id: number;

  @ApiProperty()
  comment_utc_date_time: string;

  @ApiProperty()
  user_id: number;

  @ApiProperty()
  comment_text: string;

  @ApiProperty()
  comment_type: boolean;

  @ApiProperty()
  comment_reply: string;
}

export class UpdateCustomAppCommentsDto {
  @ApiProperty()
  comment_id: number;

  @ApiProperty()
  comment_utc_date_time: string;

  @ApiProperty()
  user_id: number;

  @ApiProperty()
  comment_text: string;
}

export class CustomAppCommentsGetDto {
  @ApiProperty()
  comment_utc_date_time: string;

  @ApiProperty()
  user_id: number;

  @ApiProperty()
  communication_text: number;
}

export class CustomAppReplayCommentsDto {
  @ApiProperty()
  comment_type: boolean;

  @ApiProperty()
  comment_reply: string;

  // @ApiProperty()
  // comment_utc_date_time: string;
}
