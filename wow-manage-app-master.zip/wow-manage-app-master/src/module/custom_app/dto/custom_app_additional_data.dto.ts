import { ApiProperty } from '@nestjs/swagger';
import { Column, Entity, PrimaryColumn, PrimaryGeneratedColumn } from 'typeorm';

export class CustomAppAdditionalDataDto {
  @ApiProperty()
  custom_app_id: number;

  @ApiProperty()
  can_this_custom_app_be_blocked_by_app_administrator: boolean;

  @ApiProperty()
  can_this_app_be_displayed_in_customerbizapp_launch_screen: boolean;

  @ApiProperty()
  does_this_app_have_configuration_data_specific_to_this_app: boolean;
}
