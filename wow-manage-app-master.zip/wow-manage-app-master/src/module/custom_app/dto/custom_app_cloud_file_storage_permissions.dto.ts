import { ApiProperty } from '@nestjs/swagger';

export class CustomAppCloudFileStoragePermissionsDto {
  @ApiProperty()
  custom_app_id: number;

  @ApiProperty()
  delete_folder: boolean;

  @ApiProperty()
  delete_file: boolean;

  @ApiProperty()
  copy_file: boolean;
}
