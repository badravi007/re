import { ApiProperty } from '@nestjs/swagger';

export class CustomAppCommunicationDto {
  @ApiProperty()
  communication_id: number;

  @ApiProperty()
  communication_utc_date_time: string;

  @ApiProperty()
  user_id: number;

  @ApiProperty()
  communication_text: string;
}
