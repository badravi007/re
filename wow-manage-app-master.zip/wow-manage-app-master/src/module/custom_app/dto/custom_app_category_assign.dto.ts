import { ApiProperty } from '@nestjs/swagger';

export class CustomCategoryAssignDto {
  @ApiProperty()
  id: number;

  @ApiProperty()
  user_app_country_code: string;

  @ApiProperty()
  user_app_business_category_id: string;

  @ApiProperty()
  user_app_category_id: string;

  @ApiProperty()
  user_app_id: number;

  @ApiProperty()
  custom_app_id: number;

  @ApiProperty()
  user_app_category_location: number;
}
