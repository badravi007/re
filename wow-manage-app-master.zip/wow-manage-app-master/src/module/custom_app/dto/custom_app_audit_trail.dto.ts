import { ApiProperty } from '@nestjs/swagger';

export class CustomAppAuditTrailDto {
  @ApiProperty()
  custom_app_id: number;

  @ApiProperty()
  custom_app_activity: string;

  @ApiProperty()
  custom_app_activity_by_user_id: string;

  @ApiProperty()
  custom_app_activity_utc_date_time: string;
}
