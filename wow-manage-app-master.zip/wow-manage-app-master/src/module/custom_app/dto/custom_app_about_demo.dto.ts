import { ApiProperty } from '@nestjs/swagger';

export class CustomAppAboutDemoDto {
  @ApiProperty()
  custom_app_id: number;

  @ApiProperty()
  custom_app_demo_video_path: string;

  @ApiProperty()
  custom_app_demo_video_thumb_nail_path: string;

  @ApiProperty()
  custom_app_demo_video_datetime_description_file: TimeStampDescription[];

  @ApiProperty()
  custom_app_attachments_file: object[];
}

class TimeStampDescription {
  @ApiProperty()
  description: string;
  @ApiProperty()
  title: string;
  @ApiProperty()
  time_stamp: string;
}
