import { ApiProperty } from '@nestjs/swagger';

export class CustomAppMasterDto {
  @ApiProperty()
  custom_app_id: number;

  @ApiProperty()
  custom_app_icon_name: string;

  @ApiProperty()
  custom_app_icon_image_path: string;

  // @ApiProperty()
  // custom_app_title_bar_name: string;

  @ApiProperty()
  custom_app_full_name: string;

  @ApiProperty()
  custom_app_development_status: boolean;
}

export class UpdateCustomAppMasterDto {
  @ApiProperty()
  custom_app_id: number;

  @ApiProperty()
  custom_app_icon_name: string;

  @ApiProperty()
  custom_app_icon_image_path: string;

  // @ApiProperty()
  // custom_app_title_bar_name: string;

  @ApiProperty()
  custom_app_full_name: string;

  @ApiProperty()
  custom_app_development_status: boolean;

  @ApiProperty()
  getster_id: string;

  @ApiProperty()
  custom_app_activity_utc_date_time: string;
}

export class UpdateCustomAppDevelopmentStatusDto {
  @ApiProperty()
  custom_app_id: number;

  @ApiProperty()
  custom_app_development_status: boolean;
}

export class CustomAppMasterAuditTrailDto extends CustomAppMasterDto {
  @ApiProperty()
  getster_id: string;

  @ApiProperty()
  custom_app_activity_utc_date_time: string;
}
