/*
https://docs.nestjs.com/providers#services
*/

import { Injectable } from '@nestjs/common';
import { InjectConnection } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { CustomAppCommunicationDto } from '../dto/custom_app_communication.dto';

@Injectable()
export class Custom_app_communicationService {
  constructor(
    @InjectConnection('wow_custom_app_db')
    private readonly customAppCommunicationRepository: Repository<null>,
  ) {}

  async insertCustomAppCommunication(
    custom_app_id: number,
    customAppCommunication: CustomAppCommunicationDto,
  ): Promise<any> {
    return await this.customAppCommunicationRepository.query(
      `insert into ${custom_app_id}_custom_app_communication values(
        0,'${customAppCommunication.communication_utc_date_time}',
        ${customAppCommunication.user_id},
        '${customAppCommunication.communication_text}'
        );`,
    );
  }

  async updateCustomAppCommunication(
    custom_app_id: number,
    communication_id: number,
    customAppCommunication: CustomAppCommunicationDto,
  ): Promise<any> {
    return await this.customAppCommunicationRepository.query(
      `update into ${custom_app_id}_custom_app_communication set communication_text ='${customAppCommunication.communication_text}' where  communication_id=${communication_id};`,
    );
  }

  async deleteCustomAppCommunication(
    custom_app_id: number,
    communication_id: number,
  ): Promise<any> {
    return await this.customAppCommunicationRepository.query(
      `delete from ${custom_app_id}_custom_app_communication where  communication_id = ${communication_id}`,
    );
  }

  async getCustomAppCommunication(custom_app_id: number): Promise<any> {
    try {
      return this.customAppCommunicationRepository.query(
        `select * from ${custom_app_id}_custom_app_communication;`,
      );
    } catch (err) {
      throw err;
    }
  }
}
