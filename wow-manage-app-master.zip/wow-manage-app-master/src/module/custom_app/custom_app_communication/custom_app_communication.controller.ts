/*
https://docs.nestjs.com/controllers#controllers
*/

import {
  Body,
  Controller,
  Delete,
  Get,
  HttpStatus,
  Post,
  Put,
  Query,
} from '@nestjs/common';
import { ApiTags } from '@nestjs/swagger';
import ResponseInterface from 'src/common/interface/response.interface';
import { CustomAppCommunicationDto } from '../dto/custom_app_communication.dto';
import { Custom_app_communicationService } from './custom_app_communication.service';

// @UseGuards(JwtAuthGuard)
// @ApiBearerAuth('JWT-auth')
@ApiTags('Custom App Communication')
@Controller('custom_app_communication')
export class Custom_app_communicationController {
  constructor(
    private readonly custom_app_communicationService: Custom_app_communicationService,
  ) {}

  @Post('/add_custom_app_communication?')
  async insertCustomAppCommunication(
    @Query('custom_app_id') custom_app_id: number,
    @Body() userAPpCommunicationDto: CustomAppCommunicationDto,
  ): Promise<ResponseInterface> {
    const result =
      await this.custom_app_communicationService.insertCustomAppCommunication(
        custom_app_id,
        userAPpCommunicationDto,
      );
    return {
      statusCode: HttpStatus.CREATED,
      message: 'Sent successful!!',
      data: result,
    };
  }

  @Put('/update_custom_app_communication?')
  async updateCustomAppCommunication(
    @Query('custom_app_id') custom_app_id: number,
    @Query('communication_id') communication_id: number,
    @Body() userAPpCommunicationDto: CustomAppCommunicationDto,
  ): Promise<ResponseInterface> {
    const result =
      await this.custom_app_communicationService.updateCustomAppCommunication(
        custom_app_id,
        communication_id,
        userAPpCommunicationDto,
      );
    return {
      statusCode: HttpStatus.CREATED,
      message: 'Updated successful !!',
      data: result,
    };
  }

  @Delete('/delete_custom_app_communication?')
  async deleteCustomAppCommunication(
    @Query('custom_app_id') custom_app_id: number,
    @Query('communication_id') communication_id: number,
  ): Promise<ResponseInterface> {
    const result =
      await this.custom_app_communicationService.deleteCustomAppCommunication(
        custom_app_id,
        communication_id,
      );
    return {
      statusCode: HttpStatus.CREATED,
      message: 'Deleted successful !!',
      data: result,
    };
  }

  @Get('/get_custom_app_communication?')
  async getCustomAppCommunication(
    @Query('custom_app_id') custom_app_id: number,
  ): Promise<ResponseInterface> {
    const result =
      await this.custom_app_communicationService.getCustomAppCommunication(
        custom_app_id,
      );
    return {
      statusCode: HttpStatus.CREATED,
      message: 'Get Communication successfully!!',
      data: result,
    };
  }
}
