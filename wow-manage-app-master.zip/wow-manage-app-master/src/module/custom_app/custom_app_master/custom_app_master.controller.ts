/*
https://docs.nestjs.com/controllers#controllers
*/

import {
  Body,
  Controller,
  Get,
  NotFoundException,
  Post,
  Put,
  Query,
  Res,
  UploadedFile,
  UseInterceptors,
} from '@nestjs/common';
import { FileInterceptor } from '@nestjs/platform-express';
import { ApiBody, ApiConsumes, ApiTags } from '@nestjs/swagger';
import { existsSync } from 'fs';
import { diskStorage } from 'multer';
import { ErrorCodeMap } from 'src/common/api-error/ErrorCodeMap';
import ResponseInterface from 'src/common/interface/response.interface';
import {
  editFileName,
  imageFileFilter,
} from 'src/shared/utils/file-upload.utils';
import { CustomCategoryAssignDto } from '../dto/custom_app_category_assign.dto';
import {
  CustomAppMasterAuditTrailDto,
  UpdateCustomAppDevelopmentStatusDto,
  UpdateCustomAppMasterDto,
} from '../dto/custom_app_master.dto';
import { Custom_app_masterService } from './custom_app_master.service';

// @UseGuards(JwtAuthGuard)
// @ApiBearerAuth('JWT-auth')
@ApiTags('Custom App Master')
@Controller('custom_app_master')
export class Custom_app_masterController {
  constructor(
    private readonly custom_app_masterService: Custom_app_masterService,
  ) {}

  @Post('/add_custom_app')
  @ApiConsumes('multipart/form-data')
  @ApiBody({
    schema: {
      type: 'object',
      properties: {
        custom_app_id: { type: 'number' },
        custom_app_icon_name: { type: 'string' },
        custom_app_full_name: { type: 'string' },
        custom_app_development_status: { type: 'boolean' },
        getster_id: { type: 'string' },
        custom_app_activity_utc_date_time: { type: 'string' },
        image: {
          type: 'string',
          format: 'binary',
        },
      },
    },
  })
  @UseInterceptors(
    FileInterceptor('image', {
      storage: diskStorage({
        destination: './src/assets/custom_app_icons',
        filename: editFileName,
      }),
      fileFilter: imageFileFilter,
    }),
  )
  async createUserAppMaster(
    @UploadedFile() file,
    @Body() customAppMasterDto: CustomAppMasterAuditTrailDto,
  ): Promise<ResponseInterface> {
    const data = {
      custom_app_id: customAppMasterDto?.custom_app_id,
      custom_app_icon_name: customAppMasterDto?.custom_app_icon_name,
      custom_app_full_name: customAppMasterDto?.custom_app_full_name,
      custom_app_icon_image_path: file?.filename,
      custom_app_development_status:
        customAppMasterDto?.custom_app_development_status,
      getster_id: customAppMasterDto?.getster_id,
      custom_app_activity_utc_date_time:
        customAppMasterDto?.custom_app_activity_utc_date_time,
    };

    const alreadyExists =
      await this.custom_app_masterService.checkCustomAppMasterExist(
        customAppMasterDto.custom_app_full_name,
      );
    if (alreadyExists) {
      return {
        statusCode: 101,
        message: `Custom App  ${ErrorCodeMap[101]}!`,
        data: null,
      };
    } else {
      const result = await this.custom_app_masterService.createCustomAppMaster(
        data,
      );
      return {
        statusCode: 200,
        message: `Custom App Created Successfully!`,
        data: result,
      };
    }
  }

  @Put('/update_custom_app')
  @ApiConsumes('multipart/form-data')
  @ApiBody({
    schema: {
      type: 'object',
      properties: {
        custom_app_id: { type: 'number' },
        custom_app_icon_name: { type: 'string' },
        custom_app_full_name: { type: 'string' },
        custom_app_development_status: { type: 'boolean' },
        getster_id: { type: 'string' },
        user_app_activity_utc_date_time: { type: 'string' },
        image: {
          type: 'string',
          format: 'binary',
        },
      },
    },
  })
  @UseInterceptors(
    FileInterceptor('image', {
      storage: diskStorage({
        destination: './src/assets/custom_app_icons',
        filename: editFileName,
      }),
      fileFilter: imageFileFilter,
    }),
  )
  async updateUserAppMaster(
    @UploadedFile() file,
    @Body() updateCustomAppMasterDto: UpdateCustomAppMasterDto,
  ): Promise<ResponseInterface> {
    const data = {
      custom_app_id: updateCustomAppMasterDto?.custom_app_id,
      custom_app_icon_name: updateCustomAppMasterDto?.custom_app_icon_name,
      custom_app_full_name: updateCustomAppMasterDto?.custom_app_full_name,
      custom_app_icon_image_path: file?.filename,
      custom_app_development_status:
        updateCustomAppMasterDto?.custom_app_development_status,
      getster_id: updateCustomAppMasterDto?.getster_id,
      custom_app_activity_utc_date_time:
        updateCustomAppMasterDto?.custom_app_activity_utc_date_time,
    };

    const result = await this.custom_app_masterService.updateCustomAppMaster(
      data,
    );
    return {
      statusCode: 200,
      message: `Updated Custom App Successfully!`,
      data: result,
    };
  }

  @Post('/assign_custom_app_to_user_category')
  async assignCustomAppCountryBusinessCategory(
    @Body()
    customCategoryAssignDto: CustomCategoryAssignDto,
  ): Promise<ResponseInterface> {
    const result =
      await this.custom_app_masterService.assignCustomAppCountryBusinessCategory(
        customCategoryAssignDto,
      );
    return {
      statusCode: 200,
      message: `User App Country/Business/Category Assigned Successfully!`,
      data: result,
    };
  }

  @Put('/update_custom_app_development_status')
  async updateUserAppDevelopmentStatus(
    @Body()
    updateCustomAppDevelopmentStatus: UpdateCustomAppDevelopmentStatusDto,
  ): Promise<ResponseInterface> {
    const result =
      await this.custom_app_masterService.updateCustomAppDevelopmentStatus(
        updateCustomAppDevelopmentStatus,
      );
    return {
      statusCode: 200,
      message: `Updated Custom App Development Status Successfully.`,
      data: result,
    };
  }

  // @Get('/get_all_custom_apps_by_category_wise')
  // async getAllCustomAppsByCategoryWise(): Promise<any> {
  //   const result =
  //     await this.custom_app_masterService.getAllCustomAppsByCategoryWise();
  //   return {
  //     statusCode: 200,
  //     message: `Get User App Category List Successfully.`,
  //     data: result,
  //   };
  // }

  @Get('/get_all_user_custom_apps_by_category_ids?')
  async getAllUserCustomAppsByCategoryIds(
    @Query('user_app_category_id') user_app_category_id: string,
  ): Promise<any> {
    const result =
      await this.custom_app_masterService.getAllUserCustomAppsByCategoryIds(
        user_app_category_id,
      );
    return {
      statusCode: 200,
      message: `Get User App Category List Successfully.`,
      data: result,
    };
  }

  @Get('/get_custom_app_by_id?')
  async getUserAppById(
    @Query('custom_app_id') custom_app_id: number,
  ): Promise<any> {
    const result = await this.custom_app_masterService.getCustomAppById(
      custom_app_id,
    );
    return {
      statusCode: 200,
      message: `Get All User App Successfully!`,
      data: result,
    };
  }

  @Get('/get_all_custom_app_audit_trail')
  async getAllBusinessCategoryAuditTrail(): Promise<any> {
    const result =
      await this.custom_app_masterService.getAllCustomAppAuditTrail();
    return {
      statusCode: 200,
      message: `Get Audit Trail Successfully!`,
      data: result,
    };
  }

  @Get('/get_file_custom_app_master')
  async getFileUserAppMaster(
    @Query('file_name') file_name: string,
    @Res() res,
  ): Promise<any> {
    try {
      if (!existsSync(`src/assets/custom_app_icons/${file_name}`)) {
        throw new NotFoundException();
      }
      return res.sendFile(file_name, {
        root: 'src/assets/custom_app_icons',
      });
    } catch (error) {
      throw error.response;
    }
  }
}
