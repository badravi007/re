import { Injectable } from '@nestjs/common';
import { InjectConnection, InjectRepository } from '@nestjs/typeorm';
import { unlink } from 'fs';
import { Repository } from 'typeorm';
import { CustomAppAuditTrailDto } from '../dto/custom_app_audit_trail.dto';
import { CustomCategoryAssignDto } from '../dto/custom_app_category_assign.dto';
import {
  CustomAppMasterAuditTrailDto,
  UpdateCustomAppDevelopmentStatusDto,
  UpdateCustomAppMasterDto,
} from '../dto/custom_app_master.dto';
import { CustomAppMaster } from '../entity/custom_app_master.entity';

@Injectable()
export class Custom_app_masterService {
  constructor(
    @InjectRepository(CustomAppMaster, 'wow_custom_app_db')
    @InjectConnection('wow_custom_app_db')
    private readonly customAppMasterRepository: Repository<CustomAppMaster>,
  ) {}

  async createCustomAppMaster(
    customAppMasterDto: CustomAppMasterAuditTrailDto,
  ): Promise<CustomAppMaster> {
    try {
      let body = {
        custom_app_id: customAppMasterDto.custom_app_id,
        custom_app_icon_name: customAppMasterDto.custom_app_icon_name,
        custom_app_full_name: customAppMasterDto.custom_app_full_name,
        custom_app_icon_image_path:
          customAppMasterDto.custom_app_icon_image_path,
        custom_app_development_status:
          customAppMasterDto.custom_app_development_status,
      };
      let result = await this.customAppMasterRepository.save(body);
      let audit_trail_body = {
        custom_app_id: result.custom_app_id,
        custom_app_activity: 'Add App',
        custom_app_activity_by_user_id: customAppMasterDto.getster_id,
        custom_app_activity_utc_date_time:
          customAppMasterDto.custom_app_activity_utc_date_time,
      };
      await this.insertCustomAppAuditTrailDto(audit_trail_body);
      return result;
    } catch (err) {
      throw err;
    }
  }

  async insertCustomAppAuditTrailDto(
    customAppAuditTrailDto: CustomAppAuditTrailDto,
  ): Promise<any> {
    try {
      return await this.customAppMasterRepository.query(`
      insert into wow_custom_app_db.custom_apps_audit_trail values(
        0,'${customAppAuditTrailDto.custom_app_id}',
        '${customAppAuditTrailDto.custom_app_activity}',
        '${customAppAuditTrailDto.custom_app_activity_by_user_id}',
        '${customAppAuditTrailDto.custom_app_activity_utc_date_time}'
      )
      `);
    } catch (err) {
      throw err;
    }
  }

  async assignCustomAppCountryBusinessCategory(
    customCategoryAssign: CustomCategoryAssignDto,
  ): Promise<any> {
    try {
      let result;
      let allInfo = await this.customAppMasterRepository.query(`
        SELECT * FROM user_app_db.user_app_country_business_category_location;
        `);
      let letFindCategoryId = await this.customAppMasterRepository.query(`
        SELECT * FROM user_app_db.user_app_country_business_category_location  where user_app_category_id = '${customCategoryAssign.user_app_category_id}';
        `);

      if (letFindCategoryId.length > 0) {
        for (let j = 0; j < allInfo.length; j++) {
          if (
            customCategoryAssign.user_app_category_id ===
              allInfo[j].user_app_category_id &&
            allInfo[j].custom_app_id !== null &&
            allInfo[j].custom_app_id != customCategoryAssign.custom_app_id
          ) {
            result = await this.customAppMasterRepository.query(
              `insert into user_app_db.user_app_country_business_category_location values (0,
                '${allInfo[j].user_app_country_code}',
                '${allInfo[j].user_app_business_category_id}',
                '${allInfo[j].user_app_category_id}',
              ${customCategoryAssign.user_app_id},
              ${customCategoryAssign.custom_app_id},0);`,
            );
          }
        }
      } else {
        result = await this.customAppMasterRepository.query(
          `insert into user_app_db.user_app_country_business_category_location values (0,
            '${customCategoryAssign.user_app_country_code}',
            '${customCategoryAssign.user_app_business_category_id}',
            '${customCategoryAssign.user_app_category_id}',
          ${customCategoryAssign.user_app_id},
          ${customCategoryAssign.custom_app_id},0);`,
        );
      }

      return result;
    } catch (err) {
      throw err;
    }
  }

  async updateCustomAppMaster(
    updateCustomAppMasterDto: UpdateCustomAppMasterDto,
  ): Promise<CustomAppMaster> {
    try {
      let data: UpdateCustomAppMasterDto = await this.customAppMasterRepository
        .query(
          `
      SELECT * FROM wow_custom_app_db.custom_app_master
      where custom_app_id='${updateCustomAppMasterDto.custom_app_id}'
     `,
        )
        .then((data) => data[0]);
      const {
        custom_app_icon_name,
        custom_app_icon_image_path,
        custom_app_full_name,
        custom_app_development_status,
      } = data;

      if (updateCustomAppMasterDto?.custom_app_icon_image_path) {
        unlink(
          './src/assets/custom_app_icons/' + custom_app_icon_image_path,
          (error) => {
            console.log(error);
          },
        );
      }

      let result = await this.customAppMasterRepository.query(`
      update wow_custom_app_db.custom_app_master set
        custom_app_icon_name='${
          updateCustomAppMasterDto.custom_app_icon_name ?? custom_app_icon_name
        }',
        custom_app_icon_image_path='${
          updateCustomAppMasterDto.custom_app_icon_image_path ??
          custom_app_icon_image_path
        }',
        custom_app_full_name='${
          updateCustomAppMasterDto.custom_app_full_name ?? custom_app_full_name
        }',
        custom_app_development_status='${
          updateCustomAppMasterDto.custom_app_development_status
        }'
       where custom_app_id='${
         updateCustomAppMasterDto.custom_app_id ?? custom_app_development_status
       }'`);

      let audit_trail_body = {
        custom_app_id: updateCustomAppMasterDto.custom_app_id,
        custom_app_activity: 'Edit App',
        custom_app_activity_by_user_id: updateCustomAppMasterDto.getster_id,
        custom_app_activity_utc_date_time:
          updateCustomAppMasterDto.custom_app_activity_utc_date_time,
      };

      await this.insertCustomAppAuditTrailDto(audit_trail_body);
      return result;
    } catch (err) {
      throw err;
    }
  }

  async updateCustomAppDevelopmentStatus(
    updateCustomAppDevelopmentStatus: UpdateCustomAppDevelopmentStatusDto,
  ): Promise<boolean> {
    try {
      const result = await this.customAppMasterRepository.update(
        updateCustomAppDevelopmentStatus.custom_app_id,
        updateCustomAppDevelopmentStatus,
      );
      return result ? true : false;
    } catch (err) {
      throw err;
    }
  }

  async checkCustomAppMasterExist(
    custom_app_full_name: string,
  ): Promise<boolean> {
    try {
      const user = await this.customAppMasterRepository.findOne({
        where: { custom_app_full_name: custom_app_full_name },
      });
      return user ? true : false;
    } catch (err) {
      throw err;
    }
  }

  // async getAllCustomAppsByCategoryWise(): Promise<any> {
  //   try {
  //     // let connection = getConnection('user_app_db');
  //     let get_all_user_apps = await this.customAppMasterRepository.query(`
  //             SELECT master.custom_app_id,
  //             master.custom_app_icon_name,
  //             master.custom_app_icon_image_path,
  //             master.custom_app_full_name,
  //             master.custom_app_development_status,

  //             assign.user_app_category_location,
  //             assign.user_app_educational_institution_category_id,
  //             assign.user_app_country_code,
  //             assign.custom_app_id,

  //             catLoc.user_app_category_name as CategoryName,
  //             catLoc.user_app_category_name as user_app_category_name,
  //             catLoc.parent_user_app_category_id,
  //             catLoc.user_app_category_id

  //             FROM wow_custom_app_db.custom_app_master  master
  //             join
  //               wow_user_app_db.user_app_country_educational_institution_category_location assign on  master.custom_app_id = assign.custom_app_id
  //             join
  //               wow_user_app_db.user_app_categories catLoc  on assign.user_app_category_id=catLoc.user_app_category_id
  //           `);

  //     let get_all_category = await this.customAppMasterRepository.query(
  //       `SELECT * FROM wow_user_app_db.user_app_categories;`,
  //     );

  //     let body: any[] = [];
  //     let main_count = 0;
  //     for (let i = 0; i < get_all_category.length; i++) {
  //       let user_app_category_name = get_all_category[i].user_app_category_name;
  //       let data: any[] = [];

  //       let app_count = 0;
  //       for (let j = 0; j < get_all_user_apps.length; j++) {
  //         if (
  //           get_all_category[i].user_app_category_id ===
  //             get_all_user_apps[j].user_app_category_id &&
  //           get_all_user_apps[j].custom_app_id != null
  //         ) {
  //           if (app_count === 0) {
  //             data.push(get_all_user_apps[j]);
  //             app_count++;
  //           }

  //           let valid: boolean = false;
  //           for (let k = 0; k < data.length; k++) {
  //             if (
  //               data[k].custom_app_id === get_all_user_apps[j].custom_app_id &&
  //               data[k].user_app_category_id ===
  //                 get_all_user_apps[j].user_app_category_id
  //             ) {
  //               valid = true;
  //             } else {
  //             }
  //           }
  //           if (!valid) {
  //             data.push(get_all_user_apps[j]);
  //           }
  //           //
  //         }
  //       }

  //       main_count++;
  //       if (main_count > i && data.length != 0) {
  //         body.push({
  //           user_app_category_name: user_app_category_name,
  //           data: data,
  //         });
  //       }
  //       user_app_category_name = null;
  //       data = [null];
  //     }

  //     return await body;
  //   } catch (err) {
  //     throw err;
  //   }
  // }

  async getAllUserCustomAppsByCategoryIds(id: string): Promise<CustomApp[]> {
    try {
      // let connection = getConnection('user_app_db');
      let get_all_user_apps = await this.customAppMasterRepository.query(`
            SELECT
            a.custom_app_id,
            a.custom_app_icon_name,
            a.custom_app_icon_image_path,
            a.custom_app_full_name,
            a.custom_app_development_status,

            b.user_app_category_location,
            b.custom_app_id,

            c.user_app_category_name as CategoryName,
            c.user_app_category_name as user_app_category_name,
            c.parent_user_app_category_id,
            c.user_app_category_id

            FROM wow_custom_app_db.custom_app_master  a

            join wow_user_app_db.user_app_and_customapp_location_and_classify_user_app_category b on  a.custom_app_id = b.custom_app_id

            join wow_user_app_db.user_app_categories c  on b.user_app_category_id=c.user_app_category_id
          `);

      let category_id: any[] = id.split(',');
      let body: any[] = [];
      let main_count = 0;
      for (let i = 0; i < category_id.length; i++) {
        let user_app_category_name = await this.customAppMasterRepository.query(
          `SELECT * FROM wow_user_app_db.user_app_categories where user_app_category_id = '${category_id[i]}';`,
        );
        let data: any[] = [];

        for (let j = 0; j < get_all_user_apps.length; j++) {
          if (category_id[i] === get_all_user_apps[j].user_app_category_id) {
            data.push(get_all_user_apps[j]);
          }
        }
        main_count++;
        if (main_count > i && data.length != 0) {
          body.push({
            user_app_category_name:
              user_app_category_name[0].user_app_category_name,
            data: data,
          });
        }
        user_app_category_name = null;
        data = [null];
      }

      return await body;
    } catch (err) {
      throw err;
    }
  }

  async getCustomAppById(custom_app_id: number): Promise<CustomAppMaster[]> {
    try {
      // let connection = getConnection('wow_custom_app_db');
      let get_all_user_apps = await this.customAppMasterRepository.query(
        `SELECT * FROM wow_custom_app_db.custom_app_master where custom_app_id= ${custom_app_id}`,
      );

      let userAppCategoryIdList = await this.customAppMasterRepository.query(`
      SELECT user_app_category_id FROM wow_user_app_db.user_app_and_customapp_location_and_classify_user_app_category
      WHERE custom_app_id=${custom_app_id}
    `);

      let categoryIdList: any[] = [];
      for (let i = 0; i < userAppCategoryIdList.length; i++) {
        const element = userAppCategoryIdList[i].user_app_category_id;
        categoryIdList.push(element);
      }
      let data = [
        {
          ...get_all_user_apps[0],
          user_app_category_ids: categoryIdList.toString(),
        },
      ];
      return data;
    } catch (err) {
      throw err;
    }
  }

  async getAllCustomAppAuditTrail(): Promise<any> {
    try {
      let audit_trail = await this.customAppMasterRepository.query(`
      SELECT * FROM wow_custom_app_db.custom_apps_audit_trail;
      `);

      let result: any[] = [];
      for (let i = 0; i < audit_trail.length; i++) {
        let user_app_icon_name = await this.customAppMasterRepository.query(`
        SELECT * FROM wow_custom_app_db.custom_app_master where custom_app_id = '${audit_trail[i].custom_app_id}';`);

        let profile_name = await this.customAppMasterRepository.query(`
        SELECT * FROM in_manage_get_wow_education_db.getster_profile where getster_id = '${audit_trail[i].custom_app_activity_by_user_id}';`);

        if (user_app_icon_name.length > 0) {
          result.push({
            custom_app_id: audit_trail[i].custom_app_id,
            custom_app_activity: audit_trail[i].custom_app_activity,
            custom_app_activity_by_user_id:
              audit_trail[i].custom_app_activity_by_user_id,
            custom_app_activity_utc_date_time:
              audit_trail[i].custom_app_activity_utc_date_time,
            custom_app_icon_name: user_app_icon_name[0].custom_app_icon_name,
            first_name: profile_name[0].first_name,
          });
        }
      }
      return result;
    } catch (err) {
      throw err;
    }
  }
}

interface CustomApp {
  category_name: string;
  data: any;
}
