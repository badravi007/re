/*
https://docs.nestjs.com/modules
*/

import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { Custom_app_about_demoController } from './custom_app_about_demo/custom_app_about_demo.controller';
import { Custom_app_about_demoService } from './custom_app_about_demo/custom_app_about_demo.service';
import { Custom_app_additional_dataController } from './custom_app_additional_data/custom_app_additional_data.controller';
import { Custom_app_additional_dataService } from './custom_app_additional_data/custom_app_additional_data.service';
import { Custom_app_cloud_file_storage_permissionsController } from './custom_app_cloud_file_storage_permissions/custom_app_cloud_file_storage_permissions.controller';
import { Custom_app_cloud_file_storage_permissionsService } from './custom_app_cloud_file_storage_permissions/custom_app_cloud_file_storage_permissions.service';
import { Custom_app_commentsController } from './custom_app_comments/custom_app_comments.controller';
import { Custom_app_commentsService } from './custom_app_comments/custom_app_comments.service';
import { Custom_app_communicationController } from './custom_app_communication/custom_app_communication.controller';
import { Custom_app_communicationService } from './custom_app_communication/custom_app_communication.service';
import { Custom_app_masterController } from './custom_app_master/custom_app_master.controller';
import { Custom_app_masterService } from './custom_app_master/custom_app_master.service';
import { CustomAppAboutDemo } from './entity/custom_app_about_demo.entity';
import { CustomAppAdditionalData } from './entity/custom_app_additional_data.entity';
import { CustomAppAuditTrail } from './entity/custom_app_audit_trail.entity';
import { CustomAppCloudFileStoragePermissions } from './entity/custom_app_cloud_file_storage_permissions.entity';
import { CustomAppCustomersList } from './entity/custom_app_custoners_list.entity';
import { CustomAppMaster } from './entity/custom_app_master.entity';

@Module({
  imports: [
    TypeOrmModule.forFeature(
      [
        CustomAppMaster,
        CustomAppCloudFileStoragePermissions,
        CustomAppAdditionalData,
        CustomAppAboutDemo,
        CustomAppAuditTrail,
        CustomAppCustomersList,
      ],
      'wow_custom_app_db',
    ),
  ],
  controllers: [
    Custom_app_masterController,
    Custom_app_communicationController,
    Custom_app_commentsController,
    Custom_app_cloud_file_storage_permissionsController,
    Custom_app_additional_dataController,
    Custom_app_about_demoController,
  ],
  providers: [
    Custom_app_masterService,
    Custom_app_communicationService,
    Custom_app_commentsService,
    Custom_app_cloud_file_storage_permissionsService,
    Custom_app_additional_dataService,
    Custom_app_about_demoService,
  ],

  exports: [
    Custom_app_masterService,
    Custom_app_communicationService,
    Custom_app_commentsService,
    Custom_app_cloud_file_storage_permissionsService,
    Custom_app_additional_dataService,
    Custom_app_about_demoService,
  ],
})
export class Custom_appModule {}
