/*
https://docs.nestjs.com/providers#services
*/

import { Injectable } from '@nestjs/common';
import { InjectConnection, InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { CustomAppAboutDemoDto } from '../dto/custom_app_about_demo.dto';
import { CustomAppAboutDemo } from '../entity/custom_app_about_demo.entity';

@Injectable()
export class Custom_app_about_demoService {
  constructor(
    @InjectRepository(CustomAppAboutDemo, 'wow_custom_app_db')
    @InjectConnection('wow_custom_app_db')
    private readonly customAppAboutDemoRepository: Repository<CustomAppAboutDemo>,
  ) {}

  async createCustomAppAboutDemo(
    customAppAboutDemoDto: CustomAppAboutDemoDto,
  ): Promise<CustomAppAboutDemoDto> {
    try {
      return await this.customAppAboutDemoRepository.save(
        customAppAboutDemoDto,
      );
    } catch (err) {
      throw err;
    }
  }

  async updateCustomAppAboutDemo(
    customAppAboutDemoDto: CustomAppAboutDemoDto,
  ): Promise<CustomAppAboutDemoDto> {
    try {
      let isFound = await this.customAppAboutDemoRepository.findOne({
        where: { custom_app_id: customAppAboutDemoDto.custom_app_id },
      });

      if (isFound) {
        await this.customAppAboutDemoRepository.update(
          customAppAboutDemoDto.custom_app_id,
          customAppAboutDemoDto,
        );
      } else {
        await this.customAppAboutDemoRepository.save(customAppAboutDemoDto);
      }
      return await this.customAppAboutDemoRepository.findOne({
        where: { custom_app_id: customAppAboutDemoDto.custom_app_id },
      });
    } catch (err) {
      throw err;
    }
  }
  async getCustomAppAboutDemo(
    custom_app_id: number,
  ): Promise<CustomAppAboutDemoDto> {
    try {
      return await this.customAppAboutDemoRepository.findOne({
        where: { custom_app_id: custom_app_id },
      });
    } catch (err) {
      throw err;
    }
  }

  async checkCustomAppAboutDemoExist(custom_app_id: number): Promise<boolean> {
    try {
      const user = await this.customAppAboutDemoRepository.findOne({
        where: { custom_app_id: custom_app_id },
      });
      return user ? true : false;
    } catch (err) {
      throw err;
    }
  }
}
