/*
https://docs.nestjs.com/controllers#controllers
*/

import { Body, Controller, Get, Post, Put, Query } from '@nestjs/common';
import { ApiTags } from '@nestjs/swagger';
import ResponseInterface from 'src/common/interface/response.interface';
import { CustomAppAboutDemoDto } from '../dto/custom_app_about_demo.dto';
import { Custom_app_about_demoService } from './custom_app_about_demo.service';

// @UseGuards(JwtAuthGuard)
// @ApiBearerAuth('JWT-auth')
@ApiTags('Custom App About Demo Video')
@Controller('custom_app_about_demo')
export class Custom_app_about_demoController {
  constructor(
    private readonly custom_app_about_demoService: Custom_app_about_demoService,
  ) {}

  @Post('/add_custom_app_about_demo_video_description')
  async createCustomAppAboutDemo(
    @Body() customAppAboutDemoDto: CustomAppAboutDemoDto,
  ): Promise<ResponseInterface> {
    const alreadyExists =
      await this.custom_app_about_demoService.checkCustomAppAboutDemoExist(
        customAppAboutDemoDto.custom_app_id,
      );

    if (alreadyExists) {
      const result =
        await this.custom_app_about_demoService.updateCustomAppAboutDemo(
          customAppAboutDemoDto,
        );
      return {
        statusCode: 200,
        message: `Updated Custom App About Demo Video Successfully!`,
        data: result,
      };
    } else {
      const result =
        await this.custom_app_about_demoService.createCustomAppAboutDemo(
          customAppAboutDemoDto,
        );
      return {
        statusCode: 200,
        message: `Custom App About Demo Created Successfully!`,
        data: result,
      };
    }
  }

  @Get('/get_custom_app_about_demo_video_description')
  async getCustomAppAboutDemo(
    @Query('custom_app_id') custom_app_id: number,
  ): Promise<any> {
    const result =
      await this.custom_app_about_demoService.getCustomAppAboutDemo(
        custom_app_id,
      );
    return {
      statusCode: 200,
      message: `Get Custom App About Demo Video Successfully!`,
      data: result,
    };
  }

  @Put('/update_custom_app_about_demo')
  async updateCustomAppAboutDemo(
    @Body() customAppAboutDemoDto: CustomAppAboutDemoDto,
  ): Promise<ResponseInterface> {
    const result =
      await this.custom_app_about_demoService.updateCustomAppAboutDemo(
        customAppAboutDemoDto,
      );
    return {
      statusCode: 200,
      message: `Updated Custom App About Demo Video Successfully!`,
      data: result,
    };
  }
}
