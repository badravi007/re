/*
https://docs.nestjs.com/providers#services
*/

import { Injectable } from '@nestjs/common';
import { InjectConnection, InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { CustomAppAdditionalDataDto } from '../dto/custom_app_additional_data.dto';
import { CustomAppAdditionalData } from '../entity/custom_app_additional_data.entity';

@Injectable()
export class Custom_app_additional_dataService {
  constructor(
    @InjectRepository(CustomAppAdditionalData, 'wow_custom_app_db')
    @InjectConnection('wow_custom_app_db')
    private readonly customAppAdditionalDataRepository: Repository<CustomAppAdditionalData>,
  ) {}

  async createCustomAppAdditionalData(
    customAppAdditionalDataDto: CustomAppAdditionalDataDto,
  ): Promise<CustomAppAdditionalDataDto> {
    try {
      return await this.customAppAdditionalDataRepository.save(
        customAppAdditionalDataDto,
      );
    } catch (err) {
      throw err;
    }
  }

  async updateCustomAppAdditionalData(
    customAppAdditionalDataDto: CustomAppAdditionalDataDto,
  ): Promise<CustomAppAdditionalDataDto> {
    try {
      await this.customAppAdditionalDataRepository.update(
        customAppAdditionalDataDto.custom_app_id,
        customAppAdditionalDataDto,
      );
      return this.customAppAdditionalDataRepository.findOne({
        where: { custom_app_id: customAppAdditionalDataDto.custom_app_id },
      });
    } catch (err) {
      throw err;
    }
  }

  async getCustomAppAdditionalData(
    custom_app_id: number,
  ): Promise<CustomAppAdditionalDataDto> {
    try {
      return await this.customAppAdditionalDataRepository.findOne({
        where: { custom_app_id: custom_app_id },
      });
    } catch (err) {
      throw err;
    }
  }
  async checkCustomAppAdditionalDataExist(
    custom_app_id: number,
  ): Promise<boolean> {
    try {
      const user = await this.customAppAdditionalDataRepository.findOne({
        where: { custom_app_id: custom_app_id },
      });
      return user ? true : false;
    } catch (err) {
      throw err;
    }
  }
}
