/*
https://docs.nestjs.com/controllers#controllers
*/

import { Body, Controller, Get, Post, Put, Query } from '@nestjs/common';
import { ApiTags } from '@nestjs/swagger';
import ResponseInterface from 'src/common/interface/response.interface';
import { CustomAppAdditionalDataDto } from '../dto/custom_app_additional_data.dto';
import { Custom_app_additional_dataService } from './custom_app_additional_data.service';

// @UseGuards(JwtAuthGuard)
// @ApiBearerAuth('JWT-auth')
@ApiTags('Custom App Additional Data')
@Controller('custom_app_additional_data')
export class Custom_app_additional_dataController {
  constructor(
    private readonly custom_app_additional_dataService: Custom_app_additional_dataService,
  ) {}

  @Post('/add_custom_app_additional_data')
  async createCustomAppAboutDemo(
    @Body() customAppAdditionalDataDto: CustomAppAdditionalDataDto,
  ): Promise<ResponseInterface> {
    const alreadyExists =
      await this.custom_app_additional_dataService.checkCustomAppAdditionalDataExist(
        customAppAdditionalDataDto.custom_app_id,
      );
    if (alreadyExists) {
      const result =
        await this.custom_app_additional_dataService.updateCustomAppAdditionalData(
          customAppAdditionalDataDto,
        );
      return {
        statusCode: 200,
        message: `Updated Custom App Additional Data Successfully!`,
        data: result,
      };
    } else {
      const result =
        await this.custom_app_additional_dataService.createCustomAppAdditionalData(
          customAppAdditionalDataDto,
        );
      return {
        statusCode: 200,
        message: `Custom App Additional Data Created Successfully!`,
        data: result,
      };
    }
  }

  @Get('/get_custom_app_additional_data')
  async getCustomAppAboutDemo(
    @Query('custom_app_id') custom_app_id: number,
  ): Promise<any> {
    const result =
      await this.custom_app_additional_dataService.getCustomAppAdditionalData(
        custom_app_id,
      );
    return {
      statusCode: 200,
      message: `Get Custom App Additional Data Successfully!`,
      data: result,
    };
  }

  @Put('/update_custom_app_additional_data')
  async updateCustomAppAboutDemo(
    @Body() customAppAdditionalDataDto: CustomAppAdditionalDataDto,
  ): Promise<ResponseInterface> {
    const result =
      await this.custom_app_additional_dataService.updateCustomAppAdditionalData(
        customAppAdditionalDataDto,
      );
    return {
      statusCode: 200,
      message: `Updated Custom App Additional Data Successfully!`,
      data: result,
    };
  }
}
