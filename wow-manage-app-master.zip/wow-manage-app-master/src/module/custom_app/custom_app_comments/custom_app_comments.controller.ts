/*
https://docs.nestjs.com/controllers#controllers
*/

import {
  Body,
  Controller,
  Delete,
  Get,
  HttpStatus,
  Post,
  Put,
  Query,
} from '@nestjs/common';
import { ApiTags } from '@nestjs/swagger';
import ResponseInterface from 'src/common/interface/response.interface';
import {
  CustomAppCommentsDto,
  CustomAppReplayCommentsDto,
  UpdateCustomAppCommentsDto,
} from '../dto/custom_app_comments.dto';
import { Custom_app_commentsService } from './custom_app_comments.service';

// @UseGuards(JwtAuthGuard)
// @ApiBearerAuth('JWT-auth')
@ApiTags('Custom App Comments')
@Controller('custom_app_comments')
export class Custom_app_commentsController {
  constructor(
    private readonly custom_app_commentsService: Custom_app_commentsService,
  ) {}

  @Post('/create_custom_app_comments_communication_table?')
  async creatDynamicTable(
    @Query('custom_app_id') custom_app_id: number,
  ): Promise<ResponseInterface> {
    const result = await this.custom_app_commentsService.creatDynamicTable(
      custom_app_id,
    );
    return {
      statusCode: HttpStatus.CREATED,
      message: 'Table created successful !!',
      data: result,
    };
  }

  @Post('/add_custom_app_comments?')
  async insertCustomAppComments(
    @Query('custom_app_id') custom_app_id: number,
    @Body() customAppCommunicationDto: CustomAppCommentsDto,
  ): Promise<ResponseInterface> {
    const result =
      await this.custom_app_commentsService.insertCustomAppComments(
        custom_app_id,
        customAppCommunicationDto,
      );
    return {
      statusCode: HttpStatus.CREATED,
      message: 'Sent successful!!',
      data: result,
    };
  }

  @Put('/update_custom_app_comments?')
  async updateCustomAppComments(
    @Query('custom_app_id') custom_app_id: number,
    @Query('comment_id') comment_id: number,
    @Body() customAppCommunicationDto: UpdateCustomAppCommentsDto,
  ): Promise<ResponseInterface> {
    const result =
      await this.custom_app_commentsService.updateCustomAppComments(
        custom_app_id,
        comment_id,
        customAppCommunicationDto,
      );
    return {
      statusCode: HttpStatus.CREATED,
      message: 'Updated successful !!',
      data: result,
    };
  }

  @Put('/update_custom_app_comments_type?')
  async updateCustomAppCommentsType(
    @Query('custom_app_id') custom_app_id: number,
    @Query('comment_id') comment_id: number,
    @Body() customAppCommunicationDto: CustomAppReplayCommentsDto,
  ): Promise<ResponseInterface> {
    const result =
      await this.custom_app_commentsService.updateCustomAppCommentsType(
        custom_app_id,
        comment_id,
        customAppCommunicationDto,
      );
    return {
      statusCode: HttpStatus.CREATED,
      message: 'Updated successful !!',
      data: result,
    };
  }

  @Delete('/delete_custom_app_comments?')
  async deleteCustomAppComments(
    @Query('custom_app_id') custom_app_id: number,
    @Query('comment_id') comment_id: number,
  ): Promise<ResponseInterface> {
    const result =
      await this.custom_app_commentsService.deleteCustomAppComments(
        custom_app_id,
        comment_id,
      );
    return {
      statusCode: HttpStatus.CREATED,
      message: 'Deleted successful !!',
      data: result,
    };
  }
  @Get('/get_custom_app_comments?')
  async getCustomAppComments(
    @Query('custom_app_id') custom_app_id: number,
  ): Promise<ResponseInterface> {
    const result = await this.custom_app_commentsService.getCustomAppComments(
      custom_app_id,
    );
    return {
      statusCode: HttpStatus.CREATED,
      message: 'Get Comments successfully!!',
      data: result,
    };
  }
}
