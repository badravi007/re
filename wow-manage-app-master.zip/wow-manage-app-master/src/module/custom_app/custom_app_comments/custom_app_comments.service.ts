/*
https://docs.nestjs.com/providers#services
*/

import { Injectable } from '@nestjs/common';
import { InjectConnection } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import {
  CustomAppCommentsDto,
  CustomAppCommentsGetDto,
  CustomAppReplayCommentsDto,
  UpdateCustomAppCommentsDto,
} from '../dto/custom_app_comments.dto';

@Injectable()
export class Custom_app_commentsService {
  constructor(
    @InjectConnection('wow_custom_app_db')
    private readonly customAppCommentsRepository: Repository<null>,
  ) {}

  async creatDynamicTable(custom_app_id: number): Promise<any> {
    await this.customAppCommentsRepository.query(
      `create table ${custom_app_id}_custom_app_comments (
      comment_id int not null auto_increment,
      comment_utc_date_time varchar(30) not null,
      user_id  int not null,
      comment_text varchar(100) not null,
      comment_type int not null ,
      comment_reply varchar(100) null,
      primary key(comment_id));`,
    );

    await this.customAppCommentsRepository.query(
      `create table ${custom_app_id}_custom_app_communication (
        communication_id int not null auto_increment,
        communication_utc_date_time varchar(30) not null,
        user_id  int not null,
      	communication_text varchar(100) not null,
        primary key(communication_id));`,
    );

    return 'Success';
  }

  async insertCustomAppComments(
    custom_app_id: number,
    customAppComments: CustomAppCommentsDto,
  ): Promise<any> {
    return await this.customAppCommentsRepository.query(
      `insert into ${custom_app_id}_custom_app_comments values(
        0,'${customAppComments.comment_utc_date_time}',
        ${customAppComments.user_id},
        '${customAppComments.comment_text}',
        ${customAppComments.comment_type},
        '${customAppComments.comment_reply}')`,
    );
  }

  async updateCustomAppComments(
    custom_app_id: number,
    comment_id: number,
    customAppComments: UpdateCustomAppCommentsDto,
  ): Promise<any> {
    return await this.customAppCommentsRepository.query(
      `update ${custom_app_id}_custom_app_comments set
      comment_text =${customAppComments.comment_text},
      where comment_id=${comment_id};`,
    );
  }
  async updateCustomAppCommentsType(
    custom_app_id: number,
    comment_id: number,
    customAppReplyCommentsDto: CustomAppReplayCommentsDto,
  ): Promise<any> {
    return await this.customAppCommentsRepository.query(
      `update ${custom_app_id}_custom_app_comments set
      comment_type =${customAppReplyCommentsDto.comment_type},
      comment_reply='${customAppReplyCommentsDto.comment_reply}'
      where comment_id=${comment_id};`,
    );
  }

  async deleteCustomAppComments(
    custom_app_id: number,
    comment_id: number,
  ): Promise<any> {
    return await this.customAppCommentsRepository.query(
      `delete from ${custom_app_id}_custom_app_comments where  comment_id = ${comment_id}`,
    );
  }

  async getCustomAppComments(
    custom_app_id: number,
  ): Promise<CustomAppCommentsGetDto> {
    try {
      return await this.customAppCommentsRepository.query(
        `select * from ${custom_app_id}_custom_app_comments;`,
      );
    } catch (err) {
      throw err;
    }
  }
}
