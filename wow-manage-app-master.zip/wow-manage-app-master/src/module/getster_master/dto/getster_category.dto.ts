import { ApiProperty } from '@nestjs/swagger';

export class GetsterCategoryDto {
  @ApiProperty()
  getster_category_id: string;

  @ApiProperty()
  parent_getster_category_id: string | null;

  @ApiProperty()
  getster_category_name: string;

  @ApiProperty()
  is_the_getster_category_hidden: boolean;

  @ApiProperty()
  getster_category_type: number;
}

export class UpdateGetsterCategoryDto {
  @ApiProperty()
  getster_category_id: string;

  @ApiProperty()
  getster_category_name: string;
}
export class HideGetsterCategoryDto {
  @ApiProperty()
  getster_category_id: string;

  @ApiProperty()
  is_the_getster_category_hidden: boolean;
}

export class GetGetsterAdditionalFieldNameDto {
  @ApiProperty()
  getster_category_id: JSON;
}
