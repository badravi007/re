import { ApiProperty } from '@nestjs/swagger';

export class Additional_data_form_field {
  @ApiProperty()
  headerKey: string;
  @ApiProperty()
  headerType: string;
  @ApiProperty()
  headerValue?: any;
  @ApiProperty()
  isMandatory: boolean;
}
export class Selected_getster_apps {
  @ApiProperty()
  getster_app_category_id: string;
  @ApiProperty()
  getster_app_id: number;
}

export class AddUserCategoryWiseAppAccess {
  @ApiProperty()
  selected_getster_apps: Selected_getster_apps[];
  @ApiProperty()
  additional_getster_data_field_name: Additional_data_form_field[];
  @ApiProperty()
  getster_category_id: string;
  @ApiProperty()
  is_location_of_getster_required: boolean;
}
