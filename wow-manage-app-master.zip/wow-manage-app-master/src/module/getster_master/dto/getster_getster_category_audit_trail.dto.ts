import { ApiProperty } from '@nestjs/swagger';

export class GetsterGetsterCategoryAuditTrailDto {
  @ApiProperty()
  entry_by_getster_id?: string;
  @ApiProperty()
  entry_type?: string;
  @ApiProperty()
  entry_date_time?: string;
  @ApiProperty()
  entry_by_getster_category_id?: string;
}
