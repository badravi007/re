import { ApiProperty } from '@nestjs/swagger';
import { IsNotEmpty } from 'class-validator';

export class UserCategoryAppWiseDto {
  @IsNotEmpty()
  @ApiProperty()
  user_category_id: string;
  @ApiProperty()
  user_app_category_id: string;
  @ApiProperty()
  app_id: string;
  @ApiProperty({ default: false })
  is_custom_app: boolean;
}

export class userappAppUserRegistrationDataDto {
  @ApiProperty()
  user_category_id: string;
  @ApiProperty()
  additional_user_data_field_name: JSON;
}

export class UserCategoryAppWiseCommonDto {
  @ApiProperty()
  user_category_app_wise: UserCategoryAppWiseDto;
  @ApiProperty()
  userapp_app_user_registration_data: userappAppUserRegistrationDataDto;
}

export class common {
  @ApiProperty()
  data: JSON;
}
