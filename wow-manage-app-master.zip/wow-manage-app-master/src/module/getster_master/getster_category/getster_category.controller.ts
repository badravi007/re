/*
https://docs.nestjs.com/controllers#controllers
*/

import {
  Body,
  Controller,
  Get,
  HttpStatus,
  Post,
  Put,
  Query,
} from '@nestjs/common';
import { ApiTags } from '@nestjs/swagger';
import ResponseInterface from 'src/common/interface/response.interface';
import {
  GetsterCategoryDto,
  HideGetsterCategoryDto,
  UpdateGetsterCategoryDto,
} from '../dto/getster_category.dto';
import { AddUserCategoryWiseAppAccess } from '../dto/user-category-wiseApp-access.dto';
import { Getster_categoryService } from './getster_category.service';

// @UseGuards(JwtAuthGuard)
// @ApiBearerAuth('JWT-auth')
@ApiTags('GETster Category')
@Controller('getster_category')
export class Getster_categoryController {
  constructor(private _treeViewService: Getster_categoryService) {}

  @Get('get_all_getster_category')
  async GetAllCategories(): Promise<any> {
    try {
      const tasksData = await this._treeViewService.GetAllCategories();
      return {
        status: HttpStatus.OK,
        message: 'Fetched Successfully',
        data: tasksData,
      };
    } catch (error) {
      throw error;
    }
  }

  @Post('add_getster_category')
  async addCategory(
    @Body() category: GetsterCategoryDto,
  ): Promise<ResponseInterface> {
    try {
      await this._treeViewService.postCategory(category);
      return {
        message: 'Created Successfully',
        statusCode: 200,
      };
    } catch (error) {
      throw error;
    }
  }

  @Put('update_getster_category')
  async updateCategory(
    @Body() category: UpdateGetsterCategoryDto,
  ): Promise<any> {
    try {
      await this._treeViewService.updateCategory(category);
      return {
        status: 200,
        message: 'Updated Successfully',
      };
    } catch (error) {
      throw error;
    }
  }

  @Put('hide_getster_category')
  async hideCategory(@Body() category: HideGetsterCategoryDto): Promise<any> {
    try {
      await this._treeViewService.hideCategory(category);
      return {
        status: 200,
        message: 'Hide Successfully',
      };
    } catch (error) {
      throw error;
    }
  }

  @Get('check_getster_is_assigned_getster_category')
  async checkGetsterAssignedGetsterCategory(
    @Query('getster_category_id') getster_category_id: string,
  ) {
    let info = await this._treeViewService.checkGetsterAssignedGetsterCategory(
      getster_category_id,
    );

    if (info == true) {
      return {
        status: 200,
        message:
          'User is present in this category in-order to hide parent category / sub category kindly reassign the user to another category',
        userIsAssigned: true,
      };
    } else if (info == false) {
      return {
        status: 200,
        message: 'User is not present in this category',
        userIsAssigned: false,
      };
    }
  }

  @Post('add-user-category-wise-app-access')
  async onAddUserCategoryWiseAppAccess(
    @Body() _data: AddUserCategoryWiseAppAccess,
  ): Promise<ResponseInterface> {
    // console.log(_data);

    await this._treeViewService.onAddUserCategoryWiseAppAccess(_data);
    return {
      statusCode: HttpStatus.OK,
      message: `Insert Data Successful!`,
    };
  }

  @Get('get-user-category-wise-app-access')
  async onGetUserCategoryWiseAppAccess(
    @Query('getster_category_id') getster_category_id: string,
  ): Promise<ResponseInterface> {
    // console.log(_data);

    const data = await this._treeViewService.onGetUserCategoryWiseAppAccess(
      getster_category_id,
    );
    return {
      statusCode: HttpStatus.OK,
      message: `Get Data Successful!`,
      data,
    };
  }

  @Get('get-getster-category-wise-additional-fields')
  async onGetGetsterCategoryWiseAdditionalFields(
    @Query('getster_category_id') getster_category_id: string,
  ): Promise<ResponseInterface> {
    // console.log(_data);

    const data =
      await this._treeViewService.onGetGetsterCategoryWiseAdditionalFields(
        getster_category_id,
      );
    return {
      statusCode: HttpStatus.OK,
      message: `Get Data Successful!`,
      data,
    };
  }

  @Put('reassign-getster-category-id-to-another')
  async reassignUserCategoryIdToAnother(
    @Query('existing_getster_category_id') existing_getster_category_id: string,
    @Query('new_getster_category_id') new_getster_category_id: string,
  ): Promise<ResponseInterface> {
    await this._treeViewService.reassignUserCategoryIdToAnother(
      existing_getster_category_id,
      new_getster_category_id,
    );
    return {
      statusCode: HttpStatus.OK,
      message: `Category Reassign Successful!`,
    };
  }

  @Get('get-getster-getster-category-audit-trail')
  async onGetGetsterGetsterCategoryAuditTrail(): Promise<ResponseInterface> {
    // console.log(_data);

    const data =
      await this._treeViewService.onGetGetsterGetsterCategoryAuditTrail();
    return {
      statusCode: HttpStatus.OK,
      message: `Get Data Successful!`,
      data,
    };
  }
}
