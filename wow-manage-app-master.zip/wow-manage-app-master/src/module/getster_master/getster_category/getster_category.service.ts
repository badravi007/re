/*
https://docs.nestjs.com/providers#services
*/

import { Injectable } from '@nestjs/common';
import { InjectConnection, InjectRepository } from '@nestjs/typeorm';
import { DateTime } from 'luxon';
import * as mysql from 'mysql2';
import { IGetsterCategory } from 'src/models/interface/getster_category.interface';
import { Repository } from 'typeorm';
import { GetsterGetsterCategoryAuditTrailDto } from '../dto/getster_getster_category_audit_trail.dto';
import { AddUserCategoryWiseAppAccess } from '../dto/user-category-wiseApp-access.dto';
import { GetsterCategory } from '../entity/getster_category.entity';

@Injectable()
export class Getster_categoryService {
  constructor(
    @InjectRepository(
      GetsterCategory,
      'manage_getsters_of_get_wow_education_db',
    )
    @InjectConnection('manage_getsters_of_get_wow_education_db')
    private readonly getsterCategoryRepository: Repository<GetsterCategory>,
  ) {}

  async GetAllCategories() {
    try {
      const TaskData = await this.getsterCategoryRepository.query(
        `SELECT * FROM manage_getsters_of_get_wow_education_db.getster_category order by id`,
      );
      // console.log(TaskData);

      let data;
      if (TaskData.length > 1) {
        data = await this.treeConstruct(TaskData);
        // console.log(data, "tree");

        return data;
      }
      // console.log(data);

      // console.log(TaskData, "taskdata");

      const obj = TaskData[0];
      const pair = { children: [] };
      const objData = { ...obj, ...pair };
      if (obj !== undefined) {
        return [objData];
      }
      return [];
    } catch (error) {
      throw error;
    }
  }

  async postCategory(category_details: IGetsterCategory) {
    try {
      await this.getsterCategoryRepository.query(`
            INSERT INTO manage_getsters_of_get_wow_education_db.getster_category
             (getster_category_id,
              parent_getster_category_id,
              getster_category_name,
              is_the_getster_category_hidden,
              getster_category_type)
              VALUES (
              ${mysql.escape(category_details.getster_category_id)},
              ${mysql.escape(category_details.parent_getster_category_id)},
              ${mysql.escape(category_details.getster_category_name)},
              ${mysql.escape(category_details.is_the_getster_category_hidden)},
              ${mysql.escape(category_details.getster_category_type)}
              );
            `);
      this.getsterCategoryUpdateStatus();
      this.insertGetsterGetsterCategoryAuditTrail({
        entry_by_getster_id: '1',
        entry_by_getster_category_id: category_details.getster_category_id,
        entry_type: 'Insert Getster category',
      });
    } catch (error) {
      throw error;
    }
  }

  async updateCategory(category_details: IGetsterCategory) {
    try {
      if (category_details.getster_category_name) {
        await this.getsterCategoryRepository.query(`
        UPDATE manage_getsters_of_get_wow_education_db.getster_category
        SET getster_category_name = ${mysql.escape(
          category_details.getster_category_name,
        )} WHERE
        getster_category_id = '${category_details.getster_category_id}' `);
      }
      this.getsterCategoryUpdateStatus();
      this.insertGetsterGetsterCategoryAuditTrail({
        entry_by_getster_id: '1',
        entry_by_getster_category_id: category_details.getster_category_id,
        entry_type: 'Update Getster category',
      });
    } catch (error) {
      throw error;
    }
  }

  async hideCategory(category_details: IGetsterCategory) {
    try {
      if (category_details.is_the_getster_category_hidden) {
        await this.getsterCategoryRepository.query(`
          UPDATE manage_getsters_of_get_wow_education_db.getster_category
          SET is_the_getster_category_hidden = ${mysql.escape(
            category_details.is_the_getster_category_hidden,
          )} WHERE
          getster_category_id = '${category_details.getster_category_id}'
          `);
        this.getsterCategoryUpdateStatus();

        if (category_details.is_the_getster_category_hidden == true) {
          this.insertGetsterGetsterCategoryAuditTrail({
            entry_by_getster_id: '1',
            entry_by_getster_category_id: category_details.getster_category_id,
            entry_type: 'Hide Getster category',
          });
        } else {
          this.insertGetsterGetsterCategoryAuditTrail({
            entry_by_getster_id: '1',
            entry_by_getster_category_id: category_details.getster_category_id,
            entry_type: 'Unhide Getster category',
          });
        }
      }
    } catch (error) {
      throw error;
    }
  }

  async checkGetsterAssignedGetsterCategory(getster_category_id: string) {
    let data: any[] = await this.getsterCategoryRepository.query(
      `
        SELECT * FROM manage_getsters_of_get_wow_education_db.getster_category_wise_app_access
        WHERE getster_category_id='${getster_category_id}'
      `,
    );
    if (data.length == 0) return false;
    else return true;
  }

  async onAddUserCategoryWiseAppAccess(
    _data: AddUserCategoryWiseAppAccess,
  ): Promise<any> {
    try {
      const {
        additional_getster_data_field_name,
        getster_category_id,
        selected_getster_apps,
        is_location_of_getster_required,
      } = _data;

      await this.getsterCategoryRepository.query(
        `
        DELETE FROM manage_getsters_of_get_wow_education_db.getster_category_wise_app_access
        WHERE getster_category_id='${getster_category_id}'
        `,
      );

      for (let i = 0; i < selected_getster_apps.length; i++) {
        const element = selected_getster_apps[i];
        // console.log('file: getster_category.service.ts:170 ~ element', element);

        let getUserAppCategoryIds: any[] =
          await this.getsterCategoryRepository.query(
            `
          SELECT * FROM manage_getsters_of_get_wow_education_db.getster_category_wise_app_access
          WHERE
          getster_category_id='${getster_category_id}' AND
          getster_app_category_id='${element.getster_app_category_id}' AND
          getster_app_id=${element.getster_app_id}
            `,
          );

        if (getUserAppCategoryIds.length == 0) {
          await this.getsterCategoryRepository.query(`
          INSERT INTO manage_getsters_of_get_wow_education_db.getster_category_wise_app_access
            (getster_category_id,
            getster_app_category_id,
            getster_app_id)
            VALUES
            (${mysql.escape(getster_category_id)},
            ${mysql.escape(element.getster_app_category_id)},
            ${mysql.escape(element.getster_app_id)});
          `);
        }
      }

      const isAlreadyFoundAdditionalData =
        await this.getsterCategoryRepository.query(
          `
        SELECT * FROM manage_getsters_of_get_wow_education_db.getster_category_wise_additional_field_names
        WHERE getster_category_id='${getster_category_id}';
      `,
        );

      if (isAlreadyFoundAdditionalData.length == 0) {
        await this.getsterCategoryRepository.query(`
          INSERT INTO manage_getsters_of_get_wow_education_db.getster_category_wise_additional_field_names
            (
            getster_category_id,
            additional_getster_data_field_name,
            is_location_of_getster_required)
            VALUES
            (${mysql.escape(getster_category_id)},
            ${mysql.escape(JSON.stringify(additional_getster_data_field_name))},
            ${mysql.escape(is_location_of_getster_required)});
        `);
        this.insertGetsterGetsterCategoryAuditTrail({
          entry_by_getster_id: '1',
          entry_by_getster_category_id: getster_category_id,
          entry_type: 'Insert App to Getster category',
        });
      } else {
        await this.getsterCategoryRepository.query(`
        UPDATE manage_getsters_of_get_wow_education_db.getster_category_wise_additional_field_names
          SET
          additional_getster_data_field_name = ${mysql.escape(
            JSON.stringify(
              additional_getster_data_field_name ??
                isAlreadyFoundAdditionalData[0]
                  .additional_getster_data_field_name,
            ),
          )},
          is_location_of_getster_required = ${mysql.escape(
            is_location_of_getster_required ??
              isAlreadyFoundAdditionalData[0].is_location_of_getster_required,
          )}
          WHERE getster_category_id = '${getster_category_id}';
        `);

        this.insertGetsterGetsterCategoryAuditTrail({
          entry_by_getster_id: '1',
          entry_by_getster_category_id: getster_category_id,
          entry_type: 'Update App to Getster category',
        });
      }

      const TimeZoneIanaString = 'Asia/Kolkata';
      const entry_date_time: any = DateTime.local({
        zone: TimeZoneIanaString,
      }).toFormat('yyyy-MM-dd TT');

      this.getsterCategoryUpdateStatus();

      // const audit_trail_data = {
      //   country_code: country_code,
      //   customer_id: customer_id,
      //   entry_by_user_id: user_id,
      //   entry_type: 'INSERT',
      //   entry_date_time: entry_date_time,
      //   entry_by_user_category_id: user_category_id,
      // };
      // await this._userCategoryAuditTrail.onPostUserCategoryAuditTrail(
      //   audit_trail_data,
      // );
    } catch (error) {
      throw error;
    }
  }

  async getsterCategoryUpdateStatus() {
    const TimeZoneIanaString = 'Asia/Kolkata';
    const entry_date_time: any = DateTime.local({
      zone: TimeZoneIanaString,
    }).toFormat('yyyy-MM-dd TT');

    let isFound = await this.getsterCategoryRepository.query(`
      SELECT * FROM manage_getsters_of_get_wow_education_db.getster_category_update_status
      WHERE getster_category_update_utc_datetime
    `);

    if (isFound.length == 0) {
      await this.getsterCategoryRepository.query(`
          INSERT INTO manage_getsters_of_get_wow_education_db.getster_category_update_status
          (getster_category_update_utc_datetime)
          VALUES
          (${mysql.escape(entry_date_time)});
      `);
    } else {
      await this.getsterCategoryRepository.query(`
        UPDATE manage_getsters_of_get_wow_education_db.getster_category_update_status
        SET
        getster_category_update_utc_datetime = ${mysql.escape(entry_date_time)}

        WHERE getster_category_update_utc_datetime = '${
          isFound[0].getster_category_update_utc_datetime
        }';

      `);
    }
  }

  async reassignUserCategoryIdToAnother(
    existing_getster_category_id: string,
    new_getster_category_id: string,
  ) {
    try {
      const getExistingGetsterWiseCategories = await this
        .getsterCategoryRepository.query(`
            SELECT * FROM manage_getsters_of_get_wow_education_db.getster_category_wise_app_access
            where getster_category_id='${existing_getster_category_id}'
        `);

      for (let i = 0; i < getExistingGetsterWiseCategories.length; i++) {
        const element = getExistingGetsterWiseCategories[i];

        const getNewGetsterWiseCategories: any[] = await this
          .getsterCategoryRepository.query(`
            SELECT * FROM manage_getsters_of_get_wow_education_db.getster_category_wise_app_access
            where getster_category_id='${new_getster_category_id}' AND getster_app_category_id='${element.getster_app_category_id}' AND getster_app_id='${element.getster_app_id}'
      `);

        if (getNewGetsterWiseCategories.length == 0) {
          await this.getsterCategoryRepository.query(`
            UPDATE manage_getsters_of_get_wow_education_db.getster_category_wise_app_access
            SET
            getster_category_id = '${new_getster_category_id}'
            WHERE getster_category_id = '${existing_getster_category_id}' AND getster_app_category_id='${element.getster_app_category_id}' AND getster_app_id='${element.getster_app_id}';
          `);
        } else {
          await this.getsterCategoryRepository.query(`
            DELETE FROM manage_getsters_of_get_wow_education_db.getster_category_wise_app_access
            WHERE getster_category_id='${existing_getster_category_id}' AND getster_app_category_id='${element.getster_app_category_id}' AND getster_app_id='${element.getster_app_id}';
          `);
        }
      }
      // this.insertGetsterGetsterCategoryAuditTrail({
      //   entry_by_getster_id: '1',
      //   entry_by_getster_category_id: existing_getster_category_id,
      //   entry_type: ' App to Getster category',
      // });

      // await this.getsterCategoryRepository.query(`
      //   UPDATE manage_getsters_of_get_wow_education_db.getster_category_wise_additional_field_names
      //   SET
      //   getster_category_id = '${new_getster_category_id}'
      //   WHERE getster_category_id = '${existing_getster_category_id}';
      // `);
    } catch (error) {
      throw error;
    }
  }

  async onGetUserCategoryWiseAppAccess(
    getster_category_id: string,
  ): Promise<any> {
    try {
      let getGetsterAppCategory: any[] =
        await this.getsterCategoryRepository.query(
          `
          SELECT getster_app_category_id,getster_app_id FROM manage_getsters_of_get_wow_education_db.getster_category_wise_app_access
          WHERE
          getster_category_id='${getster_category_id}'
        `,
        );

      return getGetsterAppCategory;
    } catch (error) {
      throw error;
    }
  }

  async onGetGetsterCategoryWiseAdditionalFields(
    getster_category_idd: string,
  ): Promise<any> {
    try {
      const getster_category_id = getster_category_idd.split(',');

      const data: any[] = [];
      for (let i = 0; i < getster_category_id.length; i++) {
        const element = getster_category_id[i];
        let d = await this.getsterCategoryRepository.query(
          `
          SELECT a.additional_getster_data_field_name,a.is_location_of_getster_required,b.getster_category_name FROM manage_getsters_of_get_wow_education_db.getster_category_wise_additional_field_names a
          left join manage_getsters_of_get_wow_education_db.getster_category b on a.getster_category_id=b.getster_category_id
          WHERE a.getster_category_id='${element}';
        `,
        );
        data.push(...d);
      }

      return data;
    } catch (error) {
      throw error;
    }
  }
  async onGetGetsterGetsterCategoryAuditTrail(): Promise<any> {
    try {
      const data = await this.getsterCategoryRepository.query(
        `
        SELECT a.*,b.getster_category_name FROM manage_getsters_of_get_wow_education_db.getster_getster_category_audit_trail a
        left join  manage_getsters_of_get_wow_education_db.getster_category b on a.entry_by_getster_category_id=b.getster_category_id
        ORDER BY id DESC;
      `,
      );

      return data;
    } catch (error) {
      throw error;
    }
  }

  async insertGetsterGetsterCategoryAuditTrail(
    _data: GetsterGetsterCategoryAuditTrailDto,
  ) {
    try {
      const { entry_by_getster_category_id, entry_by_getster_id, entry_type } =
        _data;

      const TimeZoneIanaString = 'Asia/Kolkata';

      const entry_date_time: any = DateTime.local({
        zone: TimeZoneIanaString,
      }).toFormat('yyyy-MM-dd TT');

      await this.getsterCategoryRepository.query(`
        INSERT INTO manage_getsters_of_get_wow_education_db.getster_getster_category_audit_trail
        (entry_by_getster_id,
        entry_type,
        entry_date_time,
        entry_by_getster_category_id)
        VALUES
        (${mysql.escape(entry_by_getster_id)},
        ${mysql.escape(entry_type)},
        ${mysql.escape(entry_date_time)},
        ${mysql.escape(entry_by_getster_category_id)});
      `);
    } catch (error) {
      throw error;
    }
  }
  //----------- Helper Function ---------------------
  treeConstruct(treeData) {
    let constructedTree = [];
    for (let i of treeData) {
      let treeObj = i;
      let assigned = false;
      this.constructTree(constructedTree, treeObj, assigned);
    }
    return constructedTree;
  }

  constructTree(constructedTree, treeObj, assigned) {
    if (treeObj.parent_getster_category_id == null) {
      treeObj.children = [];
      constructedTree.push(treeObj);
      return true;
    } else if (
      treeObj.parent_getster_category_id === constructedTree.getster_category_id
    ) {
      treeObj.children = [];
      constructedTree.children.push(treeObj);
      return true;
    } else {
      if (constructedTree.children != undefined) {
        for (let index = 0; index < constructedTree.children.length; index++) {
          let constructedObj = constructedTree.children[index];
          if (assigned == false) {
            assigned = this.constructTree(constructedObj, treeObj, assigned);
          }
        }
      } else {
        for (let index = 0; index < constructedTree.length; index++) {
          let constructedObj = constructedTree[index];
          if (assigned == false) {
            assigned = this.constructTree(constructedObj, treeObj, assigned);
          }
        }
      }
      return false;
    }
  }
}
