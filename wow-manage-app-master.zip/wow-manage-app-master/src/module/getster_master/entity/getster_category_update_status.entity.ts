import { Entity, PrimaryColumn } from 'typeorm';

@Entity({
  database: 'manage_getsters_of_get_wow_education_db',
  name: 'getster_category_update_status',
})
export class GetsterCategoryUpdateStatus {
  @PrimaryColumn()
  getster_category_update_utc_datetime: string;
}
