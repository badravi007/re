import { Column, Entity, PrimaryGeneratedColumn } from 'typeorm';

@Entity({
  database: 'manage_getsters_of_get_wow_education_db',
  name: 'getster_getster_category_audit_trail',
})
export class GetsterGetsterCategoryAuditTrail {
  @PrimaryGeneratedColumn('increment')
  id: number;
  @Column({
    type: 'varchar',
    length: 45,
    nullable: true,
  })
  entry_by_getster_id: string;
  @Column({
    type: 'varchar',
    length: 45,
    nullable: true,
  })
  entry_type: string;
  @Column({
    type: 'datetime',
    nullable: true,
  })
  entry_date_time: string;
  @Column({
    type: 'varchar',
    length: 45,
    nullable: true,
  })
  entry_by_getster_category_id: string;
}
