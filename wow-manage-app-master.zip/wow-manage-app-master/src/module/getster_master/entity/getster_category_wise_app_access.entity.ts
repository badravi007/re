import { Column, Entity, PrimaryGeneratedColumn } from 'typeorm';

@Entity({
  database: 'manage_getsters_of_get_wow_education_db',
  name: 'getster_category_wise_app_access',
})
export class GetsterCategoryWiseAppAccess {
  @PrimaryGeneratedColumn('increment')
  id: number;

  @Column()
  getster_category_id: number;

  @Column()
  getster_app_category_id: number;

  @Column()
  getster_app_id: number;
}
