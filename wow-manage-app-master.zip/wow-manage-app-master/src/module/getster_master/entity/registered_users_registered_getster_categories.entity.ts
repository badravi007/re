import { Column, Entity, PrimaryGeneratedColumn } from 'typeorm';

@Entity({
  database: 'manage_getsters_of_get_wow_education_db',
  name: 'registered_users_registered_getster_categories',
})
export class RegisteredUsersRegisteredGetsterCategories {
  @PrimaryGeneratedColumn('increment')
  id: number;

  @Column({
    type: 'int',
  })
  getster_id: number;

  @Column({
    type: 'varchar',
    length: 100,
    nullable: true,
  })
  getster_category_id: string;
}
