import { Column, Entity, PrimaryGeneratedColumn } from 'typeorm';

@Entity({
  database: 'manage_getsters_of_get_wow_education_db',
  name: 'getster_profile',
})
export class GetsterProfile {
  @PrimaryGeneratedColumn('increment')
  getster_id: number;
  @Column({
    type: 'varchar',
    length: 3,
    nullable: true,
  })
  registered_mobile_country_code: string;
  @Column({
    type: 'varchar',
    length: 15,
    unique: true,
  })
  registered_mobile_number: number;
  @Column({
    type: 'tinyint',
    nullable: true,
  })
  getster_registration_login_approval_status: boolean;
  @Column({
    type: 'varchar',
    length: 50,
    nullable: true,
  })
  first_name: string;
  @Column({
    type: 'varchar',
    length: 50,
    nullable: true,
  })
  last_name: string;
  @Column({
    type: 'datetime',
    nullable: true,
  })
  date_of_birth: Date;
  @Column({
    type: 'varchar',
    length: 20,
    nullable: true,
  })
  getster_blood_group: string;
  @Column({
    type: 'tinyint',
    nullable: true,
  })
  gender: boolean;
  @Column({
    type: 'json',
    nullable: true,
  })
  additional_getster_data_field_values: object;
  @Column({
    type: 'varchar',
    length: 15,
    nullable: true,
  })
  emergency_mobile_no: string;
  @Column({
    type: 'varchar',
    length: 1000,
    nullable: true,
  })
  about_user: string;
  @Column({
    type: 'json',
    nullable: true,
  })
  biz_card_company_details: object;
  @Column({
    type: 'int',
    nullable: true,
  })
  biz_card_mobile_no: number;
  @Column({
    type: 'int',
    nullable: true,
  })
  biz_card_phone_no: number;
  @Column({
    type: 'varchar',
    length: 70,
    nullable: true,
  })
  biz_card_website: string;
  @Column({
    type: 'varchar',
    length: 100,
    nullable: true,
  })
  biz_card_email_id: string;
  @Column({
    type: 'varchar',
    length: 400,
    nullable: true,
  })
  biz_card_address: string;
  @Column({
    type: 'varchar',
    length: 100,
    nullable: true,
  })
  biz_card_address_gps: string;
  @Column({
    type: 'datetime',
    nullable: true,
  })
  first_login_image_of_the_day_update_datetime: Date;
}
