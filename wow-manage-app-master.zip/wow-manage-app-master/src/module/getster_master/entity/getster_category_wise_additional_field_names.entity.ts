import { Column, Entity, PrimaryGeneratedColumn } from 'typeorm';

@Entity({
  database: 'manage_getsters_of_get_wow_education_db',
  name: 'getster_category_wise_additional_field_names',
})
export class GetsterCategoryWiseAdditionalFieldNames {
  @PrimaryGeneratedColumn('increment')
  id: number;

  @Column({
    length: 100,
  })
  getster_category_id: string;

  @Column({
    type: 'json',
  })
  additional_getster_data_field_name: string;

  @Column()
  is_location_of_getster_required: boolean;
}
