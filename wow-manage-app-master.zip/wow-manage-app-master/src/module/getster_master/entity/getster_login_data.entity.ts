import { Column, Entity, PrimaryGeneratedColumn } from 'typeorm';

@Entity({
  database: 'manage_getsters_of_get_wow_education_db',
  name: 'getster_login_data',
})
export class GetsterLogin {
  @PrimaryGeneratedColumn('increment')
  getster_id: number;

  @Column({
    type: 'varchar',
    length: 3,
    nullable: true,
  })
  registered_mobile_country_code: string;

  @Column({
    type: 'varchar',
    length: 15,
    unique: true,
  })
  registered_mobile_no: number;

  @Column({
    type: 'varchar',
    length: 100,
    nullable: true,
  })
  getster_password: string;

  @Column({
    type: 'int',
    nullable: true,
  })
  getster_registration_login_approval_status: number;

  @Column({
    type: 'datetime',
    nullable: true,
  })
  login_token_foreceful_invalidation_datetime: Date;

  @Column({
    type: 'varchar',
    length: 5,
    nullable: true,
  })
  getster_language_default: string;

  @Column({
    type: 'datetime',
    nullable: true,
  })
  registration_datetime: Date;

  @Column({
    type: 'int',
    nullable: true,
  })
  number_of_failed_attempts_for_the_day: number;

  @Column({
    type: 'datetime',
    nullable: true,
  })
  login_block_datetime: Date;
}
