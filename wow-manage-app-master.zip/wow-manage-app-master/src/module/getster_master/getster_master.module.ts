/*
https://docs.nestjs.com/modules
*/

import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { AuthModule } from 'src/auth/auth.module';
import { GetsterCategory } from '../getster_masters/entity/getster_category.entity';
import { GetsterCategoryWiseAppAccess } from '../getster_masters/entity/getster_category_wise_app_access.entity';
import { GetsterCategoryUpdateStatus } from './entity/getster_category_update_status.entity';
import { GetsterCategoryWiseAdditionalFieldNames } from './entity/getster_category_wise_additional_field_names.entity';
import { GetsterGetsterCategoryAuditTrail } from './entity/getster_getster_category_audit_trail.entity';
import { GetsterLogin } from './entity/getster_login_data.entity';
import { GetsterProfile } from './entity/getster_profile.entity';
import { RegisteredUsersRegisteredGetsterCategories } from './entity/registered_users_registered_getster_categories.entity';
import { Getster_categoryController } from './getster_category/getster_category.controller';
import { Getster_categoryService } from './getster_category/getster_category.service';

@Module({
  imports: [
    TypeOrmModule.forFeature(
      [
        GetsterCategoryUpdateStatus,
        GetsterCategoryWiseAdditionalFieldNames,
        GetsterCategoryWiseAppAccess,
        GetsterCategory,
        GetsterGetsterCategoryAuditTrail,
        GetsterProfile,
        GetsterLogin,
        RegisteredUsersRegisteredGetsterCategories,
      ],
      'manage_getsters_of_get_wow_education_db',
    ),
    AuthModule,
  ],
  controllers: [Getster_categoryController],
  providers: [Getster_categoryService],
  exports: [],
})
export class GetsterMasterModule {}
