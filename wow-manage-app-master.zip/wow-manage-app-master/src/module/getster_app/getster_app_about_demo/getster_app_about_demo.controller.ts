/*
https://docs.nestjs.com/controllers#controllers
*/

import {
  Body,
  Controller,
  Get,
  Post,
  Put,
  Query,
  UseGuards,
} from '@nestjs/common';
import { ApiBearerAuth, ApiTags } from '@nestjs/swagger';
import { JwtAuthGuard } from 'src/auth/guard/jwt-auth.guard';
import ResponseInterface from 'src/common/interface/response.interface';
import { GetsterAppAboutDemoDto } from '../dto/getster_app_about_demo.dto';
import { Getster_app_about_demoService } from './getster_app_about_demo.service';

// @UseGuards(JwtAuthGuard)
// @ApiBearerAuth('JWT-auth')
@ApiTags('Getster App About Demo')
@Controller('getster_app_about_demo_video_description')
export class Getster_app_about_demoController {
  constructor(
    private readonly getster_app_about_demoService: Getster_app_about_demoService,
  ) {}

  @Post('/add_getster_app_about_demo_video_description')
  async createGetsterAppAboutDemo(
    @Body() getsterAppAboutDemoDto: GetsterAppAboutDemoDto,
  ): Promise<ResponseInterface> {
    const alreadyExists =
      await this.getster_app_about_demoService.checkGetsterAppAboutDemoExist(
        getsterAppAboutDemoDto.getster_app_id,
      );
    if (alreadyExists) {
      const result =
        await this.getster_app_about_demoService.updateGetsterAppAboutDemo(
          getsterAppAboutDemoDto,
        );
      return {
        statusCode: 200,
        message: `Updated Getster App About Demo Video Successfully!`,
        data: result,
      };
    } else {
      const result =
        await this.getster_app_about_demoService.createGetsterAppAboutDemo(
          getsterAppAboutDemoDto,
        );
      return {
        statusCode: 200,
        message: `Getster App About Demo Created Successfully!`,
        data: result,
      };
    }
  }

  @Get('/get_getster_app_about_demo_video_description')
  async getGetsterAppAboutDemo(
    @Query('getster_app_id') getster_app_id: number,
  ): Promise<any> {
    let result =
      await this.getster_app_about_demoService.getGetsterAppAboutDemo(
        getster_app_id,
      );

    return {
      statusCode: 200,
      message: `Get Getster App About Demo Video Successfully!`,
      data: result,
    };
  }

  @Put('/update_getster_app_about_demo_video_description')
  async updateGetsterAppAboutDemo(
    @Body() getsterAppAboutDemoDto: GetsterAppAboutDemoDto,
  ): Promise<ResponseInterface> {
    const result =
      await this.getster_app_about_demoService.updateGetsterAppAboutDemo(
        getsterAppAboutDemoDto,
      );
    return {
      statusCode: 200,
      message: `Updated Getster App About Demo Video Successfully!`,
      data: result,
    };
  }
}
