/*
https://docs.nestjs.com/providers#services
*/

import { Injectable } from '@nestjs/common';
import { InjectConnection, InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { GetsterAppAboutDemoDto } from '../dto/getster_app_about_demo.dto';
import { GetsterAppAboutDemo } from '../entity/getster_app_about_demo.entity';

@Injectable()
export class Getster_app_about_demoService {
  constructor(
    @InjectRepository(GetsterAppAboutDemo, 'wow_getster_app_db')
    @InjectConnection('wow_getster_app_db')
    private readonly getsterAppAboutDemoRepository: Repository<GetsterAppAboutDemo>,
  ) {}

  async createGetsterAppAboutDemo(
    getsterAppAboutDemoDto: GetsterAppAboutDemoDto,
  ): Promise<GetsterAppAboutDemoDto> {
    try {
      return await this.getsterAppAboutDemoRepository.save(
        getsterAppAboutDemoDto,
      );
    } catch (err) {
      throw err;
    }
  }

  async updateGetsterAppAboutDemo(
    getsterAppAboutDemoDto: GetsterAppAboutDemoDto,
  ): Promise<GetsterAppAboutDemoDto> {
    try {
      await this.getsterAppAboutDemoRepository.update(
        getsterAppAboutDemoDto.getster_app_id,
        getsterAppAboutDemoDto,
      );
      return this.getsterAppAboutDemoRepository.findOne({
        where: { getster_app_id: getsterAppAboutDemoDto.getster_app_id },
      });
    } catch (err) {
      throw err;
    }
  }
  async getGetsterAppAboutDemo(
    getster_app_id: number,
  ): Promise<GetsterAppAboutDemoDto> {
    try {
      return await this.getsterAppAboutDemoRepository.findOne({
        where: { getster_app_id: getster_app_id },
      });
    } catch (err) {
      throw err;
    }
  }

  async checkGetsterAppAboutDemoExist(
    getster_app_id: number,
  ): Promise<boolean> {
    try {
      const user = await this.getsterAppAboutDemoRepository.findOne({
        where: { getster_app_id: getster_app_id },
      });
      return user ? true : false;
    } catch (err) {
      throw err;
    }
  }
}
