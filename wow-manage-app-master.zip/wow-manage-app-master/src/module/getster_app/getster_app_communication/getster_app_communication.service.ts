/*
https://docs.nestjs.com/providers#services
*/

import { Injectable } from '@nestjs/common';
import { InjectConnection } from '@nestjs/typeorm';
import { DateTimeService } from 'src/shared/service/date-time.service';
import { Repository } from 'typeorm';
import { GetsterAppCommunicationDto } from '../dto/getster_app_communication.dto';

@Injectable()
export class Getster_app_communicationService {
  constructor(
    @InjectConnection('wow_getster_app_db')
    private readonly getsterAppCommunicationRepository: Repository<null>,
    private _dateTimeService: DateTimeService,
  ) {}

  async insertGetsterAppCommunication(
    getster_app_id: number,
    timeZoneIanaString: string,
    userAppCommunication: GetsterAppCommunicationDto,
  ): Promise<any> {
    return await this.getsterAppCommunicationRepository.query(
      `insert into ${getster_app_id}_getster_app_communication values(
        0,'${this._dateTimeService.getDateTime(timeZoneIanaString)}', 
        ${userAppCommunication.getster_id}, 
        '${userAppCommunication.communication_text}'
        );`,
    );
  }

  async updateGetsterAppCommunication(
    getster_app_id: number,
    communication_id: number,
    getsterAppCommunication: GetsterAppCommunicationDto,
  ): Promise<any> {
    return await this.getsterAppCommunicationRepository.query(
      `update into ${getster_app_id}_getster_app_communication set communication_text ='${getsterAppCommunication.communication_text}' where  communication_id=${communication_id};`,
    );
  }

  async deleteGetsterAppCommunication(
    getster_app_id: number,
    communication_id: number,
  ): Promise<any> {
    return await this.getsterAppCommunicationRepository.query(
      `delete from ${getster_app_id}_getster_app_communication where  communication_id = ${communication_id}`,
    );
  }

  async getGetsterAppCommunication(getster_app_id: number): Promise<any> {
    try {
      return this.getsterAppCommunicationRepository.query(
        `select * from ${getster_app_id}_getster_app_communication;`,
      );
    } catch (err) {
      throw err;
    }
  }
}
