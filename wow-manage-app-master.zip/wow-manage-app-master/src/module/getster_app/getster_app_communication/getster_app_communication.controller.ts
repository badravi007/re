/*
https://docs.nestjs.com/controllers#controllers
*/

import {
  Body,
  Controller,
  Delete,
  Get,
  HttpStatus,
  Post,
  Put,
  Query,
  UseGuards,
} from '@nestjs/common';
import { ApiBearerAuth, ApiTags } from '@nestjs/swagger';
import { JwtAuthGuard } from 'src/auth/guard/jwt-auth.guard';
import ResponseInterface from 'src/common/interface/response.interface';
import { GetsterAppCommunicationDto } from '../dto/getster_app_communication.dto';
import { Getster_app_communicationService } from './getster_app_communication.service';

// @UseGuards(JwtAuthGuard)
// @ApiBearerAuth('JWT-auth')
@ApiTags('Getster App Communication')
@Controller('getster_app_communication')
export class Getster_app_communicationController {
  constructor(
    private readonly getster_app_communicationService: Getster_app_communicationService,
  ) {}

  @Post('/add_getster_app_communication?')
  async insertGetsterAppCommunication(
    @Query('getster_app_id') getster_app_id: number,
    @Query('timeZoneIanaString') timeZoneIanaString: string,
    @Body() getsterAppCommunicationDto: GetsterAppCommunicationDto,
  ): Promise<ResponseInterface> {
    const result =
      await this.getster_app_communicationService.insertGetsterAppCommunication(
        getster_app_id,
        timeZoneIanaString,
        getsterAppCommunicationDto,
      );
    return {
      statusCode: HttpStatus.CREATED,
      message: 'Sent successful!!',
      data: result,
    };
  }

  @Put('/update_getster_app_communication?')
  async updateGetsterAppCommunication(
    @Query('getster_app_id') getster_app_id: number,
    @Query('communication_id') communication_id: number,
    @Body() getsterAppCommunicationDto: GetsterAppCommunicationDto,
  ): Promise<ResponseInterface> {
    const result =
      await this.getster_app_communicationService.updateGetsterAppCommunication(
        getster_app_id,
        communication_id,
        getsterAppCommunicationDto,
      );
    return {
      statusCode: HttpStatus.CREATED,
      message: 'Updated successful !!',
      data: result,
    };
  }

  @Delete('/delete_getster_app_communication?')
  async deleteGetsterAppCommunication(
    @Query('getster_app_id') getster_app_id: number,
    @Query('communication_id') communication_id: number,
  ): Promise<ResponseInterface> {
    const result =
      await this.getster_app_communicationService.deleteGetsterAppCommunication(
        getster_app_id,
        communication_id,
      );
    return {
      statusCode: HttpStatus.CREATED,
      message: 'Deleted successful !!',
      data: result,
    };
  }
  @Get('/get_getster_app_communication?')
  async getGetsterAppCommunication(
    @Query('getster_app_id') getster_app_id: number,
  ): Promise<ResponseInterface> {
    const result =
      await this.getster_app_communicationService.getGetsterAppCommunication(
        getster_app_id,
      );
    return {
      statusCode: HttpStatus.CREATED,
      message: 'Get Communication successfully!!',
      data: result,
    };
  }
}
