import { ApiProperty } from '@nestjs/swagger';

export class GetsterAppCommunicationDto {
  @ApiProperty()
  communication_id: number;

  @ApiProperty()
  communication_utc_date_time: string;

  @ApiProperty()
  getster_id: number;

  @ApiProperty()
  communication_text: string;
}
