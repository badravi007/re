import { ApiProperty } from '@nestjs/swagger';

export class GetsterAppsCategoryAssignmentDto {
  @ApiProperty()
  getster_app_category_id: string;

  @ApiProperty()
  getster_app_id: number;

  @ApiProperty()
  getster_app_location_within_the_category_id: string;
}
