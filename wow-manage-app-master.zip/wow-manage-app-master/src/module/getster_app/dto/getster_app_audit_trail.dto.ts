import { ApiProperty } from '@nestjs/swagger';

export class GetsterAppAuditTrailDto {
  @ApiProperty()
  getster_app_id: number;

  @ApiProperty()
  entry_type: string;

  @ApiProperty()
  entry_by_user_id: number;

  @ApiProperty()
  entry_local_date_time: string;
}
