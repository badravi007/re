import { ApiProperty } from '@nestjs/swagger';

export class GetsterAppReassignCategoryDto {
  @ApiProperty()
  getster_app_id: string;

  @ApiProperty()
  getster_app_icon_name: string;

  @ApiProperty()
  getster_app_icon_image: string;

  @ApiProperty()
  getster_app_name: string;

  @ApiProperty()
  getster_app_development_status: boolean;

  @ApiProperty()
  getster_app_title_bar_name: string;

  @ApiProperty()
  getster_app_category_id: string;

  @ApiProperty()
  id: number;

  @ApiProperty()
  getster_app_location_within_the_category_id: string;

  @ApiProperty()
  CategoryName: string;

  @ApiProperty()
  getster_app_category_name: string;

  @ApiProperty()
  getster_app_category_path: string;
}
