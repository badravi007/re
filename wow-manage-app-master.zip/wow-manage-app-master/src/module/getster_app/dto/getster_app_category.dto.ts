import { ApiProperty } from '@nestjs/swagger';

export class GetsterAppCategoryDto {
  @ApiProperty()
  getster_app_category_id: string;

  @ApiProperty()
  parent_getster_app_category_id: string | null;

  @ApiProperty()
  getster_app_category_name: string;

  @ApiProperty()
  is_the_getster_app_category_hidden: boolean;

  @ApiProperty()
  children: any;

  @ApiProperty()
  getster_app_category_type: number;
  @ApiProperty()
  time_zone_iana_string: string;
}
