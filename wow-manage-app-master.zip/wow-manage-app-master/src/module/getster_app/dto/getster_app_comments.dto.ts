import { ApiProperty } from '@nestjs/swagger';
import { Column, PrimaryColumn } from 'typeorm';

export class GetsterAppCommentsDto {
  @ApiProperty()
  getster_id: number;

  @ApiProperty()
  comment_text: string;

  @ApiProperty()
  is_the_comment_private: boolean;

  @ApiProperty()
  comment_reply: string;

  @ApiProperty()
  comment_reply_by_getster_id: number;
}

export class GetsterAppCommentsType {
  @ApiProperty()
  is_the_comment_private: boolean;

  @ApiProperty()
  comment_reply: string;

  @ApiProperty()
  comment_reply_by_getster_id: string;
}
