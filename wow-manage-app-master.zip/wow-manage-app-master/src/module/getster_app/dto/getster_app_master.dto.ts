import { ApiProperty } from '@nestjs/swagger';

export class GetsterAppMasterDto {
  @ApiProperty()
  getster_app_id: number;

  @ApiProperty()
  getster_app_icon_name: string;

  @ApiProperty()
  getster_app_icon_image: string;

  @ApiProperty()
  getster_app_name: string;

  @ApiProperty()
  getster_app_development_status: boolean;
}

export class UpdateGetsterAppMasterDto {
  @ApiProperty()
  getster_app_id: number;

  @ApiProperty()
  getster_app_icon_name: string;

  @ApiProperty()
  getster_app_full_name: string;

  @ApiProperty()
  getster_app_icon_image: string;

  @ApiProperty()
  getster_app_development_status: boolean;

  @ApiProperty()
  getster_id: number;

  @ApiProperty()
  time_zone_iana_string: string;
}

export class UpdateGetsterAppDevelopmentStatusDto {
  @ApiProperty()
  getster_app_id: number;

  @ApiProperty()
  getster_app_development_status: boolean;
  @ApiProperty()
  time_zone_iana_string: string;
}
