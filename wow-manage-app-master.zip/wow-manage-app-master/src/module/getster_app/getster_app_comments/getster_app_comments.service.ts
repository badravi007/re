/*
https://docs.nestjs.com/providers#services
*/

import { Injectable } from '@nestjs/common';
import { InjectConnection } from '@nestjs/typeorm';
import { DateTimeService } from 'src/shared/service/date-time.service';
import { Repository } from 'typeorm';
import {
  GetsterAppCommentsDto,
  GetsterAppCommentsType,
} from '../dto/getster_app_comments.dto';

@Injectable()
export class Getster_app_commentsService {
  constructor(
    @InjectConnection('wow_getster_app_db')
    private readonly getsterAppCommentsRepository: Repository<null>,
    private _dateTimeService: DateTimeService,
  ) {}

  async creatDynamicTable(getster_app_id: number): Promise<any> {
    await this.getsterAppCommentsRepository.query(
      `create table ${getster_app_id}_getster_app_comments (comment_id int not null auto_increment, comment_utc_date_time datetime not null,
      getster_id  int not null,comment_text varchar(100) not null,is_the_comment_private int null ,comment_reply varchar(100) null,
      comment_reply_by_getster_id int null,primary key(comment_id));`,
    );

    await this.getsterAppCommentsRepository.query(
      `create table ${getster_app_id}_getster_app_communication (communication_id int not null auto_increment, communication_utc_date_time varchar(30) not null,
      getster_id  int not null,	communication_text varchar(100) not null,primary key(communication_id));`,
    );

    return 'Success';
  }

  async insertGetsterAppComments(
    getster_app_id: number,
    timeZoneIanaString: string,
    getsterAppComments: GetsterAppCommentsDto,
  ): Promise<any> {
    return await this.getsterAppCommentsRepository.query(
      `insert into ${getster_app_id}_getster_app_comments values(
        0,'${this._dateTimeService.getDateTime(timeZoneIanaString)}', 
        ${getsterAppComments.getster_id}, 
        '${getsterAppComments.comment_text}',
        ${getsterAppComments.is_the_comment_private},
        ${getsterAppComments.comment_reply},
        ${getsterAppComments.comment_reply_by_getster_id}
        )`,
    );
  }

  async updateGetsterAppComments(
    getster_app_id: number,
    comment_id: number,
    getsterAppComments: GetsterAppCommentsDto,
  ): Promise<any> {
    return await this.getsterAppCommentsRepository.query(
      `update ${getster_app_id}_getster_app_comments set comment_text ='${getsterAppComments.comment_text}' where  comment_id=${comment_id};`,
    );
  }

  async updateGetsterAppCommentsType(
    getster_app_id: number,
    comment_id: number,
    getsterAppComments: GetsterAppCommentsType,
  ): Promise<any> {
    return await this.getsterAppCommentsRepository.query(
      `update ${getster_app_id}_getster_app_comments set 
      is_the_comment_private =${getsterAppComments.is_the_comment_private},
      comment_reply='${getsterAppComments.comment_reply}',
      comment_reply_by_getster_id='${getsterAppComments.comment_reply_by_getster_id}'
      where comment_id=${comment_id};`,
    );
  }

  async deleteGetsterAppComments(
    getster_id: number,
    getster_app_id: number,
    comment_id: number,
  ): Promise<any> {
    return await this.getsterAppCommentsRepository.query(
      `delete from ${getster_app_id}_getster_app_comments where  comment_id = ${comment_id}`,
    );
  }

  async getGetsterAppComments(
    getster_app_id: number,
  ): Promise<GetsterAppCommentsDto> {
    try {
      return await this.getsterAppCommentsRepository.query(
        `select * from ${getster_app_id}_getster_app_comments;`,
      );
    } catch (err) {
      throw err;
    }
  }
}
