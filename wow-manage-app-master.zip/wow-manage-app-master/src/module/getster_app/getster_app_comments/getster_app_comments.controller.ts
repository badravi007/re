/*
https://docs.nestjs.com/controllers#controllers
*/

import {
  Body,
  Controller,
  Delete,
  Get,
  HttpStatus,
  Post,
  Put,
  Query,
  UseGuards,
} from '@nestjs/common';
import { ApiBearerAuth, ApiTags } from '@nestjs/swagger';
import { JwtAuthGuard } from 'src/auth/guard/jwt-auth.guard';
import ResponseInterface from 'src/common/interface/response.interface';
import {
  GetsterAppCommentsDto,
  GetsterAppCommentsType,
} from '../dto/getster_app_comments.dto';
import { Getster_app_commentsService } from './getster_app_comments.service';

// @UseGuards(JwtAuthGuard)
// @ApiBearerAuth('JWT-auth')
@ApiTags('Getster App Comments')
@Controller('getster_app_comments')
export class Getster_app_commentsController {
  constructor(
    private readonly getster_app_commentsService: Getster_app_commentsService,
  ) {}

  @Post('/create_getster_app_comments_communication_table?')
  async creatDynamicTable(
    @Query('getster_app_id') getster_app_id: number,
  ): Promise<ResponseInterface> {
    const result = await this.getster_app_commentsService.creatDynamicTable(
      getster_app_id,
    );
    return {
      statusCode: HttpStatus.CREATED,
      message: 'Table created successful !!',
      data: result,
    };
  }

  @Post('/add_getster_app_comments?')
  async insertGetsterAppComments(
    @Query('getster_app_id') getster_app_id: number,
    @Query('timeZoneIanaString') timeZoneIanaString: string,
    @Body() getsterAppCommunicationDto: GetsterAppCommentsDto,
  ): Promise<ResponseInterface> {
    const result =
      await this.getster_app_commentsService.insertGetsterAppComments(
        getster_app_id,
        timeZoneIanaString,
        getsterAppCommunicationDto,
      );
    return {
      statusCode: HttpStatus.CREATED,
      message: 'Sent successful!!',
      data: result,
    };
  }

  @Put('/update_getster_app_comments_type?')
  async updateGetsterAppCommentsType(
    @Query('getster_app_id') getster_app_id: number,
    @Query('comment_id') comment_id: number,
    @Body() getsterAppCommunicationDto: GetsterAppCommentsType,
  ): Promise<ResponseInterface> {
    const result =
      await this.getster_app_commentsService.updateGetsterAppCommentsType(
        getster_app_id,
        comment_id,
        getsterAppCommunicationDto,
      );
    return {
      statusCode: HttpStatus.CREATED,
      message: 'Updated successful !!',
      data: result,
    };
  }

  @Put('/update_getster_app_comments?')
  async updateGetsterAppComments(
    @Query('getster_app_id') getster_app_id: number,
    @Query('comment_id') comment_id: number,
    @Body() getsterAppCommunicationDto: GetsterAppCommentsDto,
  ): Promise<ResponseInterface> {
    const result =
      await this.getster_app_commentsService.updateGetsterAppComments(
        getster_app_id,
        comment_id,
        getsterAppCommunicationDto,
      );
    return {
      statusCode: HttpStatus.CREATED,
      message: 'Updated successful !!',
      data: result,
    };
  }

  @Delete('/delete_getster_app_comments?')
  async deleteGetsterAppComments(
    @Query('getster_id') getster_id: number,
    @Query('getster_app_id') getster_app_id: number,
    @Query('comment_id') comment_id: number,
  ): Promise<ResponseInterface> {
    const result =
      await this.getster_app_commentsService.deleteGetsterAppComments(
        getster_id,
        getster_app_id,
        comment_id,
      );
    return {
      statusCode: HttpStatus.CREATED,
      message: 'Deleted successful !!',
      data: result,
    };
  }
  @Get('/get_getster_app_comments?')
  async getGetsterAppComments(
    @Query('getster_app_id') getster_app_id: number,
  ): Promise<ResponseInterface> {
    const result = await this.getster_app_commentsService.getGetsterAppComments(
      getster_app_id,
    );
    return {
      statusCode: HttpStatus.CREATED,
      message: 'Get Comments successfully!!',
      data: result,
    };
  }
}
