import { Column, Entity, PrimaryColumn, PrimaryGeneratedColumn } from 'typeorm';

@Entity({ database: 'wow_getster_app_db', name: 'getster_app_update_status' })
export class GetsterAppUpdateStatus {
  @PrimaryColumn()
  getster_app_update_utc_date_time: string;
}
