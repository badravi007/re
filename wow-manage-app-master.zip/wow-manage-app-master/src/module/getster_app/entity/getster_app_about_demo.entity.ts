import { ApiProperty } from '@nestjs/swagger';
import { Column, Entity, PrimaryColumn } from 'typeorm';

@Entity({ database: 'wow_getster_app_db', name: 'getster_app_about_demo' })
export class GetsterAppAboutDemo {
  @PrimaryColumn()
  getster_app_id: number;

  @Column({
    length: 255,
  })
  getster_app_demo_video_thumb_nail_path: string;

  @Column({
    type: 'json',
  })
  getster_app_datetime_description: TimeStampDescription[];

  @Column({
    length: 255,
  })
  getster_app_demo_video_path: string;

  @Column({
    type: 'json',
  })
  getster_app_attachments_path: object;
}

class TimeStampDescription {
  @ApiProperty()
  description: string;
  @ApiProperty()
  title: string;
  @ApiProperty()
  time_stamp: string;
}
