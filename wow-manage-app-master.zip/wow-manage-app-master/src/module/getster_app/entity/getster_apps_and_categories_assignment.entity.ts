import { Column, Entity, PrimaryColumn, PrimaryGeneratedColumn } from 'typeorm';

@Entity({
  database: 'wow_getster_app_db',
  name: 'getster_apps_and_categories_assignment',
})
export class GetsterAppsCategoryAssignment {
  @PrimaryGeneratedColumn('increment')
  id: number;

  @Column()
  getster_app_category_id: string;

  @Column({
    type: 'varchar',
    length: 100,
  })
  getster_app_id: number;

  @Column({
    type: 'varchar',
    length: 100,
  })
  getster_app_location_within_the_category_id: string;
}

export class assignCategoryToGetsterApp {
  id: number;
  getster_app_id: number;
  getster_app_category_id: string;
}
