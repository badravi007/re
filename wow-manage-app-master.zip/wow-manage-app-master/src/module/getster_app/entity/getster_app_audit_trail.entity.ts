import { Column, Entity, PrimaryGeneratedColumn } from 'typeorm';

@Entity({ database: 'wow_getster_app_db', name: 'getster_app_audit_trail' })
export class GetsterAppAuditTrail {
  @PrimaryGeneratedColumn('increment')
  id: number;

  @Column()
  getster_app_id: number;

  @Column({ length: 30 })
  entry_type: string;

  @Column()
  entry_by_user_id: number;

  @Column('datetime')
  entry_local_date_time: Date;
}
