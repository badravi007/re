import { Column, Entity, PrimaryGeneratedColumn } from 'typeorm';

@Entity({ database: 'wow_getster_app_db', name: 'getster_app_master' })
export class GetsterAppMaster {
  @PrimaryGeneratedColumn('increment')
  getster_app_id: number;

  @Column({
    type: 'varchar',
    length: 100,
  })
  getster_app_icon_name: string;

  @Column({
    type: 'varchar',
    length: 255,
  })
  getster_app_full_name: string;

  @Column({
    type: 'varchar',
    length: 100,
  })
  getster_app_icon_image: string;

  @Column()
  getster_app_development_status: boolean;
}
