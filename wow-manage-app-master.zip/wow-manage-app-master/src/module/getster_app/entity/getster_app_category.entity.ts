import { Column, Entity, PrimaryGeneratedColumn } from 'typeorm';

@Entity({
  database: 'wow_getster_app_db',
  name: 'getster_app_categories',
})
export class GetsterAppCategory {
  @PrimaryGeneratedColumn('increment')
  id: number;

  @Column({ length: 50 })
  getster_app_category_id: string;

  @Column({ length: 50, nullable: true })
  parent_getster_app_category_id: string;

  @Column({ length: 50 })
  getster_app_category_name: string;

  @Column()
  is_the_getster_app_category_hidden: boolean;

  @Column({ nullable: true })
  getster_app_category_type: number;
}
