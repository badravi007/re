import {
  Body,
  Controller,
  Get,
  HttpStatus,
  Post,
  Put,
  Query,
  Req,
} from '@nestjs/common';
import { ApiTags } from '@nestjs/swagger';
import { Request } from 'express';
import { AuthService } from 'src/auth/services/auth.service';
import ResponseInterface from 'src/common/interface/response.interface';
import { GetsterAppCategoryDto } from '../dto/getster_app_category.dto';
import { Getster_app_categoryService } from './getster_app_category.service';
@ApiTags('Getster App Category')
@Controller('getster_app_category')
export class Getster_app_categoryController {
  constructor(
    private _treeViewService: Getster_app_categoryService,
    private _authService: AuthService,
  ) {}

  @Post('add_getster_app_category')
  async addCategory(
    @Body() category: GetsterAppCategoryDto,
    @Req() request: Request,
  ): Promise<any> {
    try {
      let _data = await this._authService
        .verifyJwt(String(request.headers.authenticationtoken))
        .then((data) => data.user);
      const {
        getster_id,
        time_zone_iana_string,
        registered_mobile_country_code,
        roles,
      } = _data;
      category.time_zone_iana_string = time_zone_iana_string;
      await this._treeViewService.postCategory(category);
      return {
        status: 200,
        message: 'Created Successfully',
      };
    } catch (error) {
      throw error;
    }
  }

  @Get('get_all_getster_app_category')
  async GetAllCategories(): Promise<any> {
    try {
      const tasksData = await this._treeViewService.GetAllCategories();
      return {
        status: HttpStatus.OK,
        message: 'Fetched Successfully',
        data: tasksData,
      };
    } catch (error) {
      throw error;
    }
  }

  @Put('update_getster_app_category')
  async updateCategory(
    @Body() category: GetsterAppCategoryDto,
    @Req() request: Request,
  ): Promise<any> {
    try {
      let _data = await this._authService
        .verifyJwt(String(request.headers.authenticationtoken))
        .then((data) => data.user);
      const {
        getster_id,
        time_zone_iana_string,
        registered_mobile_country_code,
        roles,
      } = _data;
      category.time_zone_iana_string = time_zone_iana_string;

      await this._treeViewService.updateCategory(category);
      return {
        status: 200,
        message: 'Updated Successfully',
      };
    } catch (error) {
      throw error;
    }
  }

  @Put('hide_getster_app_category')
  async hideCategory(
    @Body() category: GetsterAppCategoryDto,
    @Req() request: Request,
  ): Promise<any> {
    try {
      let _data = await this._authService
        .verifyJwt(String(request.headers.authenticationtoken))
        .then((data) => data.user);
      const {
        getster_id,
        time_zone_iana_string,
        registered_mobile_country_code,
        roles,
      } = _data;
      category.time_zone_iana_string = time_zone_iana_string;

      await this._treeViewService.hideCategory(category);
      return {
        status: 200,
        message: 'Hide Successfully',
      };
    } catch (error) {
      throw error;
    }
  }

  @Get('check_getster_is_assigned_getster_app_category')
  async checkGetsterAssignedGetsterCategory(
    @Query('getster_app_category_id') getster_app_category_id: string,
  ) {
    let info = await this._treeViewService.checkGetsterAssignedGetsterCategory(
      getster_app_category_id,
    );

    if (info) {
      return {
        status: 200,
        message:
          'User is present in this category in-order to hide parent category / sub category kindly reassign the user to another category',
        userIsAssigned: true,
      };
    } else {
      return {
        status: 200,
        message: 'User is not present in this category',
        userIsAssigned: false,
      };
    }
  }

  @Put('reassign-getster-app-category-id-to-another')
  async reassignGetsterAppCategoryIdToAnother(
    @Query('existing_getster_app_category_id')
    existing_getster_app_category_id: string,
    @Query('new_getster_app_category_id') new_getster_app_category_id: string,
  ): Promise<ResponseInterface> {
    await this._treeViewService.reassignGetsterAppCategoryIdToAnother(
      existing_getster_app_category_id,
      new_getster_app_category_id,
    );
    return {
      statusCode: HttpStatus.OK,
      message: `Category Reassign Successful!`,
    };
  }
}
