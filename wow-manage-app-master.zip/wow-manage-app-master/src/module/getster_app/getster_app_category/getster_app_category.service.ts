/*
https://docs.nestjs.com/providers#services
*/

import { Injectable } from '@nestjs/common';
import { InjectConnection, InjectRepository } from '@nestjs/typeorm';
import * as mysql from 'mysql2';
import { IGetsterAppCategory } from 'src/models/interface/getster_app_category.interface';
import { DateTimeService } from 'src/shared/service/date-time.service';
import { Repository } from 'typeorm';
import { GetsterAppCategory } from '../entity/getster_app_category.entity';

@Injectable()
export class Getster_app_categoryService {
  constructor(
    @InjectRepository(GetsterAppCategory, 'wow_getster_app_db')
    @InjectConnection('wow_getster_app_db')
    private readonly userCategoryRepository: Repository<GetsterAppCategory>,
    private _dateTimeService: DateTimeService,
  ) {}

  async postCategory(category_details: IGetsterAppCategory) {
    try {
      await this.userCategoryRepository.query(`
            INSERT INTO wow_getster_app_db.getster_app_categories (getster_app_category_id, parent_getster_app_category_id, getster_app_category_name, is_the_getster_app_category_hidden,getster_app_category_type) VALUES (
              ${mysql.escape(category_details.getster_app_category_id)},
              ${mysql.escape(category_details.parent_getster_app_category_id)},
              ${mysql.escape(category_details.getster_app_category_name)},
              ${mysql.escape(
                category_details.is_the_getster_app_category_hidden,
              )},
              ${mysql.escape(category_details.getster_app_category_type)}
              );
            `);
      this.getsterAppUpdateStatus(category_details.time_zone_iana_string);
    } catch (error) {
      throw error;
    }
  }

  async updateCategory(category_details: IGetsterAppCategory) {
    try {
      if (category_details.getster_app_category_name) {
        await this.userCategoryRepository.query(`
        UPDATE wow_getster_app_db.getster_app_categories
        SET getster_app_category_name = ${mysql.escape(
          category_details.getster_app_category_name,
        )} WHERE
        getster_app_category_id = '${
          category_details.getster_app_category_id
        }' `);
      }
      this.getsterAppUpdateStatus(category_details.time_zone_iana_string);
    } catch (error) {
      throw error;
    }
  }

  async hideCategory(category_details: IGetsterAppCategory) {
    try {
      if (category_details.is_the_getster_app_category_hidden) {
        await this.userCategoryRepository.query(`
          UPDATE wow_getster_app_db.getster_app_categories
          SET is_the_getster_app_category_hidden = ${mysql.escape(
            category_details.is_the_getster_app_category_hidden,
          )} WHERE
          getster_app_category_id = '${
            category_details.getster_app_category_id
          }' `);
      }
      this.getsterAppUpdateStatus(category_details.time_zone_iana_string);
    } catch (error) {
      throw error;
    }
  }

  async GetAllCategories() {
    try {
      const TaskData = await this.userCategoryRepository.query(
        `SELECT * FROM wow_getster_app_db.getster_app_categories order by id`,
      );
      // console.log(TaskData);

      let data;
      if (TaskData.length > 1) {
        data = await this.treeConstruct(TaskData);
        // console.log(data, "tree");

        return data;
      }
      // console.log(data);

      // console.log(TaskData, "taskdata");

      const obj = TaskData[0];
      const pair = { children: [] };
      const objData = { ...obj, ...pair };
      if (obj !== undefined) {
        return [objData];
      }
      return [];
    } catch (error) {
      throw error;
    }
  }

  treeConstruct(treeData) {
    let constructedTree = [];
    for (let i of treeData) {
      let treeObj = i;
      let assigned = false;
      this.constructTree(constructedTree, treeObj, assigned);
    }
    return constructedTree;
  }

  constructTree(constructedTree, treeObj, assigned) {
    if (treeObj.parent_getster_app_category_id == null) {
      treeObj.children = [];
      constructedTree.push(treeObj);
      return true;
    } else if (
      treeObj.parent_getster_app_category_id ===
      constructedTree.getster_app_category_id
    ) {
      treeObj.children = [];
      constructedTree.children.push(treeObj);
      return true;
    } else {
      if (constructedTree.children != undefined) {
        for (let index = 0; index < constructedTree.children.length; index++) {
          let constructedObj = constructedTree.children[index];
          if (assigned == false) {
            assigned = this.constructTree(constructedObj, treeObj, assigned);
          }
        }
      } else {
        for (let index = 0; index < constructedTree.length; index++) {
          let constructedObj = constructedTree[index];
          if (assigned == false) {
            assigned = this.constructTree(constructedObj, treeObj, assigned);
          }
        }
      }
      return false;
    }
  }

  async getsterAppUpdateStatus(time_zone_iana_string: string) {
    const entry_date_time: any = await this._dateTimeService.getDateTime(
      time_zone_iana_string,
    );

    let isFound = await this.userCategoryRepository.query(`
      SELECT * FROM wow_getster_app_db.getster_app_update_status
      WHERE getster_app_update_utc_date_time
    `);

    if (isFound.length == 0) {
      await this.userCategoryRepository.query(`
          INSERT INTO wow_getster_app_db.getster_app_update_status
          (getster_app_update_utc_date_time)
          VALUES
          (${mysql.escape(entry_date_time)});
      `);
    } else {
      await this.userCategoryRepository.query(`
        UPDATE wow_getster_app_db.getster_app_update_status
        SET
        getster_app_update_utc_date_time = ${mysql.escape(entry_date_time)}

        WHERE getster_app_update_utc_date_time = '${
          isFound[0].getster_app_update_utc_date_time
        }';

      `);
    }
  }
  //
  async checkGetsterAssignedGetsterCategory(
    getster_app_category_id: string,
  ): Promise<boolean> {
    let data: any[] = await this.userCategoryRepository.query(
      `select * from wow_getster_app_db.getster_apps_and_categories_assignment where getster_app_category_id = ${mysql.escape(
        getster_app_category_id,
      )}`,
    );

    if (data.length == 0) {
      return false;
    } else {
      return true;
    }
  }

  async reassignGetsterAppCategoryIdToAnother(
    existing_getster_app_category_id: string,
    new_getster_app_category_id: string,
  ) {
    try {
      const getExistingGetsterAppWiseCategories = await this
        .userCategoryRepository.query(`
            SELECT * FROM wow_getster_app_db.getster_apps_and_categories_assignment
            where getster_app_category_id='${existing_getster_app_category_id}'
        `);

      for (let i = 0; i < getExistingGetsterAppWiseCategories.length; i++) {
        const element = getExistingGetsterAppWiseCategories[i];

        const getNewGetsterWiseCategories: any[] = await this
          .userCategoryRepository.query(`
            SELECT * FROM wow_getster_app_db.getster_apps_and_categories_assignment
            where getster_app_category_id='${new_getster_app_category_id}' AND getster_app_id='${element.getster_app_id}'
      `);

        if (getNewGetsterWiseCategories.length == 0) {
          await this.userCategoryRepository.query(`
            UPDATE wow_getster_app_db.getster_apps_and_categories_assignment
            SET
            getster_app_category_id = '${new_getster_app_category_id}'
            WHERE getster_app_category_id = '${existing_getster_app_category_id}' AND getster_app_id='${element.getster_app_id}';
          `);
        } else {
          await this.userCategoryRepository.query(`
            DELETE FROM wow_getster_app_db.getster_apps_and_categories_assignment
            WHERE getster_app_category_id='${existing_getster_app_category_id}' AND getster_app_id='${element.getster_app_id}';
          `);
        }
      }
      // this.insertGetsterGetsterCategoryAuditTrail({
      //   entry_by_getster_id: '1',
      //   entry_by_getster_category_id: existing_getster_category_id,
      //   entry_type: ' App to Getster category',
      // });

      // await this.getsterCategoryRepository.query(`
      //   UPDATE manage_getsters_of_get_wow_education_db.getster_category_wise_additional_field_names
      //   SET
      //   getster_category_id = '${new_getster_app_category_id}'
      //   WHERE getster_category_id = '${existing_getster_category_id}';
      // `);
    } catch (error) {
      throw error;
    }
  }
}
