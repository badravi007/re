import * as mysql from 'mysql2';

/*
https://docs.nestjs.com/providers#services
*/

import { Injectable } from '@nestjs/common';
import { InjectConnection, InjectRepository } from '@nestjs/typeorm';
import { unlink } from 'fs';
import { DateTimeService } from 'src/shared/service/date-time.service';
import { Repository } from 'typeorm';
import { GetsterAppAuditTrailDto } from '../dto/getster_app_audit_trail.dto';
import {
  GetsterAppMasterDto,
  UpdateGetsterAppDevelopmentStatusDto,
  UpdateGetsterAppMasterDto,
} from '../dto/getster_app_master.dto';
import { GetsterAppMaster } from '../entity/getster_app_master.entity';

@Injectable()
export class Getster_app_masterService {
  constructor(
    @InjectRepository(GetsterAppMaster, 'wow_getster_app_db')
    @InjectConnection('wow_getster_app_db')
    private readonly getsterAppMasterRepository: Repository<GetsterAppMaster>,
    private _dateTimeService: DateTimeService,
  ) {}

  async createGetsterAppMaster(
    getsterAppMasterDto: UpdateGetsterAppMasterDto,
  ): Promise<GetsterAppMaster> {
    try {
      const data = {
        getster_app_id: getsterAppMasterDto.getster_app_id,
        getster_app_icon_name: getsterAppMasterDto.getster_app_icon_name,
        getster_app_full_name: getsterAppMasterDto.getster_app_full_name,
        getster_app_development_status:
          getsterAppMasterDto.getster_app_development_status,
        getster_app_icon_image: getsterAppMasterDto.getster_app_icon_image,
      };
      let result = await this.getsterAppMasterRepository.save(data);
      let audit_trail_body = {
        getster_app_id: result.getster_app_id,
        entry_type: 'Add App',
        entry_by_user_id: getsterAppMasterDto.getster_id,
        entry_local_date_time: this._dateTimeService.getDateTime(
          getsterAppMasterDto.time_zone_iana_string,
        ),
      };

      await this.getsterAppMasterRepository.query(
        `update wow_getster_app_db.getster_app_update_status set
        getster_app_update_utc_date_time = '${this._dateTimeService.getDateTime(
          getsterAppMasterDto.time_zone_iana_string,
        )}'`,
      );

      await this.insertCustomAppAuditTrailDto(audit_trail_body);
      this.getsterAppUpdateStatus(getsterAppMasterDto.time_zone_iana_string);

      return result;
    } catch (err) {
      throw err;
    }
  }

  async updateGetsterAppMaster(
    updateGetsterAppMasterDto: UpdateGetsterAppMasterDto,
  ): Promise<GetsterApp> {
    try {
      const data = await this.getsterAppMasterRepository
        .query(
          `
        SELECT * FROM wow_getster_app_db.getster_app_master
        where getster_app_id=${updateGetsterAppMasterDto.getster_app_id}
      `,
        )
        .then((data) => data[0]);

      const {
        getster_app_development_status,
        getster_app_full_name,
        getster_app_icon_image,
        getster_app_icon_name,
        time_zone_iana_string,
      } = data;

      if (updateGetsterAppMasterDto?.getster_app_icon_image) {
        unlink(
          './src/assets/getster_app_icons/' + getster_app_icon_name,
          (error) => {
            console.log(error);
          },
        );
      }

      await this.getsterAppMasterRepository.query(
        `update wow_getster_app_db.getster_app_update_status set
        getster_app_update_utc_date_time = '${this._dateTimeService.getDateTime(
          updateGetsterAppMasterDto.time_zone_iana_string,
        )}'`,
      );

      let result = await this.getsterAppMasterRepository.query(`
      update wow_getster_app_db.getster_app_master set
      getster_app_icon_name='${
        updateGetsterAppMasterDto.getster_app_icon_name ?? getster_app_icon_name
      }',
      getster_app_icon_image='${
        updateGetsterAppMasterDto.getster_app_icon_image ??
        getster_app_icon_image
      }',
      getster_app_full_name='${
        updateGetsterAppMasterDto.getster_app_full_name ?? getster_app_full_name
      }',
      getster_app_development_status='${
        updateGetsterAppMasterDto.getster_app_development_status ??
        getster_app_development_status
      }'
       where getster_app_id='${updateGetsterAppMasterDto.getster_app_id}'`);

      let audit_trail_body = {
        getster_app_id: updateGetsterAppMasterDto.getster_app_id,
        entry_type: 'Edit App',
        entry_by_user_id: updateGetsterAppMasterDto.getster_id,
        entry_local_date_time: this._dateTimeService.getDateTime(
          updateGetsterAppMasterDto.time_zone_iana_string,
        ),
      };

      await this.insertCustomAppAuditTrailDto(audit_trail_body);
      this.getsterAppUpdateStatus(
        updateGetsterAppMasterDto.time_zone_iana_string,
      );

      return result;
    } catch (err) {
      throw err;
    }
  }

  async insertCustomAppAuditTrailDto(
    getsterAppAuditTrailDto: GetsterAppAuditTrailDto,
  ): Promise<any> {
    try {
      return await this.getsterAppMasterRepository.query(`
      insert into wow_getster_app_db.getster_app_audit_trail values(
        0,${getsterAppAuditTrailDto.getster_app_id},
        '${getsterAppAuditTrailDto.entry_type}',
        ${getsterAppAuditTrailDto.entry_by_user_id},
        '${getsterAppAuditTrailDto.entry_local_date_time}'
      )
      `);
    } catch (err) {
      throw err;
    }
  }

  async updateGetsterAppDevelopmentStatus(
    updateGetsterAppDevelopmentStatus: UpdateGetsterAppDevelopmentStatusDto,
  ): Promise<boolean> {
    try {
      const result = await this.getsterAppMasterRepository.update(
        updateGetsterAppDevelopmentStatus.getster_app_id,
        updateGetsterAppDevelopmentStatus,
      );
      this.getsterAppUpdateStatus(
        updateGetsterAppDevelopmentStatus.time_zone_iana_string,
      );

      return result ? true : false;
    } catch (err) {
      throw err;
    }
  }

  // async reassignGetsterAppToAnotherCategory(
  //   id: number,
  //   getster_app_category_id: string,
  //   time_zone_iana_string: string,
  // ): Promise<boolean> {
  //   try {
  //     const result = await this.getsterAppMasterRepository.query(
  //       `update wow_getster_app_db.getster_apps_and_categories_assignment set getster_app_category_id = '${getster_app_category_id}' where  id=${id};`,
  //     );
  //     this.getsterAppUpdateStatus(time_zone_iana_string);

  //     return result ? true : false;
  //   } catch (err) {
  //     throw err;
  //   }
  // }

  async checkGetsterAppMasterExist(
    getster_app_full_name: string,
  ): Promise<boolean> {
    try {
      const user = await this.getsterAppMasterRepository.findOne({
        where: { getster_app_full_name: getster_app_full_name },
      });
      return user ? true : false;
    } catch (err) {
      throw err;
    }
  }

  async getAllGesterAppByCategoryWise(): Promise<GetsterApp[]> {
    try {
      // let connection = getConnection('wow_getster_app_db');
      let get_all_getster_apps = await this.getsterAppMasterRepository
        .query(`SELECT master.getster_app_id,master.getster_app_icon_name,master.	getster_app_icon_image,
        master.getster_app_full_name,master.getster_app_development_status,

        assign.getster_app_category_id,assign.id,
        assign.getster_app_id,assign.getster_app_location_within_the_category_id,

        catLoc.getster_app_category_name as CategoryName, catLoc.getster_app_category_name as getster_app_category_name,
        catLoc.parent_getster_app_category_id, catLoc.getster_app_category_id

        FROM   wow_getster_app_db.getster_app_master master
        join
        wow_getster_app_db.getster_apps_and_categories_assignment assign on  master.getster_app_id = assign.getster_app_id
        join
        wow_getster_app_db.getster_app_categories catLoc  on assign.getster_app_category_id = catLoc.getster_app_category_id`);

      let get_all_category = await this.getsterAppMasterRepository.query(
        `SELECT * FROM wow_getster_app_db.getster_app_categories;`,
      );

      let body: any[] = [];
      let main_count = 0;
      for (let i = 0; i < get_all_category.length; i++) {
        let getster_app_category_name =
          get_all_category[i].getster_app_category_name;
        let data: any[] = [];

        for (let j = 0; j < get_all_getster_apps.length; j++) {
          if (
            get_all_category[i].getster_app_category_id ===
            get_all_getster_apps[j].getster_app_category_id
          ) {
            data.push(get_all_getster_apps[j]);
          }
        }
        main_count++;
        if (main_count > i && data.length != 0) {
          body.push({
            getster_app_category_name: getster_app_category_name,
            data: data,
          });
        }
        getster_app_category_name = null;
        data = [null];
      }

      return await body;
    } catch (err) {
      throw err;
    }
  }

  async getAllGetsterAppByIds(id: string): Promise<GetsterApp[]> {
    try {
      // let connection = getConnection('wow_getster_app_db');
      let get_getster_user_apps = await this.getsterAppMasterRepository
        .query(`SELECT master.getster_app_id,master.getster_app_icon_name,master.	getster_app_icon_image,
        master.getster_app_full_name,master.getster_app_development_status,

        assign.getster_app_category_id,assign.id,
        assign.getster_app_id,assign.getster_app_location_within_the_category_id,

        catLoc.getster_app_category_name as CategoryName, catLoc.getster_app_category_name as getster_app_category_name,
        catLoc.parent_getster_app_category_id, catLoc.getster_app_category_id

        FROM   wow_getster_app_db.getster_app_master master
        join
        wow_getster_app_db.getster_apps_and_categories_assignment assign on  master.getster_app_id = assign.getster_app_id
        join
        wow_getster_app_db.getster_app_categories catLoc  on assign.getster_app_category_id = catLoc.getster_app_category_id`);

      let category_id: any[] = id.split(',');
      let body: any[] = [];
      let main_count = 0;
      for (let i = 0; i < category_id.length; i++) {
        let getster_app_category_name =
          await this.getsterAppMasterRepository.query(
            `SELECT * FROM wow_getster_app_db.getster_app_categories where getster_app_category_id = '${category_id[i]}';`,
          );
        let data: any[] = [];

        for (let j = 0; j < get_getster_user_apps.length; j++) {
          if (
            category_id[i] === get_getster_user_apps[j].getster_app_category_id
          ) {
            data.push(get_getster_user_apps[j]);
          }
        }
        main_count++;
        if (main_count > i && data.length != 0) {
          body.push({
            getster_app_category_name:
              getster_app_category_name[0].getster_app_category_name,
            data: data,
          });
        }
        getster_app_category_name = null;
        data = [null];
      }
      return await body;
    } catch (err) {
      throw err;
    }
  }

  async getGetsterAppById(
    getster_app_id: number,
  ): Promise<GetsterAppMasterDto[]> {
    try {
      // let connection = getConnection('wow_getster_app_db');
      let get_getster_app = await this.getsterAppMasterRepository.query(
        `SELECT * FROM wow_getster_app_db.getster_app_master where getster_app_id= ${getster_app_id}`,
      );

      let userAppCategoryId = await this.getsterAppMasterRepository
        .query(
          `
        SELECT getster_app_category_id FROM wow_getster_app_db.getster_apps_and_categories_assignment
        WHERE getster_app_id=${getster_app_id}
    `,
        )
        .then((data) => data[0]?.getster_app_category_id);

      let data = [
        {
          ...get_getster_app[0],
          userAppCategoryId: userAppCategoryId,
        },
      ];
      return data;
    } catch (err) {
      throw err;
    }
  }

  async getAllGetsterAppAuditTrail(): Promise<any> {
    try {
      let audit_trail = await this.getsterAppMasterRepository.query(`
    SELECT * FROM wow_getster_app_db.getster_app_audit_trail;
  `);
      let result: any[] = [];
      for (let i = 0; i < audit_trail.length; i++) {
        let getster_app_master = await this.getsterAppMasterRepository.query(`
      SELECT * FROM wow_getster_app_db.getster_app_master where getster_app_id = '${audit_trail[i].getster_app_id}';`);

        let profile_name = await this.getsterAppMasterRepository.query(`
      SELECT * FROM in_manage_get_wow_education_db.getster_profile where getster_id = '${audit_trail[i].entry_by_user_id}';`);

        if (getster_app_master.length > 0) {
          result.push({
            getster_app_id: audit_trail[i].getster_app_id,
            entry_type: audit_trail[i].entry_type,
            entry_by_user_id: audit_trail[i].entry_by_user_id,
            entry_local_date_time: audit_trail[i].entry_local_date_time,
            getster_app_icon_name: getster_app_master[0].getster_app_icon_name,
            first_name: profile_name[0].first_name,
          });
        }
      }
      return result;
    } catch (err) {
      throw err;
    }
  }

  async getsterAppUpdateStatus(time_zone_iana_string: string) {
    const entry_date_time: any = await this._dateTimeService.getDateTime(
      time_zone_iana_string,
    );

    let isFound = await this.getsterAppMasterRepository.query(`
      SELECT * FROM wow_getster_app_db.getster_app_update_status
      WHERE getster_app_update_utc_date_time
    `);

    if (isFound.length == 0) {
      await this.getsterAppMasterRepository.query(`
          INSERT INTO wow_getster_app_db.getster_app_update_status
          (getster_app_update_utc_date_time)
          VALUES
          (${mysql.escape(entry_date_time)});
      `);
    } else {
      await this.getsterAppMasterRepository.query(`
        UPDATE wow_getster_app_db.getster_app_update_status
        SET
        getster_app_update_utc_date_time = ${mysql.escape(entry_date_time)}

        WHERE getster_app_update_utc_date_time = '${
          isFound[0].getster_app_update_utc_date_time
        }';

      `);
    }
  }
}

interface GetsterApp {
  category_name: string;
  data: any;
}
