/*
https://docs.nestjs.com/controllers#controllers
*/

import {
  Body,
  Controller,
  Get,
  NotFoundException,
  Post,
  Put,
  Query,
  Req,
  Res,
  UploadedFile,
  UseInterceptors,
} from '@nestjs/common';
import { FileInterceptor } from '@nestjs/platform-express';
import { ApiBody, ApiConsumes, ApiTags } from '@nestjs/swagger';
import ResponseInterface from 'src/common/interface/response.interface';
import {
  UpdateGetsterAppDevelopmentStatusDto,
  UpdateGetsterAppMasterDto,
} from '../dto/getster_app_master.dto';
import { Getster_app_masterService } from './getster_app_master.service';

import { existsSync } from 'fs';
import { diskStorage } from 'multer';
import {
  editFileName,
  imageFileFilter,
} from 'src/shared/utils/file-upload.utils';

import { Request } from 'express';
import { AuthService } from 'src/auth/services/auth.service';
import { ErrorCodeMap } from 'src/common/api-error/ErrorCodeMap';

// @UseGuards(JwtAuthGuard)
// @ApiBearerAuth('JWT-auth')
@ApiTags('Getster App Master')
@Controller('getster_app_master')
export class Getster_app_masterController {
  constructor(
    private readonly getster_app_masterService: Getster_app_masterService,
    private _authService: AuthService,
  ) {}

  @Post('/add_getster_app')
  @ApiConsumes('multipart/form-data')
  @ApiBody({
    schema: {
      type: 'object',
      properties: {
        getster_app_id: { type: 'number' },
        getster_app_icon_name: { type: 'string' },
        getster_app_full_name: { type: 'string' },
        getster_app_development_status: { type: 'boolean' },
        getster_id: { type: 'string' },
        time_zone_iana_string: { type: 'string' },
        image: {
          type: 'string',
          format: 'binary',
        },
      },
    },
  })
  @UseInterceptors(
    FileInterceptor('image', {
      storage: diskStorage({
        destination: './src/assets/getster_app_icons',
        filename: editFileName,
      }),
      fileFilter: imageFileFilter,
    }),
  )
  async createGetsterAppMaster(
    @UploadedFile() file,
    @Body() getsterAppMasterDto: UpdateGetsterAppMasterDto,
    @Req() request: Request,
  ): Promise<ResponseInterface> {
    try {
      let _data = await this._authService
        .verifyJwt(String(request.headers.authenticationtoken))
        .then((data) => data.user);
      const {
        getster_id,
        time_zone_iana_string,
        registered_mobile_country_code,
        roles,
      } = _data;
      const data = {
        getster_app_id: getsterAppMasterDto.getster_app_id,
        getster_app_icon_name: getsterAppMasterDto.getster_app_icon_name,
        getster_app_full_name: getsterAppMasterDto.getster_app_full_name,
        getster_app_development_status:
          getsterAppMasterDto.getster_app_development_status,
        getster_app_icon_image: file.filename,
        getster_id,
        time_zone_iana_string,
      };

      const alreadyExists =
        await this.getster_app_masterService.checkGetsterAppMasterExist(
          getsterAppMasterDto.getster_app_icon_name,
        );
      if (alreadyExists) {
        return {
          statusCode: 101,
          message: `Getster App  ${ErrorCodeMap[101]}!`,
          data: null,
        };
      } else {
        const result =
          await this.getster_app_masterService.createGetsterAppMaster(data);
        return {
          statusCode: 200,
          message: `Getster Getster Created Successfully!`,
          data: result,
        };
      }
    } catch (error) {
      throw error;
    }
  }

  // @UseGuards(JwtAuthGuard)
  @Put('/update_getster_app')
  @ApiConsumes('multipart/form-data')
  @ApiBody({
    schema: {
      type: 'object',
      properties: {
        getster_app_id: { type: 'number' },
        getster_app_icon_name: { type: 'string' },
        getster_app_full_name: { type: 'string' },
        getster_app_development_status: { type: 'boolean' },
        getster_id: { type: 'string' },
        time_zone_iana_string: { type: 'string' },
        image: {
          type: 'string',
          format: 'binary',
        },
      },
    },
  })
  @UseInterceptors(
    FileInterceptor('image', {
      storage: diskStorage({
        destination: './src/assets/getster_app_icons',
        filename: editFileName,
      }),
      fileFilter: imageFileFilter,
    }),
  )
  async updateGetsterAppMaster(
    @UploadedFile() file,
    @Body() updateGetsterAppMasterDto: UpdateGetsterAppMasterDto,
    @Req() request: Request,
  ): Promise<ResponseInterface> {
    try {
      let _data = await this._authService
        .verifyJwt(String(request.headers.authenticationtoken))
        .then((data) => data.user);
      const {
        getster_id,
        time_zone_iana_string,
        registered_mobile_country_code,
        roles,
      } = _data;
      const data = {
        getster_app_id: updateGetsterAppMasterDto?.getster_app_id,
        getster_app_icon_name: updateGetsterAppMasterDto?.getster_app_icon_name,
        getster_app_full_name: updateGetsterAppMasterDto?.getster_app_full_name,
        getster_app_development_status:
          updateGetsterAppMasterDto?.getster_app_development_status,
        getster_app_icon_image: file?.filename,
        getster_id,
        time_zone_iana_string,
      };
      const result =
        await this.getster_app_masterService.updateGetsterAppMaster(data);
      return {
        statusCode: 200,
        message: `Updated Getster App Successfully!`,
        data: result,
      };
    } catch (error) {
      throw error;
    }
  }

  // @UseGuards(JwtAuthGuard)
  @Put('/update_getster_app_status')
  async updateGetsterAppDevelopmentStatus(
    @Body()
    updateGetsterAppDevelopmentStatus: UpdateGetsterAppDevelopmentStatusDto,
    @Req() request: Request,
  ): Promise<ResponseInterface> {
    let _data = await this._authService
      .verifyJwt(String(request.headers.authenticationtoken))
      .then((data) => data.user);

    const {
      getster_id,
      time_zone_iana_string,
      registered_mobile_country_code,
      roles,
    } = _data;

    updateGetsterAppDevelopmentStatus.time_zone_iana_string =
      time_zone_iana_string;
    const result =
      await this.getster_app_masterService.updateGetsterAppDevelopmentStatus(
        updateGetsterAppDevelopmentStatus,
      );
    return {
      statusCode: 200,
      message: `Updated Getster App Development Status Successfully!`,
      data: result,
    };
  }

  // @UseGuards(JwtAuthGuard)
  // @Put('/reassign_getster_app_to_another_category')
  // async reassignGetsterAppToAnotherCategory(
  //   @Query('id') id: number,
  //   @Query('getster_app_category_id') getster_app_category_id: string,
  //   @Req() request: Request,
  // ): Promise<ResponseInterface> {
  //   let _data = await this._authService
  //     .verifyJwt(String(request.headers.authenticationtoken))
  //     .then((data) => data.user);
  //   const {
  //     getster_id,
  //     time_zone_iana_string,
  //     registered_mobile_country_code,
  //     roles,
  //   } = _data;
  //   const result =
  //     await this.getster_app_masterService.reassignGetsterAppToAnotherCategory(
  //       id,
  //       getster_app_category_id,
  //       time_zone_iana_string,
  //     );
  //   return {
  //     statusCode: 200,
  //     message: `Reassign Getster App To Another Category Successfully!`,
  //     data: result,
  //   };
  // }

  // @UseGuards(JwtAuthGuard)
  @Get('/get_all_getster_app_by_category_wise')
  async getAllGesterAppByCategoryWise(): Promise<any> {
    const result =
      await this.getster_app_masterService.getAllGesterAppByCategoryWise();
    return {
      statusCode: 200,
      message: `Get Getster App  List Successfully!`,
      data: result,
    };
  }

  @Get('/get_all_getster_app_by_ids?')
  async getAllGetsterAppByIds(
    @Query('getster_app_category_id') user_app_category_id: string,
  ): Promise<any> {
    const result = await this.getster_app_masterService.getAllGetsterAppByIds(
      user_app_category_id,
    );
    return {
      statusCode: 200,
      message: `Get Getster App List Successfully123!`,
      data: result,
    };
  }

  @Get('/get_getster_app_by_id?')
  async getGetsterAppById(
    @Query('getster_app_id') getster_app_id: number,
  ): Promise<any> {
    const result = await this.getster_app_masterService.getGetsterAppById(
      getster_app_id,
    );
    return {
      statusCode: 200,
      message: `Get Getster App Successfully!`,
      data: result,
    };
  }

  @Get('/get_all_getster_app_audit_trail')
  async getAllGetsterAppAuditTrail(): Promise<any> {
    const result =
      await this.getster_app_masterService.getAllGetsterAppAuditTrail();
    return {
      statusCode: 200,
      message: `Get Audit Trail Successfully!`,
      data: result,
    };
  }

  @Get('/get_file_getster_app_master')
  async getFileUserAppMaster(
    @Query('file_name') file_name: string,
    @Res() res,
  ): Promise<any> {
    try {
      if (!existsSync(`src/assets/getster_app_icons/${file_name}`)) {
        throw new NotFoundException();
      }
      return res.sendFile(file_name, {
        root: 'src/assets/getster_app_icons',
      });
    } catch (error) {
      throw error.response;
    }
  }
}
