import { AuthModule } from 'src/auth/auth.module';
/*
https://docs.nestjs.com/modules
*/

import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { DateTimeService } from 'src/shared/service/date-time.service';
import { GetsterAppAboutDemo } from './entity/getster_app_about_demo.entity';
import { GetsterAppAuditTrail } from './entity/getster_app_audit_trail.entity';
import { GetsterAppCategory } from './entity/getster_app_category.entity';
import { GetsterAppMaster } from './entity/getster_app_master.entity';
import { GetsterAppUpdateStatus } from './entity/getster_app_update_status.entity';
import { GetsterAppsCategoryAssignment } from './entity/getster_apps_and_categories_assignment.entity';
import { Getster_app_about_demoController } from './getster_app_about_demo/getster_app_about_demo.controller';
import { Getster_app_about_demoService } from './getster_app_about_demo/getster_app_about_demo.service';
import { Getster_app_categoryController } from './getster_app_category/getster_app_category.controller';
import { Getster_app_categoryService } from './getster_app_category/getster_app_category.service';
import { Getster_app_commentsController } from './getster_app_comments/getster_app_comments.controller';
import { Getster_app_commentsService } from './getster_app_comments/getster_app_comments.service';
import { Getster_app_communicationController } from './getster_app_communication/getster_app_communication.controller';
import { Getster_app_communicationService } from './getster_app_communication/getster_app_communication.service';
import { Getster_app_masterController } from './getster_app_master/getster_app_master.controller';
import { Getster_app_masterService } from './getster_app_master/getster_app_master.service';
import { Getster_apps_and_categories_assignmentController } from './getster_apps_and_categories_assignment/getster_apps_and_categories_assignment.controller';
import { Getster_apps_and_categories_assignmentService } from './getster_apps_and_categories_assignment/getster_apps_and_categories_assignment.service';

@Module({
  imports: [
    TypeOrmModule.forFeature(
      [
        GetsterAppsCategoryAssignment,
        GetsterAppMaster,
        GetsterAppCategory,
        GetsterAppAboutDemo,
        GetsterAppUpdateStatus,
        GetsterAppAuditTrail,
      ],
      'wow_getster_app_db',
    ),
    AuthModule,
  ],
  controllers: [
    Getster_apps_and_categories_assignmentController,
    Getster_app_masterController,
    Getster_app_commentsController,
    Getster_app_communicationController,
    // Getster_app_categoriesController,
    Getster_app_about_demoController,
    Getster_app_categoryController,
  ],
  providers: [
    Getster_apps_and_categories_assignmentService,
    Getster_app_masterService,
    Getster_app_commentsService,
    Getster_app_communicationService,
    Getster_app_about_demoService,
    Getster_app_categoryService,
    DateTimeService,
  ],
  exports: [
    Getster_apps_and_categories_assignmentService,
    Getster_app_masterService,
    Getster_app_commentsService,
    Getster_app_communicationService,
    Getster_app_about_demoService,
    Getster_app_categoryService,
  ],
})
export class Getster_appModule {}
