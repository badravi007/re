/*
https://docs.nestjs.com/providers#services
*/

import { Injectable } from '@nestjs/common';
import { InjectConnection, InjectRepository } from '@nestjs/typeorm';
import * as mysql from 'mysql2';
import { Repository } from 'typeorm';
import { GetsterAppAuditTrailDto } from '../dto/getster_app_audit_trail.dto';
import { GetsterAppReassignCategoryDto } from '../dto/getster_app_reassign.dto';
import { GetsterAppsCategoryAssignmentDto } from '../dto/getster_apps_and_categories_assignment.dto';
import { GetsterAppsCategoryAssignment } from '../entity/getster_apps_and_categories_assignment.entity';
@Injectable()
export class Getster_apps_and_categories_assignmentService {
  constructor(
    @InjectRepository(GetsterAppsCategoryAssignment, 'wow_getster_app_db')
    @InjectConnection('wow_getster_app_db')
    private readonly getsterAppCategoryAssignmentRepository: Repository<GetsterAppsCategoryAssignment>,
  ) {}

  async assignGetsterAppCategories(
    getsterAppCategoryAssignment: GetsterAppsCategoryAssignmentDto,
  ): Promise<any> {
    try {
      let isFound = await this.getsterAppCategoryAssignmentRepository.query(`
      SELECT * FROM wow_getster_app_db.getster_apps_and_categories_assignment
      where getster_app_category_id=${mysql.escape(
        getsterAppCategoryAssignment.getster_app_category_id,
      )} AND getster_app_id=${mysql.escape(
        getsterAppCategoryAssignment.getster_app_id,
      )}
      `);
      if (isFound.length == 0) {
        await this.getsterAppCategoryAssignmentRepository.save(
          getsterAppCategoryAssignment,
        );
      }
    } catch (err) {
      throw err;
    }
  }

  async reAssignGetsterAppCategory(
    getster_app_category_id: string,
    getster_id: number,
    entry_local_date_time: string,
    getsterAppMaster: GetsterAppReassignCategoryDto,
  ): Promise<any> {
    try {
      let result: any;
      let getsterApps = await this.getsterAppCategoryAssignmentRepository
        .query(`
      SELECT * FROM wow_getster_app_db.getster_apps_and_categories_assignment;
      `);

      for (let i = 0; i < getsterApps.length; i++) {
        let getster_apps: any = getsterAppMaster;
        for (let j = 0; j < getster_apps.length; j++) {
          if (
            getsterApps[i].getster_app_id == getster_apps[j].getster_app_id &&
            getsterApps[i].getster_app_category_id ==
              getster_apps[j].getster_app_category_id
          ) {
            // audit trail
            let audit_trail_body = {
              getster_app_id: getster_apps[j].getster_app_id,
              entry_type: 'Delete Category',
              entry_by_user_id: getster_id,
              entry_local_date_time: entry_local_date_time,
            };
            await this.insertCustomAppAuditTrailDto(audit_trail_body);
            //
            let alreadyExists = await this.checkIfExist(
              getster_app_category_id,
              getsterApps[i].getster_app_id,
            );
            if (alreadyExists) {
              // result = await this.userAppCountryBusinessCategoryLocation.query(`
              // update user_app_db.user_app_country_business_category_location set
              // user_app_category_id = '${user_app_category_id}' where
              // user_app_category_id='${userApps[i].user_app_category_id}' and
              // user_app_id='${userApps[i].user_app_id}';
              // `);

              await this.getsterAppCategoryAssignmentRepository.query(`
                delete from wow_getster_app_db.getster_apps_and_categories_assignment where
                getster_app_category_id='${getster_apps[j].getster_app_category_id}' and
                getster_app_id='${getster_apps[j].getster_app_id}';
                `);
            } else {
              let body: GetsterAppsCategoryAssignmentDto;
              body = {
                getster_app_category_id: getster_app_category_id,
                getster_app_id: getster_apps[j].getster_app_id,
                getster_app_location_within_the_category_id: '0',
              };

              result = await this.getsterAppCategoryAssignmentRepository.save(
                body,
              );

              await this.getsterAppCategoryAssignmentRepository.query(`
                delete from wow_getster_app_db.getster_apps_and_categories_assignment where
                getster_app_category_id='${getster_apps[j].getster_app_category_id}' and
                getster_app_id='${getster_apps[j].getster_app_id}';
                `);
            }
          }
        }
      }

      return result;
    } catch (err) {
      throw err;
    }
  }

  async checkIfExist(
    getster_app_category_id: any,
    getster_app_id: any,
  ): Promise<boolean> {
    try {
      let userApps = await this.getsterAppCategoryAssignmentRepository.query(`
      SELECT * FROM wow_getster_app_db.getster_apps_and_categories_assignment;
      `);
      let result: boolean = false;
      for (let i = 0; i < userApps.length; i++) {
        if (
          userApps[i].getster_app_id == getster_app_id &&
          userApps[i].getster_app_category_id == getster_app_category_id
        ) {
          result = true;
        }
      }
      return result;
    } catch (err) {
      throw err;
    }
  }

  async insertCustomAppAuditTrailDto(
    getsterAppAuditTrailDto: GetsterAppAuditTrailDto,
  ): Promise<any> {
    try {
      return await this.getsterAppCategoryAssignmentRepository.query(`
      insert into wow_getster_app_db.getster_app_audit_trail values(
        0,${getsterAppAuditTrailDto.getster_app_id},
        '${getsterAppAuditTrailDto.entry_type}',
        ${getsterAppAuditTrailDto.entry_by_user_id},
        '${getsterAppAuditTrailDto.entry_local_date_time}'
      )
      `);
    } catch (err) {
      throw err;
    }
  }
}
