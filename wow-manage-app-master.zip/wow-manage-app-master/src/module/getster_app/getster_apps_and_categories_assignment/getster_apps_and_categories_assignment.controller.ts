/*
https://docs.nestjs.com/controllers#controllers
*/

import { Body, Controller, Post, Put, Query } from '@nestjs/common';
import { ApiTags } from '@nestjs/swagger';
import ResponseInterface from 'src/common/interface/response.interface';
import { GetsterAppReassignCategoryDto } from '../dto/getster_app_reassign.dto';
import { GetsterAppsCategoryAssignmentDto } from '../dto/getster_apps_and_categories_assignment.dto';
import { Getster_apps_and_categories_assignmentService } from './getster_apps_and_categories_assignment.service';

// @UseGuards(JwtAuthGuard)
// @ApiBearerAuth('JWT-auth')
@ApiTags('Getster App Categories Assignment')
@Controller('getster_app_categories_assignment')
export class Getster_apps_and_categories_assignmentController {
  constructor(
    private readonly getster_apps_and_categories_assignmentService: Getster_apps_and_categories_assignmentService,
  ) {}

  @Post('/assign_getster_category_to_getster_app')
  async assignUserAppCountryBusinessCategory(
    @Body()
    getsterAppsCategoryAssignmentDto: GetsterAppsCategoryAssignmentDto,
  ): Promise<ResponseInterface> {
    const result =
      await this.getster_apps_and_categories_assignmentService.assignGetsterAppCategories(
        getsterAppsCategoryAssignmentDto,
      );
    return {
      statusCode: 200,
      message: `Getster App Category Assigned Successfully!`,
      data: result,
    };
  }

  @Put('/reassign_getster_app_category')
  async reassignUserAppCategory(
    @Query('getster_app_category_id') getster_app_category_id,
    @Query('getster_id') getster_id,
    @Query('entry_local_date_time') entry_local_date_time,
    @Body()
    userAppCountryBusinessCategoryDto: GetsterAppReassignCategoryDto,
  ): Promise<ResponseInterface> {
    const result =
      await this.getster_apps_and_categories_assignmentService.reAssignGetsterAppCategory(
        getster_app_category_id,
        getster_id,
        entry_local_date_time,
        userAppCountryBusinessCategoryDto,
      );
    return {
      statusCode: 200,
      message: `Getster App Reassigned Successfully!`,
      data: result,
    };
  }
}
