export class VideoHelper {
  static customFileName(req, file, cb) {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1e9);
    let fileExtension = '';
    if (file.mimetype.indexOf('mp4') > -1) {
      fileExtension = 'mp4';
    } else if (file.mimetype.indexOf('flv') > -1) {
      fileExtension = 'flv';
    } else if (file.mimetype.indexOf('mpeg') > -1) {
      fileExtension = 'mpeg';
    } else if (file.mimetype.indexOf('3gp') > -1) {
      fileExtension = '3gp';
    } else if (file.mimetype.indexOf('3g2') > -1) {
      fileExtension = '3g2';
    } else if (file.mimetype.indexOf('avi') > -1) {
      fileExtension = 'avi';
    }
    const originalName = file.originalname.split('.')[0];
    cb(null, originalName + '.' + fileExtension);
    // cb(null, originalName + '-' + uniqueSuffix + '.' + fileExtension);
  }

  static destinationPath(req, file, cb) {
    cb(null, './src/assets/uploads');
  }
}
